; ---------------------------------------------------- the 2600 program
; The original ROM with the patches the C64 needs (see the top of main.asm):
;   $F000 power-on: no SEI (our interrupts run the display)
;   $F006 the RAM clear (power-on, and Game Reset from $F7): from $80 only (JSR ClearZP), the
;         stack pointer left to the C64 (no TXS)
;   $F12E the kernel's wait for the timer: "jmp KernelHook" instead of drawing the picture
;   $F810 "sty VSYNC", $F818 "sta VSYNC": they would hit the C64's $00 (to $2E instead)
;   $FAF7 the objects' positioning: no delay loop for RESP0 (only Y's end value, $FF)
;   $F035 the colour table at $FFF7 read from a copy (TFFF7c): its last two bytes, $FFFA-$FFFB,
;         are the NMI vector, the panel's switch (NmiPanel)
ROM     = "../build/original.a26"
GameImage:
        nop                     ; F000: (sei)
        .binary ROM, $0001, $0006-$0001
        jsr ClearZP             ; F006: (sta $00,x / txs / inx / bne)
        nop
        nop
        nop
        .binary ROM, $000c, $0035-$000c
        lda TFFF7c,x            ; F035: (lda $FFF7,x)
        .binary ROM, $0038, $012e-$0038
        jmp KernelHook          ; F12E: (lda INTIM / bne)
        nop
        nop
        .binary ROM, $0133, $0810-$0133
        sty $2e                 ; F810: (sty VSYNC)
        .binary ROM, $0812, $0818-$0812
        sta $2e                 ; F818: (sta VSYNC)
        .binary ROM, $081a, $0af7-$081a
        ldy #$ff                ; FAF7: (sta WSYNC / dey / bpl: RESP0's delay, Y left $FF)
        nop
        nop
        nop
        .binary ROM, $0afc, $0ffa-$0afc
        .word NmiPanel          ; FFFA: the NMI vector (the game's colours there: TFFF7c)
        .binary ROM, $0ffc, $1000-$0ffc
        .cerror * - GameImage != $1000, "the 2600 image must be 4K"
