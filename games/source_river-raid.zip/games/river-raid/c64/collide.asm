; ============================================================== collisions
; What the 2600's TIA would have seen while its kernel drew the picture, worked out from the RAM
; by the rules of tools/model.js (checked there against tools/vcs.js), and the RAM the kernel
; leaves. Called at KernelHook, with the RAM as the kernel would find it.
;
; The play area is lines 37-197; block 5's line o 0 is line Scroll + 6 (above the top), each
; block 32 lines. A block's line o 3 reads the latches for the window that ends there (into
; $E2 shot-object, $E4 plane-bank, $E6 shot-bank, $E8 plane-object: X = the block + 1); its line
; o 4 reads object-bank (bit 5 of block + 1's flags) and clears them. The reads' clocks: 25 (46
; on the lines the kernel counts as the plane's, 179-197), 6 later after each hit found before
; them, 18 apart; o 4: the object-bank read at 31 (52), the clear at 58 (79), 27 later after an
; object-bank hit. After the picture the last reads store X = 0 (1 when Scroll >= 26). The pairs:
;   0 M0P: the shot's pixel on the object's
;   1 P0F: the plane on the bank
;   2 M0F: the shot on the bank
;   3 PP:  the plane on the object
;   4 P1F: the object on the bank (only moving helicopters' and tankers' matter: the game clears
;          the bit for all every frame and reads it only for those: types 5-7, flags bit 6)
; Objects are never drawn on a block's lines o 30-5, so the reads' clocks only matter for the
; plane and the shot against the bank.
;
; The hits are found first, into three short lists by line (usually all empty: then no window
; needs looking at): the shot's lines with a hit, the plane's lines with a hit, the blocks whose
; object is on the bank.

HitE        = $E2       ; $E2, $E4, $E6, $E8: by pair (stride 2)
pfb         = cx1       ; a line's PF0, PF1, PF2, and a 0 (cells past the screen)
gfx         = v4        ; a line's object graphics

Collide:
        lda Scroll
        sta k8b
        clc
        adc #6
        sta sb5                 ; block 5's line o 0
        jsr BlockSetup
        lda PF0
        sta pfb
        lda #0
        sta pfb+3
        sta SHN                 ; the lists empty
        sta PHN
        sta OHN
        ldx #4                  ; the latches
-       sta Lat,x
        dex
        bpl -
        jsr ShotScan
        jsr PlaneScan
        ; ---- the moving objects against the bank (types 5-7, flags bit 6), bottom block first
        ldx #0
-       lda BlkType,x
        cmp #5
        bcc +
        cmp #8
        bcs +
        lda BlkFlags,x
        and #$40
        beq +
        jsr ObjBank
+       inx
        cpx #6
        bne -
        lda SHN                 ; no hits at all: nothing stored
        ora PHN
        ora OHN
        bne +
        jmp Leftovers
+
; ---- the windows, top to bottom: the blocks' reads (o 3) and clears (o 4) on the screen, the
; hits on the lines before each (and on its line, left of the read or clear) latched first
        lda #0
        sta SHI
        sta PHI
        lda OHN
        sta OHI                 ; (that list is bottom block first: taken from its end)
        lda #255                ; (the first line with a hit: blocks whose clear comes before it
        ldx SHN                 ; latch nothing)
        beq +
        lda SHL
+       ldx PHN
        beq +
        cmp PHL
        bcc +
        lda PHL
+       ldx OHN
        beq +
        cmp OHL-1,x
        bcc +
        lda OHL-1,x
+       sta v6
        ldx #5
        stx blk
_win    ldx blk
        lda BlkO0,x             ; (its clear before the first hit: nothing latched)
        clc
        adc #4
        cmp v6
        bcc _nclr
        lda BlkO0,x             ; (the block's line o 0)
        clc
        adc #3
        sta lineL
        cmp #38
        bcc _nread
        cmp #198
        bcs _final
        jsr Reads
_nread  ldx blk
        lda BlkO0,x
        clc
        adc #4
        sta lineL
        cmp #38
        bcc _nclr
        cmp #198
        bcs _final
        jsr Clear
        lda SHI                 ; (every hit latched and cleared: nothing more happens)
        cmp SHN
        bcc _nclr
        lda PHI
        cmp PHN
        bcc _nclr
        lda OHI
        beq _final
_nclr   dec blk
        bpl _win
_final  lda #200                ; (everything left)
        sta lineL
        lda #0
        sta cutX
        jsr HitsTo
        ldx #0
        lda k8b
        cmp #26
        bcc +
        inx
+       ldy #0
-       lda Lat,y
        beq +
        tya
        asl
        sty v3
        tay
        txa
        sta HitE,y              ; (stride 2)
        ldy v3
+       iny
        cpy #4
        bne -
        lda Lat+4
        beq +
        lda BlkFlags,x
        ora #$20
        sta BlkFlags,x
+       jmp Leftovers

; Reads: block blk's line o 3 (lineL): the hits up to each read's clock latched, each latch
; stored (X = block + 1)
Reads:
        lda #25
        ldx lineL
        cpx #179
        bcc +
        lda #46
+       sta cutX
        ldy #0                  ; (pair)
_rd     sty rpair
        jsr HitsTo              ; (hits left of cutX on lineL, all on the lines before)
        ldy rpair
        lda Lat,y
        beq +
        tya
        asl
        tax
        lda blk
        clc
        adc #1
        sta HitE,x
        lda cutX
        clc
        adc #6
        sta cutX
+       lda cutX
        clc
        adc #18
        sta cutX
        ldy rpair
        iny
        cpy #4
        bne _rd
        rts

; Clear: block blk's line o 4 (lineL): the object-bank read, then the clear
Clear:
        ldy #0
        lda lineL
        cmp #179                ; (the plane's lines, as the kernel counts them: 179 on)
        bcc +
        ldy #21
+       sty rpair
        tya
        clc
        adc #31
        sta cutX
        jsr HitsTo
        lda #58
        clc
        adc rpair
        ldx Lat+4
        beq +
        adc #27
        pha
        ldx blk
        lda BlkFlags+1,x        ; (block 5's would be $94: the object can't be drawn there)
        ora #$20
        sta BlkFlags+1,x
        pla
+       sta cutX
        jsr HitsTo
        lda #0
        ldx #4
-       sta Lat,x
        dex
        bpl -
        rts

; HitsTo: latch every hit before (lineL, cutX): the objects' bank hits, the shot's lines, the
; plane's lines. A hit on lineL itself counts if its pixel is left of cutX; a plane line is
; taken only once its last hit is accounted for.
HitsTo:
        ; the objects against the bank: on their lines o 6-29 (never a read's line)
-       ldx OHI
        beq _shot
        lda OHL-1,x
        cmp lineL
        bcs _shot
        lda #1
        sta Lat+4
        dec OHI
        jmp -
        ; the shot
_shot   ldx SHI
        cpx SHN
        bcs _plane
        lda SHL,x
        cmp lineL
        bcc +
        bne _plane
        lda m0x                 ; on the line: left of the cut?
        cmp cutX
        bcs _plane
+       lda SHB,x
        lsr
        bcc +
        ldy #1
        sty Lat+0
+       lsr
        bcc +
        ldy #1
        sty Lat+2
+       inc SHI
        jmp _shot
_plane  ldx PHI
        cpx PHN
        bcs _done
        lda PHL,x
        cmp lineL
        bcc _pall
        bne _done
        lda PHA,x               ; on the line itself: its hits left of the cut now, the rest later
        cmp cutX
        bcs _done               ; (the first hit isn't left of the cut)
        lda #1
        sta Lat+1
        lda PHB,x               ; the last hit left of the cut too: the line done
        cmp cutX
        bcs _done
        inc PHI
_done   rts
_pall   lda PHA,x
        cmp #$ff
        beq +
        lda #1
        sta Lat+1
+       lda PHP,x
        beq +
        lda #1
        sta Lat+3
+       inc PHI
        jmp _plane

; ShotScan: the shot's lines with a hit into SHL (line), SHB (bit 0 on the object, bit 1 on the
; bank). The kernel writes ENAM0 on a block's odd lines (o), on for 198 - line = ShotY .. ShotY
; + 7 (mod 256), off on the plane's lines (180 on) but at o 3 and 5; the even line after shows
; the same. Line 37 is never written, nor 38 after it. The lines walked with their block (v0) and
; o (v1); a block's playfield register under the shot and whether its object is near it looked
; up once.
ShotScan:
        lda #0                  ; (its lines for the picture: none yet)
        sta SLFirst
        sta SLBits
        sta SLBits+1
        sta SLBits+2
        lda ShotX               ; (the missile's pixel: X - 1)
        sec
        sbc #1
        bcs +
        lda #159
+       sta m0x
        cmp #8                  ; (in the HMOVE comb: nothing collides)
        bcs +
        rts
+       tax
        lda CellOfX,x
        tax
        lda CellSel,x           ; (its cell's register and bit)
        sta shSel
        lda CellMask,x
        sta shMask
        lda #198                ; the lines' counter 198 - line is ShotY .. ShotY + 7
        sec
        sbc ShotY               ; (mod 256: ShotY 249+ shows on the last lines)
        sta v7                  ; the last line
        sec
        sbc #7
        bcs +
        lda #0
+       cmp #38
        bcs +
        lda #38
+       sta lineL
        lda v7
        cmp #198
        bcc +
        lda #197
        sta v7
+       lda lineL
        cmp v7
        beq +
        bcc +
        rts
+       jsr LineBO              ; (X block, Y o)
        stx v0
        sty v1
        lda #$ff
        sta shBlk               ; (no block looked up yet)
        lda v7                  ; above the plane's lines: its lines recorded at once (odd lines o
        cmp #180                ; from the first, each with the line after); the hits looked for
        bcc +                   ; only with land in the shot's cell on its rows or an object near
        jmp _sl
+       lda v7                  ; it on those lines in the blocks of its lines (shAny): the first
        sec                     ; block's o v1 to v1 + v7 - lineL (at most 31)
        sbc lineL
        clc
        adc v1
        cmp #32
        bcc +
        lda #31
+       sta tmp4
        lda v1
        sta tmp3
        ldx v0
        jsr ShQuick
        lda #0
        rol a
        sta shAny
        lda v7
        jsr LineBO
        cpx v0
        beq +
        sty tmp4                ; (the last block's: o 0 to Y)
        lda #0
        sta tmp3
        jsr ShQuick
        lda #0
        rol a
        ora shAny
        sta shAny
+       lda v1
        lsr
        bcs +
        inc lineL               ; (the first odd line)
        inc v1
+       lda v7
        sec
        sbc lineL
        bcc _snone
        and #$fe
        clc
        adc #2                  ; (lines: 2 * pairs)
        tax
        stx v3
        lda lineL
        sta SLFirst
        lda RunLo,x
        sta SLBits
        lda RunHi,x
        sta SLBits+1
        lda shAny
        beq _snone
-       jsr _hits               ; (each line's hits)
        inc lineL
        inc v1
        lda v1
        cmp #32
        bcc +
        lda #0
        sta v1
        dec v0
+       dec v3
        bne -
_snone  rts
_sl     lda v1
        lsr
        bcc _snext              ; (only the odd lines write ENAM0)
        lda lineL
        cmp #180                ; the plane's lines turn it off, but at o 3 and 5
        bcc _son
        ldy v1
        cpy #3
        beq _son
        cpy #5
        bne _snext
_son    jsr _rec
        jsr _hits               ; the odd line,
        lda lineL
        cmp #197
        bcs _snext
        inc lineL               ; ... and the even line after (o + 1: the next block's o 0 after 31)
        inc v1
        lda v1
        cmp #32
        bcc +
        lda #0
        sta v1
        dec v0
+       jsr _rec
        jsr _hits
_snext  inc lineL
        inc v1
        lda v1
        cmp #32
        bcc +
        lda #0
        sta v1
        dec v0
+       lda lineL
        cmp v7
        bcc _sl
        beq _sl
        rts
; (line lineL recorded for the picture: SLFirst the first, a bit a line from there in SLBits)
_rec    lda SLFirst
        bne +
        lda lineL
        sta SLFirst
+       lda lineL
        sec
        sbc SLFirst
        tax
        cpx #8
        bcs +
        lda BitR,x              ; (at most 8 lines on: within the first 16)
        ora SLBits
        sta SLBits
        rts
+       lda BitR-8,x
        ora SLBits+1
        sta SLBits+1
        rts
; (line lineL, block v0, o v1: its hits listed)
_hits   ldx v0
        cpx shBlk
        bne +
        jmp _chk
+
        stx shBlk               ; a new block: the shot's register in its playfield, its object
        lda shSel               ; near the shot?
        beq _np
        cmp #1
        bne _p2
        lda PP1Lo,x
        sta ptrA
        lda PP1Hi,x
        jmp _pd
_p2     lda PP2Lo,x
        sta ptrA
        lda PP2Hi,x
_pd     sta ptrA+1
_np     lda #0
        sta ShNear
        ldy BlkType,x
        lda TypeRowLo,y
        beq _land
        lda m0x
        sec
        sbc P1Pos,x
        bcs +
        adc #160
+       sta tmp
        lda P1Nus,x
        and #7
        tay
        lda tmp
        cmp NusWidth,y
        bcs _land
        inc ShNear
        lda #$ff                ; (the bit of its graphics at the shot's pixel, if any: shBit)
        sta gfx
        lda m0x
        jsr P1Pix
        sta shBit
        jmp _pos
_land   lda shSel               ; no object near: any land under the shot on its rows in this
        bne +                   ; block? (else nothing to look at on its lines: shPoss 0)
        lda PF0
        and shMask
        bne _pos
        beq _npos
+       lda v7                  ; (its lines here: o v1 to v1 + v7 - lineL, at most 31)
        sec
        sbc lineL
        clc
        adc v1
        cmp #32
        bcc +
        lda #31
+       tay
        lda RowOfO,y
        sta tmp
        ldy v1
        lda RowOfO,y
        sta tmp2
        ldy tmp
-       lda (ptrA),y
        and shMask
        bne _pos
        iny
        cpy tmp2
        bcc -
        beq -
_npos   lda #0
        .byte $2c
_pos    lda #1
        sta shPoss
_chk    lda shPoss
        bne _known
        rts
_known  lda #0
        sta v2
        lda shSel               ; the bank: the shot's cell on this row
        beq _l0
        ldy v1
        lda RowOfO,y
        tay
        lda (ptrA),y
        jmp _lm
_l0     lda PF0
_lm     and shMask
        beq +
        lda #2
        sta v2
+       lda ShNear              ; the object, if near
        beq +
        ldy v1
        jsr ObjGfx
        and shBit
        beq +
        inc v2
+       lda v2
        beq +
        ldx SHN
        sta SHB,x
        lda lineL
        sta SHL,x
        inc SHN
+       rts

; ShQuick: block X, lines o tmp3-tmp4: an object near the shot on them, or land in its cell on
; their rows? Carry set if so
ShQuick ldy BlkType,x
        lda TypeRowLo,y
        beq _ql
        lda tmp3                ; (the object's lines: o 6-29, as ObjGfx)
        cmp #30
        bcs _ql
        lda tmp4
        cmp #6
        bcc _ql
        lda m0x
        sec
        sbc P1Pos,x
        bcs +
        adc #160
+       sta tmp
        lda P1Nus,x
        and #7
        tay
        lda tmp
        cmp NusWidth,y
        bcs _ql
        ldy BlkType,x           ; ... and the shot's pixel on its graphics on some row (TypeOr)
        lda TypeOr,y
        sta gfx
        lda m0x
        jsr P1Pix
        bne _qy
_ql     lda shSel
        bne +
        lda PF0
        and shMask
        bne _qy
        clc
        rts
+       cmp #1
        bne +
        lda PP1Lo,x
        sta ptrA
        lda PP1Hi,x
        bne ++
+       lda PP2Lo,x
        sta ptrA
        lda PP2Hi,x
+       sta ptrA+1
        ldy tmp3                ; (the rows: o tmp4's to o tmp3's)
        lda RowOfO,y
        sta tmp3
        ldy tmp4
        lda RowOfO,y
        tay
        lda #0
-       ora (ptrA),y
        iny
        cpy tmp3
        bcc -
        beq -
        and shMask
        beq +
_qy     sec
        rts
+       clc
        rts

; PlaneScan: the plane's lines 180-197 with a hit into PHL (line), PHA / PHB (its first / last
; pixel on the bank, $FF none), PHP (on the object). Its eight pixels from p0x; its rows from
; the graphics pointer by 198 - line, reflected by REFP0. The bank: its three cells' land once a
; playfield row; the objects: only those near it.
PlaneScan:
        lda PlaneX              ; its pixel
        ldx $e0
        beq +
        clc
        adc #1
+       sta p0x
        tax                     ; its three cells' registers and bits (past 39: none)
        lda CellOfX,x
        sta tmp
        ldy #0
-       ldx tmp
        lda #3
        sta PSel,y
        lda #0
        sta PMask,y
        cpx #40
        bcs +
        lda CellSel,x
        sta PSel,y
        lda CellMask,x
        sta PMask,y
+       inc tmp
        iny
        cpy #3
        bne -
        lda #$ff                ; (the comb: pixels left of 8 don't collide)
        ldx p0x
        cpx #8
        bcs +
        lda CombMask,x
+       sta PComb
        ; the objects near it: blocks whose object's pixels may reach the plane's
        ; (only the bottom blocks: those whose lines o 6-29 reach line 180)
        lda #0
        sta PNear
        ldx #0
_pnb    lda BlkO0,x
        cmp #180 - 29
        bcc _pnd
        ldy BlkType,x
        lda TypeRowLo,y
        beq _pnn
        lda p0x
        sec
        sbc P1Pos,x
        bcs +
        adc #160
+       sta tmp
        lda P1Nus,x
        and #7
        tay
        lda tmp
        cmp NusWidth,y
        bcc +
        cmp #160 - 8
        bcc _pnn
+       jsr NearOK              ; (no pixel of it could meet one of the plane's: not near)
        bcc _pnn
        lda BitR,x
        ora PNear
        sta PNear
_pnn    inx
        cpx #6
        bne _pnb
_pnd
        ; quick look: the land under its three cells on all the playfield rows of lines 180-197
        ; (their bits in PF1 and in PF2: qm1, qm2; PF0's are the same on every row), and the
        ; objects near it on those blocks: neither, nothing to do
        lda #0
        sta qm1
        sta qm2
        ldx #2
-       ldy PSel,x
        lda PMask,x
        cpy #1
        bcc _q0
        bne _q2
        ora qm1
        sta qm1
        jmp _qn
_q2     ora qm2                 ; (PSel 3, past the screen: mask 0)
        sta qm2
        jmp _qn
_q0     and PF0
        bne _land
_qn     dex
        bpl -
        lda #180
        jsr LineBO
        stx v0
        tya                     ; (o of line 180: its rows to o + 17 or the block's end)
        clc
        adc #17
        cmp #32
        bcc +
        lda #31
+       tax
        lda RowOfO,x
        sta tmp                 ; (the lowest row)
        lda RowOfO,y
        ldx v0
        jsr QLand
        bcs _land
        lda #180                ; the block below, if lines 180-197 run into it
        jsr LineBO
        tya
        clc
        adc #17
        cmp #32
        bcc +
        sbc #32
        tax
        lda RowOfO,x
        sta tmp
        lda #15
        ldx v0
        dex
        jsr QLand
        bcs _land
+       ldx v0                  ; no land: objects near on those blocks?
        lda BitR,x
        dex
        bmi +
        ora BitR,x
+       and PNear
        bne _scan
        rts
_land   lda #1                  ; (land near it: looked at line by line)
        .byte $2c               ; (bit abs: skips the lda)
_scan   lda #0
        sta PLNear
        lda #0
        sta PLand
        lda #180                ; the lines: all with land near; else only the near objects'
        sta lineL
        lda #198
        sta PEnd
        lda PLNear
        bne _from
        lda #198
        sta lineL
        lda #180
        sta PEnd
        ldx #5
-       lda PNear
        and BitR,x
        beq _nb
        ldy BlkType,x           ; (its lines with pixels: o 30 - 2 * its highest row ... 31 - 2 *
        lda BlkO0,x             ; its lowest)
        clc
        adc TypeOFirst,y
        cmp lineL
        bcs +
        sta lineL
+       lda BlkO0,x
        clc
        adc TypeOEnd,y
        cmp PEnd
        bcc _nb
        sta PEnd
_nb     dex
        bpl -
        lda lineL
        cmp #180
        bcs +
        lda #180
        sta lineL
+       lda PEnd
        cmp #198
        bcc +
        lda #198
        sta PEnd
+       lda lineL
        cmp PEnd
        bcc _from
        rts
_from   lda lineL
        jsr LineBO
        stx v0                  ; (block, o)
        sty v1
        lda #$ff
        sta PRowB               ; (the land mask's block and row: none yet)
        sta PPBlk               ; (no block's playfield pointers yet)
        lda PlanePtr            ; (its graphics, normalised: bit 7 the leftmost pixel)
        sta ptrC
        lda PlanePtr+1
        sta ptrC+1
        lda p0x                 ; (the land's pixels shifted to start at the plane's first)
        and #3
        sta pshift
        lda REFP0
        and #8
        sta prefl
        lda #0                  ; (only the first hit in each latch window matters: an object's
        sta PDoneO              ; lines lie in one, the bank's windows end at lines o 3, 4: after a
        lda PLNear              ; hit the rest of the window not looked at: PDoneO by block, PDoneL
        eor #1                  ; (1 with no land near: PLReset), ObjDone (1: every near object's
        sta PLReset             ; found, or none near)
        sta PDoneL
        lda PNear
        cmp #1
        lda #0
        rol a
        eor #1
        sta ObjDone
        lda #198                ; (the plane's row: 198 - line)
        sec
        sbc lineL
        sta prow
_pl     ldy prow                ; the plane's row on this line
        lda (ptrC),y
        bne +
        jmp _next               ; (nothing on this line)
+       ldy v1                  ; (lines o 3-5: a new window for the bank)
        cpy #3
        bcc +
        cpy #6
        bcs +
        ldy PLReset
        sty PDoneL
+       ldy PDoneL              ; (nothing left to find on this line: the next; and no land near,
        beq +                   ; the rest)
        ldy ObjDone
        beq +
        ldy PLNear
        bne _nx
        rts
_nx     jmp _next
+       ldx prefl
        beq +
        tay
        lda Rev,y
+       sta v3
        lda #0
        sta v2                  ; (on the object)
        sta tmp4                ; (its pixels on the bank)
        lda PLNear
        beq +
        lda PDoneL
        beq ++
+       jmp _pp
+       ldx v0
        ldy v1
        lda RowOfO,y            ; the land under the plane, once a row
        cmp PRowR
        bne +
        cpx PRowB
        beq _have
+       sta PRowR
        stx PRowB
        cpx PPBlk               ; (the block's playfield pointers)
        beq +
        stx PPBlk
        lda PP1Lo,x
        sta ptrA
        lda PP1Hi,x
        sta ptrA+1
        lda PP2Lo,x
        sta ptrB
        lda PP2Hi,x
        sta ptrB+1
+       ldy PRowR
        lda (ptrA),y
        sta pfb+1
        lda (ptrB),y
        sta pfb+2
        ldy PSel                ; (its three cells' land: bits 2-0)
        lda pfb,y
        and PMask
        cmp #1
        lda #0
        rol a
        sta tmp2
        ldy PSel+1
        lda pfb,y
        and PMask+1
        cmp #1
        rol tmp2
        ldy PSel+2
        lda pfb,y
        and PMask+2
        cmp #1
        rol tmp2
        lda tmp2                ; (cells -> the plane's eight pixels)
        asl
        asl
        ora pshift
        tax
        lda LandWin,x
        and PComb
        sta PLand
_have   lda v3
        and PLand
        sta tmp4
        beq _pp
        sta PDoneL
_pp     ldx v0                  ; the object, if near: its graphics on this line (o 6-29)
        lda PNear
        and BitR,x
        beq _list
        and PDoneO
        bne _list
        ldy v1
        cpy #6
        bcc _list
        cpy #30
        bcs _list
        tya
        lsr
        lda ShE,x
        bcc +
        lda ShO,x
+       clc
        adc ObjRowOfO,y
        tay
        lda $fe00,y
        beq _list
        sta gfx
        lda P1Pos,x             ; (the plane's pixels -> the object's bits, by the plane's
        cmp GkPos               ; pixels in each nibble: GWHi / GWLo; again when the object's
        bne _gk                 ; pixel or NUSIZ or the plane's pixel changed)
        lda P1Nus,x
        cmp GkNus
        bne _gk
        lda p0x
        cmp GkP0
        beq +
_gk     jsr Gk
+       lda v3
        lsr
        lsr
        lsr
        lsr
        tay
        lda GWHi,y
        sta tmp
        lda v3
        and #15
        tay
        lda GWLo,y
        ora tmp
        and gfx
        beq _list
        lda #1
        sta v2
        lda BitR,x
        ora PDoneO
        sta PDoneO
        eor #$ff                ; (every near object's found?)
        and PNear
        bne _list
        lda #1
        sta ObjDone
_list   lda tmp4                ; any hit: listed (the first and last pixel on the bank, $FF none)
        ora v2
        beq _next
        ldx PHN
        lda lineL
        sta PHL,x
        lda #$ff
        ldy tmp4
        beq +
        lda HiBit,y
        clc
        adc p0x
+       sta PHA,x
        lda #$ff
        ldy tmp4
        beq +
        lda LoBit,y
        clc
        adc p0x
+       sta PHB,x
        lda v2
        sta PHP,x
        inc PHN
_next   dec prow                ; the next line
        inc v1
        lda v1
        cmp #32
        bcc +
        lda #0
        sta v1
        dec v0
+       inc lineL
        lda lineL
        cmp PEnd
        bcs +
        jmp _pl
+       rts

; Gk: block X's object (X kept): for each of the plane's eight pixels the bit of the object's
; graphics shown there (0 none: GkBit; one copy, normal or double width: by the pixels' distance
; mod 160; others: P1Pix's, not past the line's end), then by the plane's pixels set in each
; nibble of its graphics the bits shown under them: GWHi (pixels 0-3), GWLo (4-7)
Gk:     stx GkBlk
        lda P1Pos,x
        sta GkPos
        lda P1Nus,x
        sta GkNus
        lda p0x
        sta GkP0
        lda #0                  ; (one copy: by the distance mod 160 and the pixel size; quad
        sta gkEnd               ; width: not past the line's end, as P1Pix's callers)
        lda P1Nus,x
        and #7
        beq _g1
        cmp #5
        beq _g2
        cmp #7
        beq _g4
        lda gfx
        pha
        lda #$ff
        sta gfx
        ldy #7
-       sty tmp3
        tya
        clc
        adc p0x
        cmp #160
        lda #0
        bcs +
        tya
        adc p0x                 ; (carry clear)
        jsr P1Pix
+       ldy tmp3
        sta GkBit,y
        dey
        bpl -
        pla
        sta gfx
        jmp _gw
_g4     lda #160
        sec
        sbc p0x
        sta gkEnd               ; (the plane's pixels from this one past the line's end)
        lda #2
        .byte $2c
_g1     lda #0                  ; (pixel size: 1 << tmp2)
        .byte $2c
_g2     lda #1
        sta tmp2
        lda p0x                 ; (the plane's first pixel past the object's first, mod 160)
        sec
        sbc P1Pos,x
        bcs +
        adc #160
+       sta tmp3
        lda P1Nus,x             ; (reflected: bit t is 1 << t)
        and #8
        sta tmp
        ldy #0
-       lda gkEnd
        beq +
        cpy gkEnd
        bcs _g0
+       lda tmp3
        cmp #160
        bcc +
        sbc #160
+       ldx tmp2
        beq +
        lsr a
        dex
        beq +
        lsr a
+       cmp #8
        bcs _g0
        tax
        lda tmp
        bne +
        lda BitL,x
        jmp _gs
+       lda BitR,x
        jmp _gs
_g0     lda #0
_gs     sta GkBit,y
        inc tmp3
        iny
        cpy #8
        bne -
        ldx GkBlk
_gw     lda GkBit+3             ; (GWHi: plane pixel 0 is the nibble's bit 3 ... pixel 3 bit 0)
        sta GWHi+1
        lda GkBit+2
        sta GWHi+2
        ora GWHi+1
        sta GWHi+3
        lda GkBit+1
        sta GWHi+4
        ora GWHi+1
        sta GWHi+5
        lda GWHi+4
        ora GWHi+2
        sta GWHi+6
        ora GWHi+1
        sta GWHi+7
        lda GkBit
        sta GWHi+8
        .for i := 1, i < 8, i += 1
        ora GWHi+i
        sta GWHi+8+i
        lda GWHi+8
        .endfor
        lda GkBit+7             ; (GWLo: pixels 4-7)
        sta GWLo+1
        lda GkBit+6
        sta GWLo+2
        ora GWLo+1
        sta GWLo+3
        lda GkBit+5
        sta GWLo+4
        ora GWLo+1
        sta GWLo+5
        lda GWLo+4
        ora GWLo+2
        sta GWLo+6
        ora GWLo+1
        sta GWLo+7
        lda GkBit+4
        sta GWLo+8
        .for i := 1, i < 8, i += 1
        ora GWLo+i
        sta GWLo+8+i
        lda GWLo+8
        .endfor
        rts

; NearOK: could block X's object meet the plane on any line? Carry set if some pixel of its
; graphics (any row: TypeOr) lies under some pixel of the plane's (any row: PlaneOr), by the
; pixel masks (Gk) (X kept)
NearOK:
        lda P1Pos,x
        cmp GkPos
        bne +
        lda P1Nus,x
        cmp GkNus
        bne +
        lda p0x
        cmp GkP0
        beq ++
+       jsr Gk
+       lda PlanePtr            ; (the plane's rows ORed: once an image)
        cmp POKLo
        bne +
        lda PlanePtr+1
        cmp POKHi
        beq ++
+       lda PlanePtr
        sta POKLo
        sta ptrC
        lda PlanePtr+1
        sta POKHi
        sta ptrC+1
        lda #0
        ldy #18
-       ora (ptrC),y
        dey
        bne -
        sta PlaneOr
+       lda PlaneOr
        ldy REFP0
        cpy #8
        bcc +
        tay
        lda Rev,y
+       pha
        lsr
        lsr
        lsr
        lsr
        tay
        lda GWHi,y
        sta tmp
        pla
        and #15
        tay
        lda GWLo,y
        ora tmp
        ldy BlkType,x
        and TypeOr,y
        cmp #1
        rts

; QLand: block X's playfield rows tmp .. A: carry set if land in the plane's cells (qm1 in
; PF1, qm2 in PF2) on any
QLand:
        sta tmp2
        lda qm1
        beq _p2
        lda PP1Lo,x
        sta ptrA
        lda PP1Hi,x
        sta ptrA+1
        ldy tmp
-       lda (ptrA),y
        and qm1
        bne _yes
        iny
        cpy tmp2
        bcc -
        beq -
_p2     lda qm2
        beq _no
        lda PP2Lo,x
        sta ptrB
        lda PP2Hi,x
        sta ptrB+1
        ldy tmp
-       lda (ptrB),y
        and qm2
        bne _yes
        iny
        cpy tmp2
        bcc -
        beq -
_no     clc
        rts
_yes    sec
        rts

; OrRows: block X's playfield rows tmp .. A ORed into pfb+1 / pfb+2
OrRows:
        sta tmp2
        lda PP1Lo,x
        sta ptrA
        lda PP1Hi,x
        sta ptrA+1
        lda PP2Lo,x
        sta ptrB
        lda PP2Hi,x
        sta ptrB+1
        ldy tmp
-       lda (ptrA),y
        ora pfb+1
        sta pfb+1
        lda (ptrB),y
        ora pfb+2
        sta pfb+2
        iny
        cpy tmp2
        bcc -
        beq -
        rts

; ObjBank: block X's object (a helicopter or the tanker) against the bank: its first line o 6
; listed in OHL if any of its pixels is on land on its lines o 6-29 on the screen (X kept). Row r
; (12-1) is lines o 30 - 2r and 31 - 2r, on the playfield's row r. First a quick look: its cells
; against the land of all its rows at once.
ObjBank:
        stx v2
        lda P1Pos,x             ; its cells
        sta v6
        tay
        lda CellOfX,y
        sta tmp3
        lda P1Nus,x
        and #7
        tay
        lda NusWidth,y
        sta v7                  ; (pixels)
        clc
        adc v6
        sbc #0                  ; (carry clear: - 1)
        cmp #160
        bcc +
        lda #159                ; (past the line's end: wraps into the comb; not looked at)
+       tay
        lda CellOfX,y
        sta v5
        lda PP1Lo,x             ; its playfield
        sta ptrA
        lda PP1Hi,x
        sta ptrA+1
        lda PP2Lo,x
        sta ptrB
        lda PP2Hi,x
        sta ptrB+1
        ldy BlkType,x           ; its rows with pixels: the playfield's land on them at once
        lda TypeRowHi,y
        sta v3
        lda TypeRowLo,y
        tay
        lda #0
        sta pfb+1
        sta pfb+2
-       lda (ptrA),y
        ora pfb+1
        sta pfb+1
        lda (ptrB),y
        ora pfb+2
        sta pfb+2
        iny
        cpy v3
        bcc -
        beq -
-       ldx tmp3                ; any land in its cells?
        jsr Land
        bne _look
        inc tmp3
        lda tmp3
        cmp v5
        beq -
        bcc -
        ldx v2
        rts
_look   ldx v2                  ; row by row
        lda v6                  ; (its first cell again)
        tay
        lda CellOfX,y
        sta obC0
        lda #12
        sta v3                  ; (the row)
_row    ldx v2
        lda ShE,x
        clc
        adc v3
        tay
        lda $fe00,y
        sta v0                  ; (even line)
        lda ShO,x
        clc
        adc v3
        tay
        lda $fe00,y
        sta v1                  ; (odd line)
        ora v0
        beq _rn
        lda #30                 ; its first line
        sec
        sbc v3
        sbc v3
        clc
        adc BlkO0,x
        sta lineL
        cmp #198
        bcs _rn
        cmp #36
        bcc _rn
        ldy v3                  ; the playfield's row r
        lda (ptrA),y
        sta pfb+1
        lda (ptrB),y
        sta pfb+2
        lda obC0                  ; any land in the object's cells on it?
        sta tmp3
-       ldx tmp3
        jsr Land
        bne _pix
        inc tmp3
        lda tmp3
        cmp v5
        beq -
        bcc -
_rn     dec v3
        bne _row
        ldx v2
        rts
_pix    lda v0                  ; the pixels one by one, on each line of the row
        ldy lineL
        jsr _line
        bne _hit
        lda v1
        ldy lineL
        iny
        jsr _line
        bne _hit
        jmp _rn
_hit    ldx v2
        lda BlkO0,x
        clc
        adc #6
        ldy OHN
        sta OHL,y
        inc OHN
        rts
; (line Y with graphics A: Z clear if a pixel on land)
_line   sta gfx
        cpy #37                 ; (on the screen; line 37 at o 29 not drawn)
        bcc _no
        cpy #198
        bcs _no
        cpy #37
        bne +
        ldx v2
        lda BlkO0,x
        clc
        adc #29
        cmp #37
        beq _no
+       lda gfx
        beq _no
        lda #0
        sta tmp3
-       lda v6
        clc
        adc tmp3
        cmp #160
        bcs _no
        cmp #8
        bcc +
        sta tmp4
        ldx v2
        jsr P1Pix
        beq +
        ldx tmp4
        lda CellOfX,x
        tax
        jsr Land
        bne _yes
+       inc tmp3
        lda tmp3
        cmp v7
        bne -
_no     lda #0
_yes    rts

; RunLo / RunHi: n lines from SLFirst (bits 0 to n - 1)
RunLo:      .for i := 0, i < 17, i += 1
            .byte <((1 << i) - 1)
            .endfor
RunHi:      .for i := 0, i < 17, i += 1
            .byte >((1 << i) - 1)
            .endfor

; ---- helpers

; BlockSetup: per block its line o 0; its playfield pointers, its object's shapes, pixel and
; NUSIZ, when its bytes changed since last time
BlockSetup:
        ldx #5
        lda sb5
-       sta BlkO0,x
        clc
        adc #32
        dex
        bpl -
        ldx #5
_bs     lda BlkPF1,x            ; (changed?)
        cmp BsPF1,x
        bne _set
        lda BlkPF2,x
        cmp BsPF2,x
        bne _set
        lda BlkFlags,x
        and #3
        cmp BsPg,x
        bne _set
        lda BlkType,x
        cmp BsType,x
        bne _set
        lda BlkFine,x
        cmp P1Nus,x
        bne _set
        lda BlkCoarse,x
        cmp BsCoarse,x
        beq _bn
_set    lda BlkPF1,x
        sta BsPF1,x
        sta PP1Lo,x
        lda BlkPF2,x
        sta BsPF2,x
        sta PP2Lo,x
        lda BlkFlags,x
        and #3
        sta BsPg,x
        lsr
        ora #$fc
        sta PP2Hi,x
        lda BlkFlags,x
        and #1
        ora #$fc
        sta PP1Hi,x
        lda BlkType,x
        sta BsType,x
        tay
        lda T_EVEN,y
        sta ShE,x
        lda T_ODD,y
        sta ShO,x
        lda BlkCoarse,x
        sta BsCoarse,x
        lda BlkFine,x
        sta P1Nus,x
        and #$f0
        ora BlkCoarse,x
        tay
        lda XOf,y
        sta P1Pos,x
_bn     dex
        bpl _bs
        rts

; LineBO: line A (37-197) -> X = its block, Y = its line in the block (o)
LineBO:
        sec
        sbc sb5
        tay
        ldx BlkOfD,y
        lda OOfD,y
        tay
        rts

; PFRow: block X, line o Y -> pfb+1 / pfb+2 = its PF1, PF2 (X, Y kept)
PFRow:
        sty tmp4
        lda PP1Lo,x
        sta ptrA
        lda PP1Hi,x
        sta ptrA+1
        lda PP2Lo,x
        sta ptrB
        lda PP2Hi,x
        sta ptrB+1
        lda RowOfO,y
        tay
        lda (ptrA),y
        sta pfb+1
        lda (ptrB),y
        sta pfb+2
        ldy tmp4
        rts

; Land: cell X (0-39) on the row in pfb -> A != 0 (Z clear) if land (X kept, Y lost)
Land:
        ldy CellSel,x
        lda pfb,y
        and CellMask,x
        rts

; ObjGfx: block X, line o Y -> gfx = the object's graphics on that line (0 off its rows),
; Z set if none (X, Y kept)
ObjGfx:
        lda #0
        sta gfx
        cpy #6
        bcc _none
        cpy #30
        bcs _none
        sty tmp4
        tya
        lsr
        lda ShE,x
        bcc +
        lda ShO,x
+       clc
        adc ObjRowOfO,y
        tay
        lda $fe00,y
        sta gfx
        ldy tmp4
        lda gfx
_none   rts

; P1Pix: is block X's object lit at pixel A on a line with graphics gfx? A != 0 (Z clear) if
; so (X kept)
P1Pix:
        stx pbx
        sec
        sbc P1Pos,x
        bcs +
        adc #160
+       sta pd
        lda P1Nus,x
        and #7
        tay
        lda NusShift,y
        sta psh
        lda CopyFirst+1,y
        sta pend
        lda CopyFirst,y
        tay
_copy   lda pd
        sec
        sbc CopyOff,y
        bcc _nx
        ldx psh
        beq +
-       lsr a
        dex
        bne -
+       cmp #8
        bcs _nx
        tax
        ldy pbx
        lda P1Nus,y
        and #8
        beq +
        lda BitR,x
        jmp ++
+       lda BitL,x
+       and gfx
        ldx pbx
        cmp #0
        rts
_nx     iny
        cpy pend
        bne _copy
        ldx pbx
        lda #0
        rts

; Leftovers: the RAM the kernel (and the panel's code) would have left
Leftovers:
        lda #$ff                ; the line counter, the panel's loop counter
        sta $fd
        lda #0
        sta $ed
        sta $e0                 ; (REFP0's copy)
        lda #$fa                ; the 2600 stack: the panel's last call
        sta $fe
        lda #$f3
        sta $ff
        ldx BlkType             ; block 0's object: its shape pointers
        lda T_ODD,x
        sta $c7
        lda k8b                 ; (Scroll 0: the kernel went on into a block "-1", type 0)
        bne +
        ldx #0
+       lda T_EVEN,x
        sta $c9
        lda T_COL,x
        sta $cb
        ldx #0                  ; DE: the last block, -1 if block 0's line o 29 was drawn
        lda k8b
        cmp #2
        bcs +
        dex
+       stx $de
        lda BlkFlags            ; block 0's bank colour
        and #4
        ora #$d2
        eor ColEor
        and ColAnd
        sta $ee
        lda BlkPF1              ; the PF pointers: block 0's
        sta $d9
        lda BlkFlags
        and #1
        ora #$fc
        sta $da
        lda BlkPF2
        sta $db
        lda BlkFlags
        lsr
        and #1
        ora #$fc
        sta $dc
        ldy #7                  ; the logo's first row: 7 in a game; with none, by the frame
        lda State
        cmp #$ff
        bne +
        lda #$58                ; (and the ships left blank)
        sta LivesPtr
        lda $82
        lsr
        lsr
        lsr
        ldy #15
        cmp #$14
        bcs +
        ldy #7
        cmp #$0c
        bcc +
        sbc #4
        tay
+       sty LogoTop
        tya
        sec
        sbc #7
        tay
        lda T_LOGO5,y           ; ($F2: the logo's last row's last column)
        sta $f2
        dey
        sty $fc
        rts
T_LOGO5     = $FBA8

; the rows (1-12) with pixels, by object type (helicopters, tanker: the others not used)
TypeRowLo:  .byte 1, 1, 1, 1, 1, 4, 4, 4, 1, 1, 1
TypeRowHi:  .byte 12, 12, 12, 12, 12, 9, 9, 7, 12, 12, 12

; a nibble's bits each doubled (bit 3 -> bits 7-6)
Dbl4:       .byte $00, $03, $0c, $0f, $30, $33, $3c, $3f, $c0, $c3, $cc, $cf, $f0, $f3, $fc, $ff

; three cells' land (bits 2, 1, 0) -> their 12 pixels as 16 bits (high byte first)
CellPix:    .byte $00, $00, $00, $f0, $0f, $00, $0f, $f0, $f0, $00, $f0, $f0, $ff, $00, $ff, $f0
; ... shifted left 0-3 pixels, the high byte: the plane's eight pixels (cells * 4 + shift)
LandWin:    .byte $00, $00, $00, $00, $00, $01, $03, $07, $0f, $1e, $3c, $78, $0f, $1f, $3f, $7f
            .byte $f0, $e0, $c0, $80, $f0, $e1, $c3, $87, $ff, $fe, $fc, $f8, $ff, $ff, $ff, $ff
; the plane's pixel 0-7 left of pixel 8: its eight pixels' mask (the comb's don't collide)
CombMask:   .byte $00, $01, $03, $07, $0f, $1f, $3f, $7f
