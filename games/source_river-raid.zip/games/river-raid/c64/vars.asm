; working variables in free RAM at $C000 (not in the program file; cleared at start-up)
        .virtual WORKRAM
; collide
sb5:        .byte 0             ; block 5's line o 0 (Scroll + 6)
BlkO0:      .fill 6             ; by block: its line o 0
PP1Lo:      .fill 6             ; ... its playfield's PF1 / PF2 pointers
PP1Hi:      .fill 6
PP2Lo:      .fill 6
PP2Hi:      .fill 6
ShE:        .fill 6             ; ... its object's shapes (even / odd lines, low bytes in $FE00)
ShO:        .fill 6
P1Pos:      .fill 6             ; ... its object's pixel, NUSIZ (bit 3: reflected)
P1Nus:      .fill 6
BsPF1:      .fill 6             ; ... the bytes those came from
BsPF2:      .fill 6
BsPg:       .fill 6
BsType:     .fill 6
BsCoarse:   .fill 6
Lat:        .fill 5             ; the latches by pair
SLFirst:    .byte 0             ; the shot's lines for the picture: the first (0 none), a bit each
SLBits:     .fill 3
shSel:      .byte 0             ; ShotScan: its cell's register and bit, the objects near it
shMask:     .byte 0
ShNear:     .byte 0
shBlk:      .byte 0
shBit:      .byte 0
shPoss:     .byte 0
shAny:      .byte 0
m0x:        .byte 0             ; the shot's pixel, the plane's
p0x:        .byte 0
SHN:        .byte 0             ; the shot's lines with a hit: how many, which (top first), the
SHL:        .fill 12            ; hits (bit 0 on the object, bit 1 on the bank), the next to take
SHB:        .fill 12
SHI:        .byte 0
PHN:        .byte 0             ; the plane's lines with a hit: how many, which, its first / last
PHL:        .fill 18            ; pixel on the bank ($FF none), on the object; the next to take
PHA:        .fill 18
PHB:        .fill 18
PHP:        .fill 18
PHI:        .byte 0
OHN:        .byte 0             ; the objects on the bank: how many, their first lines (bottom
OHL:        .fill 6             ; block first), how many left to take
OHI:        .byte 0
PSel:       .fill 3             ; PlaneScan: its cells' registers and bits, the comb's mask,
PMask:      .fill 3             ; the land under it (and for which block and row), the blocks
PComb:      .byte 0             ; whose objects are near it (bits)
PLand:      .byte 0
PRowB:      .byte 0
PRowR:      .byte 0
PNear:      .byte 0
PLNear:     .byte 0
qm1:        .byte 0             ; PlaneScan: its cells' bits in PF1, PF2; the land's shift
qm2:        .byte 0
pshift:     .byte 0
GkBlk:      .byte 0
GkPos:      .byte $ff           ; ... (what they were made for: the object's pixel, NUSIZ, the
GkNus:      .byte 0             ; plane's pixel; the quad's plane pixels on the line)
GkP0:       .byte 0
gkEnd:      .byte 0
PlaneOr:    .byte 0             ; ... the plane's rows ORed, for the image at
POKLo:      .byte 0
POKHi:      .byte 0
TypeOr:     .fill 11            ; the objects' rows ORed, by type (TypeRows); their first line
TypeOFirst: .fill 11            ; with pixels (o), the line after their last
TypeOEnd:   .fill 11             ; ... the block GkBit is for, the plane's pixels' object bits
GkBit:      .fill 8
GWHi:       .fill 16            ; ... the object's bits under the plane's pixels set (by nibble)
GWLo:       .fill 16
prefl:      .byte 0             ; ... REFP0's reflection, the plane's row
prow:       .byte 0
PDoneO:     .byte 0             ; ... the blocks whose object hit is found, a bank hit in this window
PDoneL:     .byte 0
PLReset:    .byte 0
ObjDone:    .byte 0
PPBlk:      .byte 0             ; ... the block whose playfield ptrA / ptrB point at
PEnd:       .byte 0             ; PlaneScan: the line after the last looked at             ; PlaneScan: land near the plane
obC0:       .byte 0             ; ObjBank: the object's first cell
plA:        .byte 0             ; ... a line's first / last pixel on the bank
plB:        .byte 0
cutX:       .byte 0
rpair:      .byte 0             ; Reads: the pair             ; a read's / clear's clock (pixel)
pbx:        .byte 0             ; P1Pix's scratch
pd:         .byte 0
psh:        .byte 0
pend:       .byte 0
LogoTop:    .byte 0             ; the logo's first row (the kernel's $FC)

; render
Queue:      .fill NBUF
EvBaseOf:   .fill NBUF
NEV         = 48
CSLOTS      = 16
SlotPF1:    .fill CSLOTS        ; ... the slots' playfields (PF1 / PF2 pointers, pages), last use
SlotPF2:    .fill CSLOTS
SlotPg:     .fill CSLOTS
SlotUsed:   .fill CSLOTS
SlotRow:    .fill CSLOTS * 4    ; ... their rows' tags (render.asm: Rows), their playfield pointers
SlotP1Lo:   .fill CSLOTS
SlotP1Hi:   .fill CSLOTS
SlotP2Lo:   .fill CSLOTS
SlotP2Hi:   .fill CSLOTS
LastPF1:    .fill 6             ; the blocks' playfields last frame
LastPF2:    .fill 6
LastPg:     .fill 6
FKid:       .byte 0             ; the frame key (a new one when q8 or a slot changes; $FF none):
DesQ:       .byte 0             ; DesKey's q8, a slot changed since, each screen's key, each
SlotsChg:   .byte 0             ; screen's made ahead (and the next row to make)
SlotsMoved: .byte 0             ; (the slots moved down one block; last frame's slots; the key
OldBS:      .fill 6             ; the screen was made ahead with, rows 1-20 right: 0 none)
PreOK:      .byte 0
PreKey:     .byte 0
ScrId:      .fill 3
PreId:      .fill 3
PreJ:       .fill 3
PreScr:     .byte 0             ; (Scroll last frame: Prebuild's speed)
KofN:       .fill 24            ; (Rows: slot row by n)
BSlot:      .fill 6             ; each block's slot (and last frame's)
BSlotPrev:  .fill 6
DesKey:     .fill 21            ; the rows this frame wants (slot * 4 + w)
RowKey:     .fill 3 * 21        ; the rows each screen has ($FF: unknown)
NSTORE      = 64                ; the rows' codes: stores (their tags, slot rows holding them,
StoreTag:   .fill NSTORE        ; hash, signature: ROWRAM), the tags' stores, the next tag, the
StoreRef:   .fill NSTORE        ; next store to look at
StoreHash:  .fill NSTORE
NextTag:    .byte 0
Clock:      .byte 0
TAGMAX      = $ff - 24          ; (a frame makes 21 at most)
FrameNo:    .byte 0
cy:         .byte 0
ColK1:      .byte 0             ; Blocks: the masks its colours are for, the greens, the road's
ColK2:      .byte 0
EEC:        .fill 2
RoadC:      .fill 13             ; (C64Col's)
RoadChg:    .fill 12            ; (the rows whose colour changes, 0 ends)
RoadO:      .fill 13            ; (a whole road's colours: row 12's, then each change: its line o,
RoadV:      .fill 13            ; 0 ends; its colour)
LastQ:      .byte 0
PhaseP:     .byte 0
; staged for the frame top, by buffer
StScr:      .fill NBUF          ; the river's screen (0-2), $D018 for it, $D011
StD018:     .fill NBUF
StD011:     .fill NBUF
StStat:     .fill NBUF          ; the panel's screen ($D018)
rasOfs:     .byte 0             ; Render: a colour event's raster = line + this (LINEOFS; less one at
                                ; scroll 7: drawn as 6, Phase)
LastLine:   .byte 0             ; the last raster line's low byte (DetectPal: NmiInit's period)
FoldN:      .fill NBUF          ; the $D022 writes on raster lines 213-215 (FoldEv), done by the
FoldL:      .fill 3 * NBUF      ; panel's interrupt: how many, by buffer; each one's line, value,
FoldV:      .fill 3 * NBUF      ; kind (bit 7: a badline's)
FoldB:      .fill 3 * NBUF
StD021:     .fill NBUF          ; colours: the river, the banks at the top, the panel, the gauge,
StD022:     .fill NBUF          ; the digits (and the logo), the plane (and the shot), the needle
StPanelBg:  .fill NBUF
StGauge:    .fill NBUF
StDigit:    .fill NBUF
StPlane:    .fill NBUF
StNeedle:   .fill NBUF
StX0:       .fill NBUF          ; sprites 0 (the plane) and 1 (the shot)
StY0:       .fill NBUF
StX1:       .fill NBUF
StY1:       .fill NBUF
StMsb:      .fill NBUF
StEn:       .fill NBUF
StCol0:     .fill NBUF
StCol1:     .fill NBUF
StPtr0:     .fill NBUF
StPtr1:     .fill NBUF
NPL         = 6                 ; ... the plane's images (BLK_PLANE on): their graphics,
PlKLo:      .fill NPL           ; reflection, last use
PlKHi:      .fill NPL
PlKR:       .fill NPL
PlUsed:     .fill NPL
ShK1:       .fill NBUF          ; ... the shot image each buffer has: its lines' bits
ShK2:       .fill NBUF
ShK3:       .fill NBUF
ObjHint:    .fill 7             ; each block's last two object entries (by BlkBase + block,
ObjHint2:   .fill 7             ; mod 7: oBK)
oBK:        .byte 0
oBX:        .byte 0
; the blocks' sprites, staged (NSTAGE a buffer)
NSTAGE      = 7
stageN:     .byte 0
BlkBase:    .byte 0             ; (stage of block b: (BlkBase + b) mod 7; the Scroll it was for)
LastScroll: .byte 0
StageOf:    .fill NBUF
SgKT:       .fill NSTAGE * NBUF ; (the object's type and NUSIZ the entry is for)
SgKN:       .fill NSTAGE * NBUF
SgKE:       .fill NSTAGE * NBUF ; (the stage's entry and pixel)
SgKP:       .fill NSTAGE * NBUF

; the objects' images
ObjKT:      .fill OBJN          ; key: type, NUSIZ, the colour masks; last use
ObjKN:      .fill OBJN
ObjKE:      .fill OBJN
ObjKA:      .fill OBJN
ObjUsed:    .fill OBJN
ObjPin:     .fill OBJN          ; (1: made ahead, kept)
FreeN:      .byte 0             ; the sprite blocks free (FreeBlk: a stack)
oSl:        .byte 0
oFX:        .fill 2
oPK:        .byte 0
ObjM1:      .fill OBJN          ; the shared colours, the sprites on (bits 2-7), expanded
ObjM2:      .fill OBJN
ObjEn:      .fill OBJN
ObjExp:     .fill OBJN
okT:        .byte 0             ; MakeObj's
okN:        .byte 0
oE:         .byte 0
oM1:        .byte 0
oM2:        .byte 0
oNOwn:      .byte 0
oLayU:      .byte 0
oLayL:      .byte 0
oMrg:       .byte 0             ; (the lower sprites: the layer drawn by layer 0's, $FF none)
oH:         .byte 0
oX:         .byte 0
oB:         .byte 0
oBlk:       .byte 0
oS:         .byte 0
oLays:      .byte 0
oMax:       .byte 0
oSeg:       .byte 0
oLayer:     .byte 0
oHalf:      .byte 0
oRow:       .byte 0
oR:         .byte 0
RowE:       .fill 13
RowO:       .fill 13
RowC:       .fill 13
RowP:       .fill 13
RowL:       .fill 13
CCount:     .fill 16
OwnC:       .fill 8
; the panel (shared): what it shows
PnDig:      .fill 12
PnNeedle:   .byte 0
PnLives:    .word 0
PnLogo:     .byte 0
PnGaugeCol: .byte 0
NeedleRow:  .fill 12
GMaskT:     .fill 15 * 12       ; the gauge's pixels by row and character column (InitGauge)
GgLo:       .byte 0             ; GaugeGlyphs: the character columns redrawn
GgEnd:      .byte 0
EvRas:      .fill NEV * NBUF    ; the events by buffer: raster line, the line its interrupt comes on,
EvArm:      .fill NEV * NBUF    ; its handler, its kind (AddEv: a register on the $D000 page, + $C0
EvLo:       .fill NEV * NBUF    ; a badline's), value
EvHi:       .fill NEV * NBUF
EvReg:      .fill NEV * NBUF
EvVal:      .fill NEV * NBUF
DbgLoops:   .word 0             ; testing aids (read by the tools, in this order: AutoInput copies
DbgLate:    .word 0             ; them to DbgAutoRes): main-loop passes, passes skipping pictures,
DbgTops:    .word 0             ; frame tops, tops with no new picture, sprite moves on or after
DbgRepeat:  .word 0             ; their sprites' first line, the time waiting (15 cycles a count;
DbgMoveLate: .word 0            ; 17 for a free buffer)
DbgIdle:    .fill 3
DbgIdleQ:   .fill 3
DbgAcc:                         ; cycles (DBGTIME, main.asm): the interrupt, the ticks, render, sound
DbgIrqC:    .fill 4
DbgTickC:   .fill 4
DbgRendC:   .fill 4
DbgSndC:    .fill 4
DbgAutoN    = DbgSndC + 4 - DbgLoops
DbgTL:      .byte 0
DbgTH:      .byte 0
DbgTIL:     .byte 0
DbgTIH:     .byte 0
DbgAutoRes: .fill 32
DbgBorder:  .byte 0             ; testing aid: the border by what the C64 does (main.asm)
DbgB:       .byte 0
DbgLogI:    .byte 0
DbgLog:     .fill 256
DbgRepI:    .byte 0             ; the ticks (AutoT) of the last 128 frames with no new picture
DbgRepT:    .fill 256
DbgAuto:    .byte 0             ; the self-playing game: 1 on, $80 done
AutoT:      .word 0             ; ... its tick count, its counters from / to
AutoFrom:   .word 0
AutoTo:     .word 0
AutoR:      .byte 0             ; ... random, frames with no game, its stick
AutoOver:   .byte 0
AutoStick:  .byte 0
AutoSpeed:  .byte 0
        .cerror * > $d000, "the working variables run into the I/O area"
        .endv

; the river rows' stores (Rows, in render.asm): their codes by column (4-11, 12-19), store; in
; the panel's screens, rows they never show (STATA's 0-19, STATB's 0-20)
CodeColA    = STATA
CodeColB    = STATB
        .cerror CodeColA + 8 * NSTORE > STATA + 40 * 20, "CodeColA runs into the panel"
        .cerror CodeColB + 8 * NSTORE > STATB + 40 * 21, "CodeColB runs into the panel"
; the objects' images' sprites (render.asm), in free RAM after the code at $8000
        .virtual OBJRAM
ObjXOff:    .fill 6 * OBJN      ; by sprite: X offset, colour, block
ObjCol:     .fill 6 * OBJN
ObjPtr:     .fill 6 * OBJN
FreeBlk:    .fill 256 - BLK_OBJ + XTRAN ; the sprite blocks free (a stack: FreeN)
        .cerror * > StgCode, "OBJRAM runs into StgCode"
        .endv
        .virtual SIGRAM
StoreSig:   .fill 8 * NSTORE    ; the river rows' signatures (PF1 rows, PF2 rows), store
        .cerror * > CHARSET + $800, "SIGRAM runs past the character set"
        .endv
        .virtual HASHRAM
HashTab:    .fill 256           ; by hash: the tag last made with it ($FF none)
TagStore:   .fill 256           ; by tag: its store
        .cerror * > CHARSET + $800, "HASHRAM runs past the character set"
        .cerror HASHRAM < CHARSET + 8 * (CH_PANEL + 48), "HASHRAM over the panel's characters"
        .endv
