; River Raid (Atari 2600, Activision 1982) running on the Commodore 64.
;
; The original 2600 program runs almost unchanged at $F000, in the RAM under the C64 KERNAL
; (patches: see GameImage in data.asm). This file and the others supply everything the 2600
; hardware used to do:
;   - display: laid out line for line like the 2600 picture (one 2600 pixel = one multicolour
;     pixel, two C64 pixels; 2600 line L is raster line L + 18). The river (the playfield, four
;     2600 pixels a character) is multicolour characters that scroll with the VIC's vertical
;     scroll: a block of the river (32 lines) is four character rows, the same characters as long
;     as it is on the screen; three screens taken in turn (every eight lines of scroll the rows
;     move down one, the next screen made ahead).
;     The banks' colour ("01", $D022) is set line by line where it changes (roads, sections). The
;     objects (one a block) are multicolour sprites moved down the screen block by block, the
;     plane and the shot sprites 0 and 1. The bottom panel is fixed character rows (the VIC's
;     scroll set back to 0 there), the ships left and the logo sprites 0 and 1 again.
;   - collisions: the shot and the plane against the banks and the objects, the objects against
;     the banks, worked out in software by the rules of tools/model.js (which matches the 2600
;     pixel for pixel), handed to the game as the RAM its kernel would have left
;   - input: keyboard and joysticks mapped onto the 2600 joystick and switch ports
;   - sound: the game's TIA sound registers translated to the SID
;
; The game's TIA writes land harmlessly in zero page $02-$2C, its VSYNC writes at $2E (patched);
; it reads its fire buttons at $0C/$0D, where we put them. Its RIOT accesses ($0280-$0297) hit
; plain C64 RAM, which we fill in each frame.
;
; Build: build.cmd (64tass -C -a -o build/riverraid-V.prg c64/main.asm)

        .cpu "6502"

; ---------------------------------------------------------------- 2600 RAM (see 2600/symbols.js)
Scroll      = $8B       ; the line within the top block (0-31)
Flash       = $8D
BlkFlags    = $8E       ; per block (0 the bottom, 5 the top): flags,
BlkCoarse   = $94       ; the object's coarse position,
BlkFine     = $9A       ; fine motion | NUSIZ1 (reflection in bit 3),
BlkType     = $A0       ; type,
BlkPF1      = $A6       ; the playfield's PF1 and PF2 pointers
BlkPF2      = $AC
ShotY       = $B2
PlaneX      = $B3
Fuel        = $B7
PlanePtr    = $BA
LivesPtr    = $C0
State       = $C6       ; $FF: no game
DigitPtr    = $CD
ColEor      = $85
ColAnd      = $86
ColPlane    = $EF
ColPanel    = $F0
ColNeedle   = $F1
ColGauge    = $F3
CurPlayer   = $F4
ShotX       = $F5

; ------------------------------- 2600 hardware: TIA writes land in zero page
COLUP0      = $06
COLUBK      = $09
REFP0       = $0B
PF0         = $0D
AUDC0       = $15       ; AUDC0/1, AUDF0/1, AUDV0/1 in pairs
AUDF0       = $17
AUDV0       = $19
INPT4       = $0C       ; bit 7 clear: fire
INPT5       = $0D
; RIOT
SWCHA       = $0280     ; joysticks (high nibble: player 1, low: player 2)
SWCHB       = $0282     ; console switches
INTIM       = $0284     ; timer (kept at 0 so the game never waits)

; ------------------------------------------------ 2600 program addresses
PowerOn     = $F000
FrameEnd    = $F489     ; where the game continues after drawing a picture
T_ODD       = $FFC8     ; the objects' shapes (odd lines, even lines) and colours by type
T_EVEN      = $FBBB
T_COL       = $FF23
T_ROAD      = $FFB3     ; a road's colours by row

; ------------------------------------------------------------ C64 layout
NBUF        = 3         ; buffers: one shown, one waiting, one being drawn
LINEOFS     = 18        ; 2600 line L is raster line L + LINEOFS (the top line, 37: 55)
TOPRASTER   = 8         ; frame start: above the picture
ENDRASTER   = 251       ; the picture done
STATRASTER  = 197 + LINEOFS     ; the play area's last line: the panel from the next
LOGORASTER  = 228       ; the logo's sprites set up, the needle's colour
LOGOY       = 242       ; the logo's first line - 1 (2600 225: two lines higher than the 2600's)
NEEDLERASTER = 228      ; (the needle's colour set: after the digits, before the needle)
WORKRAM     = $c000     ; our working variables (vars.asm)
CHARSET     = $4000     ; the VIC (bank 1, $4000-$7FFF): the characters,
SCREEN0     = $4800     ; the river's three screens (by the scroll's eight-line phase, in turn),
STATA       = $5400     ; the panel's two screens (its rows from row 20, from 21 at scroll 0)
STATB       = $5800
SPR0        = $5c00     ; sprite blocks from here (block 112)
BLK0        = (SPR0 - $4000) / 64
BLK_PLANE   = BLK0      ; the plane's images (NPL), the shot's by buffer (NBUF)
BLK_SHOT    = BLK0 + 6
BLK_LOGO    = BLK0 + 9  ; the ships left and the logo (two)
BLK_BLANK   = BLK0 + 11
BLK_OBJ     = BLK0 + 12 ; the objects' images' sprites: blocks from here on (and XtraBlk), OBJN
OBJN        = 40        ; images
CODE_8      = $8000     ; parts of the program that run elsewhere (copied there by Start)
OBJRAM      = $ad00     ; the objects' images' sprites (vars.asm)
SIGRAM      = $4500     ; ... their signatures (in the character set: past the characters used)
StgCode     = $b080     ; the objects' sprites' code by stage (render.asm, InitStages)
HASHRAM     = $4300     ; the river rows' hash table and tags' stores (in the character set: past
                        ; the characters used)

; characters
CH_COMB     = 16        ; "11" (black): the HMOVE comb at the left edge
CH_LAND     = 15        ; all land
CH_BLANK    = 17        ; all "00"
CH_BLACK    = 18        ; the panel's first line: "11" (colour RAM: the gauge's colour), then "00"
CH_PANEL    = 32        ; the panel's characters from here

; sprites
S_PLANE     = 0
S_SHOT      = 1

; ------------------------------------------------------- zero page ($40+)
; $02-$2C take the game's TIA writes, $2E its VSYNC writes (patched), $0C/$0D are its fire
; buttons, so ours start at $40.
        .virtual $40
ptrA        .word ?
ptrB        .word ?
ptrC        .word ?
ptrD        .word ?
tmp         .byte ?
tmp2        .byte ?
tmp3        .byte ?
tmp4        .byte ?
v0          .byte ?
v1          .byte ?
v2          .byte ?
v3          .byte ?
v4          .byte ?
v5          .byte ?
v6          .byte ?
v7          .byte ?
frameFlag   .byte ?     ; frames counted by the raster interrupt, the main loop's yet to do
FOwed       .byte ?
FNow        .byte ?
isPal       .byte ?
tickAcc     .byte ?
firstTick   .byte ?
joyb        .word ?     ; port 2, port 1 (0 bits = pressed)
switches    .byte ?     ; SWCHB toggles
curBuf      .byte ?     ; raster interrupt: the buffer shown
QCount      .byte ?     ; buffers drawn, waiting to be shown, in Queue
irqIdx      .byte ?     ; the raster interrupt's event (its index in EvRas ...)
irqT        .byte ?     ; its scratch bytes
irqB        .byte ?
irqPM       .byte ?     ; ... the plane's and the shot's MSBs and on bits (the frame top's)
irqPE       .byte ?
irqSA       .byte ?
irqSX       .byte ?
irqSY       .byte ?
irqP        .word ?     ; ... the sprite pointers' address in the screen shown
rbuf        .byte ?     ; render: the buffer being drawn
evN         .byte ?     ; ... its events so far
k8b         .byte ?     ; collide / render: Scroll at the kernel's start, block 5's first line - 37
lineL       .byte ?     ; a 2600 line
blk         .byte ?     ; a block
cx0         .byte ?     ; collide: a line's PF0, PF1, PF2 and a 0 (pfb: cx1-cx4)
cx1         .byte ?
cx2         .byte ?
cx3         .byte ?
cx4         .byte ?
q8          .byte ?     ; render: Scroll / 8, the colour so far down the screen
curCol      .byte ?
cw0         .fill 8     ; ... MakeCodes' rows
        .cerror * > $80, "zero page overflow"
        .endv

; ------------------------------------------------------------ BASIC program
; LOAD and RUN start the game; LIST shows the title, credits and controls.
; (Lower case here: 64tass -a turns it into PETSCII, which the C64 shows in capitals.)
        * = $0801
        .word Bas10, 0
        .null $9e, format(" %d", Start)
Bas10   .word Bas20, 10
        .null $8f, " river raid"
Bas20   .word Bas30, 20
        .null $8f, " from the atari 2600, activision 1982"
Bas30   .word Bas40, 30
        .null $8f, " programmed by carol shaw"
Bas40   .word Bas50, 40
        .null $8f, " version 1.1"
Bas50   .word Bas60, 50
        .null $8f, " ported by claude and doughboy68"
Bas60   .word Bas70, 60
        .null $8f, " joy port 2 (player 2: port 1) or"
Bas70   .word Bas80, 70
        .null $8f, " a/d-steer w/s-speed space-fire"
Bas80   .word Bas90, 80
        .null $8f, " f1 or fire-start f2-power off/on"
Bas90   .word BasEnd, 90
        .null $8f, " f3-game f5-colour/b&w f7/f8-missiles"
BasEnd  .word 0

; ===================================================================== init
Start:
        sei
        cld
        ldx #$ff
        txs
        lda #$7f                ; no CIA interrupts
        sta $dc0d
        sta $dd0d
        lda $dc0d
        lda $dd0d
        lda #$35                ; RAM everywhere except I/O at $D000
        sta $01
        jsr Relocate            ; the parts that run elsewhere, the 2600 program at $F000

        lda #0                  ; clear zero page $02-$FF (2600 RAM included)
        ldx #2
-       sta $00,x
        inx
        bne -
        ldx #0                  ; and our working variables
-       .for i := 0, i < 16, i += 1
        sta WORKRAM + i * $100,x
        .endfor
        inx
        bne -
        lda #<IrqTop            ; our IRQ vector replaces the 2600's (the frame top's first)
        sta $fffe
        lda #>IrqTop
        sta $ffff
        ; 2600 ports at rest
        lda #$ff
        sta SWCHA
        lda #$0b                ; colour, both difficulties B, reset/select up
        sta SWCHB
        sta switches
        lda #0
        sta INTIM
        lda #$80
        sta INPT4
        sta INPT5
        lda #1
        sta firstTick

        lda #$ff                ; CIA 1's timer A free-running (testing aid: DbgT0 / DbgT1)
        sta $dc04
        sta $dc05
        lda #$11
        sta $dc0e
        jsr InitVideo
        jsr PreObj              ; (the objects' images, a fraction of a second)
        jsr InitSound
        jsr DetectPal
        jsr NmiInit             ; (the panel's switch: an NMI on line 215 every frame)

        lda #0                  ; start the raster interrupt at the frame top
        sta curBuf
        sta QCount
        lda #NBUF - 1
        sta frameFlag
        lda #TOPRASTER
        sta $d012
        lda #$13                ; display on, 24 rows (the top border down to line 55), raster bit 8 clear
        sta $d011
        lda #1
        sta $d01a
        lda #$ff
        sta $d019
        cli

; ================================================================ main loop
; Each pass: the game's ticks for a frame (PAL: 6 every 5 frames), then the picture drawn into
; the buffer not shown, queued for the frame top. Behind (more frames owed), a pass does the
; ticks of the rest at once, skipping pictures to keep the game's speed (at most 4 frames owed).
MainLoop:
-       lda frameFlag           ; frames to do (the raster interrupt adds one each frame)
        bne +
        inc DbgIdle             ; (testing aid: the time waiting, 15 cycles a count)
        bne -
        inc DbgIdle+1
        bne -
        inc DbgIdle+2
        jmp -
+       sei
        lda frameFlag
        cmp #5
        bcc +
        lda #4
+       sta FOwed
        sec                     ; this pass: all owed but the lead (NBUF - 2), at least one
        sbc #NBUF - 2
        beq +
        bcs ++
+       lda #1
+       sta FNow
        eor #$ff
        sec
        adc FOwed
        sta frameFlag
        cli
        ldx FNow
        inc DbgLoops            ; (testing aid: passes, and passes that skipped pictures)
        bne +
        inc DbgLoops+1
+       cpx #2
        bcc +
        inc DbgLate
        bne +
        inc DbgLate+1
+       jsr ReadInput
        jsr DbgT0
        lda DbgBorder           ; (testing aid: the border shows where the time goes)
        beq +
        lda #2
        sta $d020
+
        lda PowerReq            ; F2: the power switch
        beq _frame
        jsr PowerCycle
_frame  lda isPal               ; PAL: 6 game ticks every 5 frames keeps 2600 speed
        beq _ntsc
        lda tickAcc
        clc
        adc #6
        sta tickAcc
-       lda tickAcc
        cmp #5
        bcc _next
        sbc #5
        sta tickAcc
        jsr TickIn
        jmp -
_ntsc   jsr TickIn
_next   dec FNow
        bne _frame
        ldy #DbgTickC - DbgAcc
        jsr DbgT1
-       lda QCount              ; a buffer free (one shown, at most one waiting)
        cmp #NBUF - 1
        bcc +
        inc DbgIdleQ            ; (testing aid: the time waiting, 17 cycles a count)
        bne -
        inc DbgIdleQ+1
        bne -
        inc DbgIdleQ+2
        jmp -
+
        lda DbgBorder           ; (testing aid: the border shows where the time goes)
        beq +
        lda #5
        sta $d020
+
        jsr DbgT0
        jsr Render              ; draw the state the ticks produced
        ldy #DbgRendC - DbgAcc
        jsr DbgT1
        sei                     ; ... queued for the frame top
        ldx QCount
        lda rbuf
        sta Queue,x
        inc QCount
        cli
        lda DbgBorder           ; (testing aid: the border shows where the time goes)
        beq +
        lda #6
        sta $d020
+
        jsr DbgT0
        jsr UpdateSound
        ldy #DbgSndC - DbgAcc
        jsr DbgT1
        lda DbgBorder           ; (testing aid: the border shows where the time goes)
        beq +
        lda #0
        sta $d020
+
        jmp MainLoop

; TickIn: a tick with the fire buttons as ReadInput last read them (the 2600's TIA writes REFP1
; and PF0 at $0C / $0D, where it reads INPT4 / INPT5: a pass doing two ticks, as PAL's every
; fifth, would read those for the second: fire held at random)
TickIn:
        lda FireIn
        sta INPT4
        lda FireIn+1
        sta INPT5
; One 2600 frame of game logic: the original code from the end of the picture to the start
; of the next one, where it jumps to KernelHook.
Tick:
        lda DbgAuto             ; (testing aid: the inputs by the tick count)
        beq +
        jsr AutoInput
+       lda firstTick
        beq +
        lda #0
        sta firstTick
        jmp PowerOn             ; the very first frame starts at power-on
+       jmp FrameEnd

; The game would draw the picture now. Its vertical blank pushed the kernel's entry (two bytes,
; which the 2600 leaves at $FE / $FF): off our stack, into the 2600 RAM as the 2600's stack does.
KernelHook:
        pla
        sta $fe
        pla
        sta $ff
        jsr Collide             ; what the TIA would have seen, and the RAM the kernel leaves
        rts                     ; (returns to whoever called Tick)

; Relocate: the parts of the file that run elsewhere copied there, whole pages
Relocate:
        ldx #0
_part   stx tmp4
        lda RelSrcLo,x
        sta ptrA
        lda RelSrcHi,x
        sta ptrA+1
        lda #0
        sta ptrB
        lda RelDst,x
        sta ptrB+1
        lda RelPages,x
        tax
        ldy #0
-       lda (ptrA),y
        sta (ptrB),y
        iny
        bne -
        inc ptrA+1
        inc ptrB+1
        dex
        bne -
        ldx tmp4
        inx
        cpx #RelN
        bne _part
        rts
RelSrcLo:   .byte <GameImage, <Img8
RelSrcHi:   .byte >GameImage, >Img8
RelDst:     .byte $f0, >CODE_8
RelPages:   .byte 16, >(Img8End - CODE_8 + 255)
RelN        = 2

; =========================================================== interrupts
; Each buffer has its list of events down the screen (made by Render), from the frame top:
; register writes on their line (the banks' colour), the objects' sprites for a block, the
; panel, the logo. An event's line has passed: it runs at once.
; Each event's handler is the interrupt's vector itself (EvLo / EvHi), entered on its line EvArm
; (the event's line EvRas less its lead: a register write's 2 lines ahead, then it waits for the
; line). Every handler starts with IrqPro (the registers saved, the interrupt acknowledged) and
; goes on at IrqNextEv, which points the vector and the raster line at the next event, or runs
; it at once (past IrqPro) if its line has come. irqIdx: the event being run; irqT: its line.
IRQPRO      = 10 + ((DBGTIME || DBGLOG) ? 3 : 0)   ; (IrqPro's bytes)
IrqPro  .macro
        sta irqSA
        stx irqSX
        sty irqSY
        cld
        asl $d019
        .if DBGTIME || DBGLOG
        jsr DbgIrqIn
        .endif
        .endm

IrqNextEv:
        ldy irqIdx
        iny
        sty irqIdx
        lda EvRas,y
        sta irqT
        lda EvLo,y
        sta $fffe
        lda EvHi,y
        sta $ffff
        lda EvArm,y
        sta $d012
        bit $d011               ; (below line 255: passed)
        bmi IrqDue
        cmp $d012
        beq IrqDue
        bcc IrqDue
IrqOut
        .if DBGTIME || DBGLOG
        jsr DbgIrqOut
        .endif
        lda irqSA
        ldx irqSX
        ldy irqSY
        rti
IrqDue  asl $d019               ; (its line has come: at once, past its IrqPro; the interrupt
        lda $fffe               ; latched by writing $D012 on its line cleared)
        clc
        adc #IRQPRO
        sta _j+1
        lda $ffff
        adc #0
        sta _j+2
_j      jmp $0000

; the frame top: the buffer to show (FrameTop), then its events
IrqTop
        #IrqPro
        jsr FrameTop
        ldx curBuf
        ldy EvBaseOf,x
        dey
        sty irqIdx
        jmp IrqNextEv
; a register write on its line (EvReg: the register)
IrqWrite
        #IrqPro
        ldy irqIdx
        ldx EvReg,y
        stx _w+1
        lda EvVal,y
        ldx irqT
        dex
-       cpx $d012               ; (the line or a later one: a short loop, the write as early as
        bcs -                   ; it can be, ahead of the first pixel past the comb)
_w      sta $d000
        jmp IrqNextEv
; a badline's write: the VIC holds the CPU from cycle ~12 of that line, so write at the end of
; the line before, past the last pixel (BADDELAY)
IrqBad
        #IrqPro
        ldy irqIdx
        ldx EvReg,y
        stx _w+1
        ldx irqT
        dex
        stx irqB
        lda EvVal,y
-       ldx $d012               ; wait for the line before
        cpx irqB
        bcc -
        bne _w                  ; (the badline or later already: at once)
        ldx #BADDELAY
-       dex                     ; (5 cycles a loop)
        bne -
_w      sta $d000
        jmp IrqNextEv
BADDELAY    = 8
; the panel: its screen and colours (on line 215), the colour writes folded there (FoldEv) first
IrqStat
        #IrqPro
        ldx curBuf
        lda FoldN,x             ; the $D022 writes on the river's last lines (FoldEv's), each on
                                ; its line (a badline's at the end of the line before, as IrqBad);
        beq _x                  ; one on 215 is the panel's NMI's
        sta irqB
        ldy Mul3,x
_fl     ldx FoldL,y
        cpx #STATRASTER
        bcs _x
        lda FoldB,y
        bpl _wr
        dex
-       cpx $d012               ; (the line before reached: the delay; passed: at once)
        beq _bd
        bcs -
        bcc _go
_bd     ldx #BADDELAY
-       dex
        bne -
        beq _go
_wr
-       cpx $d012               ; (its line reached or passed)
        beq _go
        bcs -
_go     lda FoldV,y
        sta $d022
        iny
        dec irqB
        bne _fl
_x      jmp IrqNextEv
IrqLogo
        #IrqPro
        jsr EvLogo
        jmp IrqNextEv
; the frame's end: the next interrupt is the frame top
IrqEnd
        #IrqPro
        inc frameFlag
        lda #<IrqTop
        sta $fffe
        lda #>IrqTop
        sta $ffff
        lda #TOPRASTER
        sta $d012
        jmp IrqOut

EV_BLK      = $80
EV_STAT     = $a1
STATLEAD    = 4         ; (the panel's interrupt four lines ahead: with every sprite fetching
                        ; there the CPU gets ~30 cycles a line, and its way to line 215's
                        ; writes takes about two lines; two lines ahead it missed 215 now and
                        ; then and the panel broke up. Two lines ahead of FoldEv's writes too)
EV_LOGO     = $82
EV_END      = $7f
; by an event's kind (AddEv): its handler, its lead (the end: at once, armed on line 0)
IrqH        .function n
            .endf n == EV_END ? IrqEnd : n < $40 ? IrqWrite : n >= $c0 ? IrqBad : n == EV_STAT ? IrqStat : n == EV_LOGO ? IrqLogo : IrqEnd
IrqJLo      .for i := 0, i < 256, i += 1
            .byte <IrqH(i)
            .endfor
IrqJHi      .for i := 0, i < 256, i += 1
            .byte >IrqH(i)
            .endfor
LeadOf      .for i := 0, i < 256, i += 1
            .byte i == EV_END ? ENDRASTER : i == EV_LOGO ? 0 : i == EV_STAT ? STATLEAD : 2
            .endfor

; testing aids (DBGLOG: the border yellow and a log of the interrupt's lines from a frame top on,
; at entry and exit, DbgBorder $80: from the next frame top; DBGTIME: the interrupt's cycles)
DBGLOG      = 0
DbgIrqIn
        .if DBGTIME
-       lda $dc05
        ldx $dc04
        cmp $dc05
        bne -
        sta DbgTIH
        stx DbgTIL
        .endif
        .if DBGLOG
        lda DbgBorder
        beq +
        jsr DbgIrqLog
+
        .endif
        rts
DbgIrqOut
        .if DBGLOG
        lda DbgBorder
        beq +
        jsr DbgIrqOut2
+
        .endif
        .if DBGTIME
        jsr DbgIrqT
        .endif
        rts
DbgIrqLog
        lda $d020
        sta DbgB
        lda #7
        sta $d020
        lda DbgBorder
        bpl +
        lda $fffe               ; (the frame top's handler)
        cmp #<IrqTop
        bne ++
        lda DbgBorder
        and #$7f
        sta DbgBorder
        lda #0
        sta DbgLogI
+       ldx DbgLogI
        lda $d012
        sta DbgLog,x
        inc DbgLogI
+       rts
DbgIrqOut2
        lda DbgB
        sta $d020
        lda DbgBorder
        bmi +
        ldx DbgLogI
        lda $d012
        sta DbgLog,x
        inc DbgLogI
+       rts
DbgIrqT
-       lda $dc05
        ldx $dc04
        cmp $dc05
        bne -
        sta irqB
        txa
        eor #$ff
        sec
        adc DbgTIL
        tax
        lda DbgTIH
        sbc irqB
        tay
        txa
        clc
        adc DbgIrqC
        sta DbgIrqC
        tya
        adc DbgIrqC+1
        sta DbgIrqC+1
        bcc +
        inc DbgIrqC+2
        bne +
        inc DbgIrqC+3
+       rts

; Testing aid (DBGTIME): cycles by part, counted with CIA 1's timer A (free-running): DbgT0
; starts, DbgT1 adds the cycles since to the 24-bit counter at DbgAcc + Y (interrupts and the
; VIC's DMA included; the interrupt's own in DbgIrqC)
DBGTIME     = 0
DbgT0:
        .if DBGTIME
-       lda $dc05
        ldx $dc04
        cmp $dc05
        bne -
        sta DbgTH
        stx DbgTL
        .endif
        rts
DbgT1:
        .if DBGTIME
-       lda $dc05
        ldx $dc04
        cmp $dc05
        bne -
        sta tmp4
        txa
        eor #$ff
        sec
        adc DbgTL
        tax
        lda DbgTH
        sbc tmp4
        pha
        txa
        clc
        adc DbgAcc,y
        sta DbgAcc,y
        pla
        adc DbgAcc+1,y
        sta DbgAcc+1,y
        bcc +
        lda DbgAcc+2,y
        adc #0
        sta DbgAcc+2,y
        lda DbgAcc+3,y
        adc #0
        sta DbgAcc+3,y
+
        .endif
        rts


; F2: the power switch off and on. The TIA is cleared and the next tick starts at the 2600's
; power-on code, which clears its RAM; the console switches, the joysticks and the fire buttons
; stay as they are, as on a real 2600. The display catches up by itself.
PowerCycle:
        lda INPT4
        pha
        lda INPT5
        pha
        lda #0
        sta PowerReq
        ldx #2                  ; the TIA's registers ($02-$2E)
-       sta $00,x
        inx
        cpx #$30
        bne -
        sta INTIM
        pla
        sta INPT5
        pla
        sta INPT4
        lda #1
        sta firstTick
        lda DbgAuto             ; (testing aid: the self-playing game from its start, whenever the
        beq +                   ; power cycle came: the same game every time)
        lda #0
        sta AutoT
        sta AutoT+1
        sta AutoOver
        lda #1
        sta AutoR
        lda #$f0
        sta AutoSpeed
+       rts

; Replaces the 2600's "sta $00,x / txs / inx / bne" clearing loop (power-on, X = 0, and Game
; Reset, X = $F7; A = 0): clear the 2600 RAM from X up, but not the C64's zero page below $80.
ClearZP:
        cpx #$80
        bcs +
        ldx #$80
+
-       sta $00,x
        inx
        bne -
        rts

; ============================================================= setup code
DetectPal:
-       lda $d012
-       cmp $d012
        beq -
        bmi --
        ldx #0                  ; A = low byte of the last raster line: $37 on PAL
        cmp #$20
        bcc +
        inx
+       stx isPal
        sta LastLine
        txa                     ; the SID's pitch depends on the machine's clock
        bne +
        lda #<SidFreqLoN
        sta FreqTab
        lda #>SidFreqLoN
        sta FreqTab+1
+       rts

InitSound:
        ldx #$18
        lda #0
-       sta $d400,x
        dex
        bpl -
        lda #$8f                ; full volume, voice 3 off (it only syncs voice 1)
        sta $d418
        ldx #5
        lda #$ff
-       sta SndLast,x
        dex
        bpl -
        rts

; tables render.asm uses (here for room at $8000)
; a byte's high and low nibble's 4 pixels as a multicolour byte (Exp4 of each)
Exp4Hi:     .for i := 0, i < 256, i += 1
            .byte (i & $80 ? $c0 : 0) | (i & $40 ? $30 : 0) | (i & $20 ? $0c : 0) | (i & $10 ? $03 : 0)
            .endfor
Exp4Lo:     .for i := 0, i < 256, i += 1
            .byte (i & 8 ? $c0 : 0) | (i & 4 ? $30 : 0) | (i & 2 ? $0c : 0) | (i & 1 ? $03 : 0)
            .endfor
; a 2600 pixel's sprite X (24 + 2 * pixel): low byte, MSB
SprXLo:     .for i := 0, i < 160, i += 1
            .byte <(24 + 2 * i)
            .endfor
SprXHi:     .for i := 0, i < 160, i += 1
            .byte >(24 + 2 * i)
            .endfor
        .include "input.asm"
        .include "sound.asm"
        .include "collide.asm"
        .include "data.asm"
        .include "tables.inc"
        .cerror * > $4000, "the program runs into the VIC's bank ($4000)"
; (in the file from here on: copied to where they run by Relocate; Img8 must not start below
; $4000 + the part of it... it is copied after the 2600 image, which lies before it)
Img8:
        .logical CODE_8
        .include "render.asm"
        .include "sidtables.inc"
Img8End:
        .here
        .cerror Img8End > OBJRAM, "the code at $8000 runs into OBJRAM"
        .cerror StgCode + SGLEN * NSTAGE * NBUF > WORKRAM, "StgCode runs into the working variables"

        .include "vars.asm"
