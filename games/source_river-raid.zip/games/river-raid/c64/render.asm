; ================================================================== render
; Render: the picture for the state the ticks produced, staged in buffer rbuf for the frame top,
; with its list of events down the screen. (Runs at CODE_8.)
;
; The river: the VIC's vertical scroll is the kernel's scroll (Scroll & 7) and the character
; rows world-aligned: a block (32 lines) is four character rows (w 0-3, four playfield rows
; each), the same codes as long as the block is on the screen: a code is a column's four rows of
; land (bit 0 the top row: characters 0-15). Screen row j shows block 5 - n / 4, its row n & 3,
; for n = 3 - Scroll / 8 + j. Each eight lines of scroll every row moves down one: three screens
; take turns (one shown, one waiting to be, the next made), each row rewritten only when it
; changes, and the next screen's rows made ahead in the frames before.

; ---- the per-frame steps
Render:
        lda rbuf                ; the next buffer
        clc
        adc #1
        cmp #NBUF
        bcc +
        lda #0
+       sta rbuf
        tax
        lda EvBaseOf,x
        sta evN
        inc FrameNo
        jsr Phase
        jsr Rows
        jsr Colours
        jsr PlaneShot
        jsr Blocks
        jsr Panel
        jsr FoldEv              ; the panel: its screen and colours (waits for its line; the
        lda #STATRASTER         ; colour changes on the lines before it its own)
        ldx #EV_STAT
        jsr AddEv
        ldx rbuf                ; (armed three lines before the first of those, if earlier)
        lda FoldN,x
        beq +
        ldy Mul3,x
        lda FoldL,y
        sec
        sbc #3
        ldx evN
        cmp EvArm-1,x
        bcs +
        sta EvArm-1,x
+
        lda #NEEDLERASTER       ; the needle's colour, the logo's sprites
        ldx #EV_LOGO
        jsr AddEv
        lda #ENDRASTER
        ldx #EV_END
        jsr AddEv
        jmp Prebuild

; FoldEv: the events on raster lines FOLDRASTER on (the river's last lines: only $D022 writes)
; taken off the list into this buffer's FoldN / L / V / B: the panel's interrupt does them on
; their lines, then the panel (each with an interrupt of its own, chained with the sprites'
; fetches there, the panel's came too late for line 215 and the panel's rows broke up)
FOLDRASTER  = STATRASTER - 4
FoldEv:
        ldy rbuf
        lda EvBaseOf,y
        sta tmp2
        ldx evN                 ; (the first of them: at most three)
-       cpx tmp2
        beq +
        lda EvRas-1,x
        cmp #FOLDRASTER
        bcc +
        dex
        txa
        clc
        adc #3
        cmp evN
        bne -
+       stx tmp3
        lda Mul3,y
        tay
-       cpx evN
        beq +
        lda EvRas,x
        sta FoldL,y
        lda EvVal,x
        sta FoldV,y
        lda EvReg,x
        sta FoldB,y
        iny
        inx
        bne -
+       tya
        ldy rbuf
        sec
        sbc Mul3,y
        sta FoldN,y
        lda tmp3
        sta evN
        rts

; AddEv: an event at raster A: register / routine X (its kind: its handler and lead), value Y
AddEv:
        sty tmp3
        ldy evN
        sta EvRas,y
        sec
        sbc LeadOf,x
        sta EvArm,y
        lda IrqJLo,x
        sta EvLo,y
        lda IrqJHi,x
        sta EvHi,y
        txa
        sta EvReg,y
        lda tmp3
        sta EvVal,y
        inc evN
        rts

; ---- Phase: the scroll's eight-line phase (q8 = Scroll / 8) and the screen it takes (PhaseP:
; the phases counted mod 3, so consecutive ones take turns), the VIC's scroll, the panel's screen
Phase:
        ldx rbuf
        lda Scroll
        lsr
        lsr
        lsr
        sta q8
        sec
        sbc LastQ
        and #3
        clc
        adc PhaseP
-       cmp #3
        bcc +
        sbc #3
        bcs -
+       sta PhaseP
        sta StScr,x
        tay
        lda ScrD018,y
        sta StD018,x
        lda q8
        sta LastQ
        lda Scroll              ; the VIC's scroll; at 7 drawn as 6, the river one line up (the
        and #7                  ; colour events with it: rasOfs). At 7 line 215 would be the
        ldy #LINEOFS            ; river's last badline, and with sprites at the bottom their fetches
        cmp #7                  ; and its hold leave no cycle before 216's for the panel's switch
        bne +
        lda #6
        dey
+       sty rasOfs
        ora #$10                ; display on, 24 rows (the top border down to line 55)
        sta StD011,x
        and #7
        beq +
        lda #(STATA - $4000) / $400 * 16    ; (the panel's rows from row 20: the badline at
        sta StStat,x                        ; 216 starts it again; at scroll 0 the river's row
        rts                                 ; 20 ends at 215: from 21)
+       lda #(STATB - $4000) / $400 * 16
        sta StStat,x
        rts
ScrD018:    .byte (SCREEN0 - $4000) / $400 * 16, (SCREEN0 + $400 - $4000) / $400 * 16, (SCREEN0 + $800 - $4000) / $400 * 16

; ---- Rows: each block's playfield's slot (BlockSlot, when the blocks changed), the rows the
; frame wants (DesKey: a tag each, by the frame key q8 + the six slots), then screen PhaseP's rows
; that differ (none when it already has this frame key's).
; A row's codes are made once for its content, its signature: the four playfield rows' PF1 and
; PF2 bytes. The same content (another block, another of the block's rows) gets the same tag, so
; a screen row is rewritten only when what it shows changes. A slot's rows' tags: SlotRow (slot *
; 4 + w, $FF not known yet); a tag's codes are in a store (CodeCol, NSTORE of them), kept while a
; slot row has it (StoreRef). Tags are never reused for other content: when they run out, the
; stores' are renumbered (Retag).
Rows:
        lda NextTag             ; (tags running out: renumbered first)
        cmp #TAGMAX
        bcc +
        jsr Retag
+       lda #0
        sta SlotsMoved
        ldx #5                  ; the blocks' playfields as last frame: the same slots
-       lda BlkPF1,x
        cmp LastPF1,x
        bne _slots
        lda BlkPF2,x
        cmp LastPF2,x
        bne _slots
        lda BlkFlags,x
        eor LastPg,x
        and #3
        bne _slots
        dex
        bpl -
        jmp _keys
_slots  ldx #5                  ; (last frame's slots kept: did they move down one block?)
-       lda BSlot,x
        sta OldBS,x
        dex
        bpl -
        ldx #4                  ; the blocks moved down one (blocks 0-4 last frame's 1-5): their
-       lda BlkPF1,x            ; slots move with them, only block 5's looked for
        cmp LastPF1+1,x
        bne _each
        lda BlkPF2,x
        cmp LastPF2+1,x
        bne _each
        lda BlkFlags,x
        eor LastPg+1,x
        and #3
        bne _each
        dex
        bpl -
        ldx #0
-       lda BSlotPrev+1,x
        sta BSlotPrev,x
        bmi +
        tay
        lda FrameNo
        sta SlotUsed,y
+
        lda Slot4+1,x
        sta Slot4,x
        lda BSlot+1,x
        sta BSlot,x
        lda LastPF1+1,x
        sta LastPF1,x
        lda LastPF2+1,x
        sta LastPF2,x
        lda LastPg+1,x
        sta LastPg,x
        inx
        cpx #5
        bne -
        inc SlotsChg
        ldx #5
        jsr BlockSlot
        sta BSlot,x
        lda BlkPF1,x
        sta LastPF1,x
        lda BlkPF2,x
        sta LastPF2,x
        lda BlkFlags,x
        sta LastPg,x
        jmp _moved
_each   ldx #5
-       jsr BlockSlot
        cmp BSlot,x
        beq +
        sta BSlot,x
        inc SlotsChg
+
        lda BlkPF1,x
        sta LastPF1,x
        lda BlkPF2,x
        sta LastPF2,x
        lda BlkFlags,x
        sta LastPg,x
        dex
        bpl -
_moved  ldx #4
-       lda BSlot,x
        cmp OldBS+1,x
        bne _keys
        dex
        bpl -
        inc SlotsMoved          ; (yes)
_keys   lda #0
        sta PreOK
        lda q8                  ; the rows wanted: again when the phase or a slot changed (a new
        cmp DesQ                ; frame key FKid)
        bne +
        lda SlotsChg
        bne _des
        jmp _scr
+       ldx DesQ                ; (none yet: all)
        bmi _des
        sec                     ; the river eight lines on (the next phase; at its wrap the blocks
        sbc DesQ                ; moved down one, nothing else): the rows move down one, a new
        and #3                  ; top row (block 5's row 3 - q8)
        cmp #1
        bne _des
        lda q8
        bne +
        lda SlotsMoved
        beq _des
        bne ++
+       lda SlotsChg
        bne _des
+       lda #0
        sta SlotsChg
        sta SlotsMoved
        lda q8
        sta DesQ
        lda FKid                ; (its screen made ahead with the last key: rows 1-20 right)
        sta PreKey
        inc PreOK
        jsr NewKey
        ldx #19
-       lda DesKey,x
        sta DesKey+1,x
        dex
        bpl -
        lda #3
        sec
        sbc q8
        ora Slot4+5
        tax
        lda SlotRow,x
        cmp #$ff
        bne +
        jsr RowMake
+       sta DesKey
        jmp _scr
_des    lda q8
        sta DesQ
        lda #0
        sta SlotsChg
        sta SlotsMoved
        jsr NewKey
        .for b := 0, b < 6, b += 1      ; (n: block 5 - n / 4, its row n & 3: slot row KofN)
        lda Slot4 + b
        sta KofN + 4 * (5 - b)
        ora #1
        sta KofN + 4 * (5 - b) + 1
        eor #3
        sta KofN + 4 * (5 - b) + 2
        ora #1
        sta KofN + 4 * (5 - b) + 3
        .endfor
        lda #3                  ; row j: n = 3 - q + j
        sec
        sbc q8
        tay
        ldx #0
-       stx v5
        lda KofN,y
        tax
        lda SlotRow,x
        cmp #$ff
        bne +
        sty v3
        jsr RowMake
        ldy v3
+       ldx v5
        sta DesKey,x
        iny
        inx
        cpx #21
        bne -
_scr    ldx PhaseP              ; the screen: already this key's?
        lda FKid
        cmp ScrId,x
        bne _copy
        rts
_copy   sta ScrId,x             ; its rows that differ (made ahead for the last key, rows moved
        lda Mul3,x              ; down one: only row 0)
        sta v7
        lda Mul21,x
        clc
        adc #20
        tay
        ldx #20
        lda PreOK
        beq _rows
        ldx PhaseP
        lda PreKey
        cmp PreId,x
        bne +
        lda PreJ,x
        cmp #21
        bcc +
        lda Mul21,x
        tay
        ldx #0
        beq _rows
+       ldx PhaseP
        lda Mul21,x
        clc
        adc #20
        tay
        ldx #20
_rows
-       lda DesKey,x
        cmp RowKey,y
        beq +
        sta RowKey,y
        stx v5
        sty v6
        jsr CopyRowT
        ldx v5
        ldy v6
+       dey
        dex
        bpl -
        rts
Slot4:  .fill 6                 ; (BSlot * 4: kept by BlockSlot)

; CopyRowT: row v5 of the screen whose copy routines start at v7 gets tag A's codes
CopyRowT:
        tay
        lda TagStore,y
        sta tmp4
        ldy v5
        lda GrpOfRow,y
        clc
        adc v7
        tay
        lda CopyLo,y
        sta _cj+1
        lda CopyHi,y
        sta _cj+2
        ldy v5
        lda YOfRow,y
        tay
        ldx tmp4
_cj     jmp $0000

; frames until the next phase (scroll & 7 = p, speed v 1-4): ceil((8 - p) / v), by p * 4 + v - 1
PreFrames:  .for i := 0, i < 32, i += 1
            .byte (8 - (i >> 2) + (i & 3)) / ((i & 3) + 1)
            .endfor
; Prebuild: the next phase's screen ((PhaseP + 1) mod 3), when no buffer shown or waiting has
; it: its row j becomes this phase's row j - 1 (the river goes on down; the top row comes with
; the phase), what is left spread over the frames until the phase changes, at most PREMAX rows a
; frame (PreJ: the next row; again from 1 for a new key)
PREMAX      = 5
Prebuild:
        ldx PhaseP
        inx
        cpx #3
        bcc +
        ldx #0
+       stx v4                  ; (the screen)
        sei                     ; in use by the buffer shown or one waiting?
        txa
        ldy curBuf
        cmp StScr,y
        beq _bsy
        ldy QCount
        beq _free
-       ldx Queue-1,y
        cmp StScr,x
        beq _bsy
        dey
        bne -
        beq _free
_bsy    cli
        rts
_free   cli
        ldx v4                  ; (for this frame key? else from row 1 again)
        lda FKid
        cmp PreId,x
        beq _go
        sta PreId,x
        lda #1
        sta PreJ,x
_go     ldx v4
        lda PreJ,x
        cmp #21
        bcs _pd
        sta v5
        lda Mul3,x
        sta v7
        lda Mul21,x
        clc
        adc v5
        tay
        sty v6
        lda Scroll              ; (rows a frame: what is left over the frames until the next
        sec                     ; phase, by the scroll's speed since last frame)
        sbc PreScr
        and #31
        bne +
        lda #1
+       cmp #5
        bcc +
        lda #4
+       sta tmp
        lda Scroll
        sta PreScr
        and #7
        asl
        asl
        ora tmp
        tay
        lda PreFrames-1,y       ; (frames left)
        sta tmp
        lda #21
        sec
        sbc v5
        ldy #0                  ; (rows: ceil(left / frames))
-       iny
        sec
        sbc tmp
        beq +
        bcs -
+       cpy #PREMAX + 1         ; (at most PREMAX)
        bcc +
        ldy #PREMAX
+       sty v3
        ldy v6
        ldx v5
_pr     lda DesKey-1,x
        cmp RowKey,y
        beq _pn
        sta RowKey,y
        stx v5
        sty v6
        jsr CopyRowT
        ldx v5
        ldy v6
        dec v3
        beq _px
_pn     iny
        inx
        cpx #21
        bne _pr
        stx v5
_px     ldx v4
        lda v5
        sta PreJ,x
_pd     rts

; BlockSlot: block X's codes: their slot (A; X kept). Cached by the block's playfield (PF1 / PF2
; pointers and pages): the slot it had last frame, the one above's (the blocks move down one
; when the scroll wraps), any; else the slot used longest ago is given it.
BlockSlot:
        lda BlkFlags,x
        and #3
        sta tmp2
        ldy BSlotPrev,x
        bmi +
        jsr _same
        beq _hit
+       cpx #5
        beq +
        ldy BSlotPrev+1,x
        bmi +
        jsr _same
        beq _hit
+       ldy #CSLOTS - 1
-       jsr _same
        beq _hit
        dey
        bpl -
        ldy #0                  ; none: the slot used longest ago (not this frame)
        sty tmp3
        lda #0
        sta tmp4
-       lda FrameNo
        sec
        sbc SlotUsed,y
        beq +
        cmp tmp4
        bcc +
        sta tmp4
        sty tmp3
+       iny
        cpy #CSLOTS
        bne -
        ldy tmp3
        jsr NewSlot
_hit    lda FrameNo
        sta SlotUsed,y
        tya
        sta BSlotPrev,x
        asl
        asl
        sta Slot4,x
        tya
        rts
_same   lda SlotPF1,y           ; (Z set: slot Y holds block X's playfield)
        cmp BlkPF1,x
        bne +
        lda SlotPF2,y
        cmp BlkPF2,x
        bne +
        lda SlotPg,y
        cmp tmp2
+       rts

; NewSlot: slot Y is block X's (X, Y kept): its playfield, its rows' tags let go
NewSlot:
        lda BlkPF1,x
        sta SlotPF1,y
        lda BlkPF2,x
        sta SlotPF2,y
        lda tmp2
        sta SlotPg,y
        lda PP1Lo,x             ; (the playfield's pointers: BlockSetup's)
        sta SlotP1Lo,y
        lda PP1Hi,x
        sta SlotP1Hi,y
        lda PP2Lo,x
        sta SlotP2Lo,y
        lda PP2Hi,x
        sta SlotP2Hi,y
        stx v0
        sty v1
        tya
        asl
        asl
        tax
        ldy #4
-       lda SlotRow,x           ; (each row's store: one holder less)
        cmp #$ff
        beq +
        stx tmp
        tax
        lda TagStore,x
        tax
        dec StoreRef,x
        ldx tmp
        lda #$ff
        sta SlotRow,x
+       inx
        dey
        bne -
        inc SlotsChg            ; (the rows wanted: again, even if the slots look the same)
        ldx v0
        ldy v1
        rts

; RowMake: slot row X (slot * 4 + w) -> A its tag: a store with its content if any, else a new
; store (one no slot row holds) made for it
RowMake:
        stx v2
        txa
        lsr
        lsr
        tay
        lda SlotP1Lo,y
        sta ptrA
        lda SlotP1Hi,y
        sta ptrA+1
        lda SlotP2Lo,y
        sta ptrB
        lda SlotP2Hi,y
        sta ptrB+1
        txa                     ; (rows 15 - 4w - i)
        and #3
        asl
        asl
        eor #$ff
        sec
        adc #15
        tay
        .for i := 0, i < 4, i += 1     ; the signature
        lda (ptrA),y
        sta cw0 + i
        lda (ptrB),y
        sta cw0 + 4 + i
        dey
        .endfor
        lda #0                  ; its hash
        .for i := 0, i < 8, i += 1
        asl
        adc #0
        eor cw0 + i
        .endfor
        sta tmp3
        tax                     ; a store with it?
        ldy HashTab,x
        cpy #$ff
        beq _new
        ldx TagStore,y
        tya
        cmp StoreTag,x
        bne _new
        .for i := 0, i < 8, i += 1
        lda cw0 + i
        cmp StoreSig + NSTORE * i,x
        bne _new
        .endfor
        tya                     ; (tag Y, store X)
        jmp _use
_new    ldx Clock               ; a new store: one no slot row holds, from the clock on
-       inx
        txa
        and #NSTORE - 1
        tax
        lda StoreRef,x
        bne -
        stx Clock
        ldy StoreTag,x          ; (its old tag out of the hash table)
        cpy #$ff
        beq +
        lda StoreHash,x
        tay
        lda HashTab,y
        cmp StoreTag,x
        bne +
        lda #$ff
        sta HashTab,y
+       ldy NextTag             ; its new tag
        inc NextTag
        tya
        sta StoreTag,x
        txa
        sta TagStore,y
        tya
        ldy tmp3
        sta HashTab,y
        tya
        sta StoreHash,x
        .for i := 0, i < 8, i += 1
        lda cw0 + i
        sta StoreSig + NSTORE * i,x
        .endfor
        stx v1
        jsr MakeW
        ldx v1
        lda StoreTag,x
_use    inc StoreRef,x
        ldx v2
        sta SlotRow,x
        rts

; MakeW: store X's codes from the signature in cw0-cw7 (each column 4-19 its four playfield
; rows' land: PF1 bit 7 column 4 ... PF2 bit 0 column 12; rows 15 - 4w - i as bit i). Clears cw.
MakeW:
        .for k := 0, k < 8, k += 1
        lda #0
        asl cw0 + 3
        rol a
        asl cw0 + 2
        rol a
        asl cw0 + 1
        rol a
        asl cw0
        rol a
        sta CodeColA + NSTORE * k,x
        .endfor
        .for k := 0, k < 8, k += 1
        lda #0
        lsr cw0 + 7
        rol a
        lsr cw0 + 6
        rol a
        lsr cw0 + 5
        rol a
        lsr cw0 + 4
        rol a
        sta CodeColB + NSTORE * k,x
        .endfor
        rts

; Retag: the tags running out: each store's tag becomes its number (the slots' rows and the
; screens' rows renumbered with them; a tag no store has any more: unknown), new ones from NSTORE
Retag:
        ldx #NSTORE - 1         ; (TagStore by the old tags, for the stores that have one)
-       ldy StoreTag,x
        cpy #$ff
        beq +
        txa
        sta TagStore,y
+       dex
        bpl -
        ldx #NSTORE * 4 - 1
-       lda SlotRow,x
        jsr _map
        sta SlotRow,x
        dex
        bpl -
        ldx #3 * 21 - 1
-       lda RowKey,x
        jsr _map
        sta RowKey,x
        dex
        bpl -
        ldx #0                  ; the hash table again
        lda #$ff
-       sta HashTab,x
        inx
        bne -
        ldx #NSTORE - 1
-       lda StoreTag,x
        cmp #$ff
        beq +
        txa
        sta StoreTag,x
        sta TagStore,x
        ldy StoreHash,x
        sta HashTab,y
+       dex
        bpl -
        lda #NSTORE
        sta NextTag
        inc SlotsChg            ; (the rows wanted, the screens': looked at again; DesKey's tags
        lda #$ff                ; are old ones: no moving them down)
        sta DesQ
        jmp NoKeys
_map    cmp #$ff                ; (old tag A -> its store's number, $FF if none has it; X kept)
        beq _r
        sta tmp
        tay
        lda TagStore,y
        cmp #NSTORE
        bcs _nm
        tay
        lda StoreTag,y
        cmp tmp
        bne _nm
        tya
        rts
_nm     lda #$ff
_r      rts

; NewKey: a new frame key (FKid; past $FE: from 0, no screen made for any)
NewKey: ldx FKid
        inx
        cpx #$ff
        bne +
        jsr NoKeys
        ldx #0
+       stx FKid
        rts

; NoKeys: no screen made for any frame key (FKid starts again)
NoKeys: lda #$ff
        ldx #2
-       sta ScrId,x
        sta PreId,x
        dex
        bpl -
        rts

; InitRows: no stores, tags or slot rows yet
InitRows:
        lda #$ff
        ldx #0
-       sta HashTab,x
        inx
        bne -
        ldx #NSTORE - 1
-       sta StoreTag,x
        dex
        bpl -
        ldx #CSLOTS * 4 - 1
-       sta SlotRow,x
        dex
        bpl -
        lda #0
        sta NextTag
        sta Clock
        ldx #NSTORE - 1
-       sta StoreRef,x
        dex
        bpl -
        rts

; the row copies: X = the codes' store, Y = 40 * (row - 7 * group); one routine
; per screen and group of seven rows: columns 4-19 and, mirrored, 35-20
CopyRow .macro scr, grp
        .for k := 0, k < 16, k += 1
        .if k < 8
        lda CodeColA + NSTORE * k,x
        .else
        lda CodeColB + NSTORE * (k - 8),x
        .endif
        sta \scr + 280 * \grp + 4 + k,y
        sta \scr + 280 * \grp + 35 - k,y
        .endfor
        rts
        .endm
Copy00  #CopyRow SCREEN0, 0
Copy01  #CopyRow SCREEN0, 1
Copy02  #CopyRow SCREEN0, 2
Copy10  #CopyRow SCREEN0 + $400, 0
Copy11  #CopyRow SCREEN0 + $400, 1
Copy12  #CopyRow SCREEN0 + $400, 2
Copy20  #CopyRow SCREEN0 + $800, 0
Copy21  #CopyRow SCREEN0 + $800, 1
Copy22  #CopyRow SCREEN0 + $800, 2
CopyLo:     .byte <Copy00, <Copy01, <Copy02, <Copy10, <Copy11, <Copy12, <Copy20, <Copy21, <Copy22
CopyHi:     .byte >Copy00, >Copy01, >Copy02, >Copy10, >Copy11, >Copy12, >Copy20, >Copy21, >Copy22
GrpOfRow:   .byte 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2
YOfRow:     .byte 0, 40, 80, 120, 160, 200, 240, 0, 40, 80, 120, 160, 200, 240, 0, 40, 80, 120, 160, 200, 240
BOfN:       .fill 4, 5
            .fill 4, 4
            .fill 4, 3
            .fill 4, 2
            .fill 4, 1
            .fill 4, 0
Mul21:      .byte 0, 21, 42
Mul6:       .for i := 0, i < OBJN, i += 1
            .byte 6 * i
            .endfor
Mul7:       .byte 0, 7, 14
Mul3:       .byte 0, 3, 6

; ---- Colours: this frame's C64 colours (the river, the panel's)
Colours:
        ldx rbuf
        .for src, dst in [(COLUBK, StD021), (ColPanel, StPanelBg), (ColGauge, StGauge), (ColPlane, StDigit), (COLUP0, StPlane), (ColNeedle, StNeedle)]
        lda src
        lsr
        tay
        lda ColorMap,y
        sta dst,x
        .endfor
        rts
; C64Col: 2600 colour A -> C64 colour A (X, Y kept)
C64Col:
        sty cy
        lsr
        tay
        lda ColorMap,y
        ldy cy
        rts
; MaskCol: 2600 colour A through the colour masks, as a C64 colour (X, Y kept)
MaskCol:
        eor ColEor
        and ColAnd
        jmp C64Col

; ---- Blocks: down the screen, the banks' colour changes (events: $D022 on their line; a
; block's first line is a badline: the end of the line before) and each block's object (an
; event two lines before its first line: its sprites)
Blocks:
        ; the banks' colours as C64 colours (the greens, the road's rows), when the masks change
        lda ColEor
        cmp ColK1
        bne +
        lda ColAnd
        cmp ColK2
        bne +
        jmp _cols
+       lda ColEor
        sta ColK1
        lda ColAnd
        sta ColK2
        ldx #NSTAGE * NBUF - 1  ; (the stages' entries: not for these masks)
        lda #$ff
-       sta SgKE,x
        dex
        bpl -
        lda #$d2
        jsr MaskCol
        sta EEC
        lda #$d6
        jsr MaskCol
        sta EEC+1
        ldy #12
-       lda T_ROAD,y
        jsr MaskCol
        cmp #1                  ; (the road's grey, white in the table: light grey in colour, as
        bne +                   ; the 2600's; in black and white it stays apart from the land)
        ldx ColEor
        bne +
        ldx ColAnd
        inx
        bne +
        lda #15
+       sta RoadC,y
        dey
        bpl -
        ldx #0                  ; (the rows 11-1 whose colour isn't the row above's: RoadChg, 0 ends)
        ldy #11
-       lda RoadC,y
        cmp RoadC+1,y
        beq +
        tya
        sta RoadChg,x
        inx
+       dey
        bne -
        lda #0
        sta RoadChg,x
        lda #6                  ; (the same as a list of lines o 30 - 2 * row and colours)
        sta RoadO
        lda RoadC+12
        sta RoadV
        ldx #0
-       ldy RoadChg,x
        beq +
        lda RoadC,y
        sta RoadV+1,x
        tya
        asl
        eor #$ff
        sec
        adc #30
        sta RoadO+1,x
        inx
        bne -
+       lda #0
        sta RoadO+1,x
_cols  ; the top line's colour (the vertical blank's: Scroll 0-2 block 4's; block 5's road row)
        ldx #5
        lda Scroll
        lsr
        tay                     ; (the top line's row)
        lda BlkFlags+5
        bpl _ee
        cpy #13
        bcs _ee
        lda RoadC,y
        jmp _top
_ee     lda Scroll
        cmp #3
        bcs +
        dex
+       lda BlkFlags,x
        and #4
        lsr
        lsr
        tay
        lda EEC,y
_top    sta curCol
        ldx rbuf
        sta StD022,x
        lda Scroll              ; (the blocks moved down one since: BlkBase + 1, mod 7)
        sec
        sbc LastScroll
        bpl +
        cmp #-16
        bcs +
        ldy BlkBase
        iny
        cpy #7
        bcc ++
        ldy #0
        beq ++
+       ldy BlkBase
+       sty BlkBase
        lda Scroll
        sta LastScroll
        lda #5
        sta blk
_blk    ldx blk
        ldy BlkType,x           ; its object, if it has pixels: its sprites and their event
        lda TypeRowLo,y
        beq +
        jsr BlockObject
        ldx blk
+       lda BlkO0,x             ; its first line: the block's colour
        sta lineL
        cmp #198
        bcs _end
        cmp #38
        bcc +
        lda BlkFlags,x
        and #4
        lsr
        lsr
        tay
        lda EEC,y
        jsr ColEv
        ldx blk
+       lda BlkFlags,x          ; a road: by its rows 12-1 (lines o 30 - 2 * row): the first on
        bpl _nb                 ; the screen (line 38 on), then those whose colour changes
        lda BlkO0,x
        cmp #8 + 2 * 12
        bcs _rall
        sbc #8 - 1              ; (carry clear: - 8)
        bcc _nb                 ; (none: the block's top above line 8 ... its rows from (o0 - 8) / 2)
        lsr
        beq _nb
        sta v5
        ldy #$ff
_road   sty v4
        lda v5
        asl
        eor #$ff
        sec
        adc #30
        clc
        adc BlkO0,x
        sta lineL
        cmp #198
        bcs _end
        ldy v5
        lda RoadC,y
        jsr ColEv
        ldx blk
        ldy v4
-       iny                     ; (the next row that changes, below this one)
        lda RoadChg,y
        beq _nb
        cmp v5
        bcs -
        sta v5
        bcc _road
_nb     dec blk
        bpl _blk
_end    rts
_rall   ldy #0                  ; (the whole road on the screen: its list, ColEv's work inline:
_rf     lda RoadO,y             ; never on a badline)
        beq _rx
        clc
        adc BlkO0,x
        cmp #198
        bcs _end
        sta tmp
        lda RoadV,y
        cmp curCol
        beq _rn
        sta curCol
        ldx evN
        sta EvVal,x
        lda tmp
        clc
        adc rasOfs
        sta EvRas,x
        sbc #1                  ; (carry clear: - 2)
        sta EvArm,x
        lda #$22
        sta EvReg,x
        lda #<IrqWrite
        sta EvLo,x
        lda #>IrqWrite
        sta EvHi,x
        inc evN
        ldx blk
_rn     iny
        bne _rf
_rx     jmp _nb

; ColEv: C64 colour A from line lineL on: an event if it is new
ColEv:
        cmp curCol
        bne +
        rts
+       sta curCol
        ldx evN                 ; (AddEv's, for a $D022 write: 2 lines ahead; on a badline, o & 7
        sta EvVal,x             ; = 0, at the end of the line before)
        lda lineL
        clc
        adc rasOfs              ; (LINEOFS; less one at scroll 7: Phase)
        sta EvRas,x
        sec
        sbc #2
        sta EvArm,x
        lda lineL
        sec
        sbc sb5
        and #7
        beq +
        lda #$22
        sta EvReg,x
        lda #<IrqWrite
        sta EvLo,x
        lda #>IrqWrite
        sta EvHi,x
        inc evN
        rts
+       lda #$c0 + $22
        sta EvReg,x
        lda #<IrqBad
        sta EvLo,x
        lda #>IrqBad
        sta EvHi,x
        inc evN
        rts

; StageX: sprite 2 + i's X in the stage's code (ptrD), if on (the MSBs in v6)
StageX  .macro i
        lda v5
        and #4 << \i
        beq _off
        ldx v4
        lda ObjXOff + \i,x
        clc
        adc v2
        cmp #160
        bcc +
        lda #159
+       tax
        lda SprXHi,x
        beq +
        lda v6
        ora #4 << \i
        sta v6
+       lda SprXLo,x
        ldy #SG_P + 16 * \i + 1
        sta (ptrD),y
_off
        .endm

; StageSpr: sprite 2 + i in the stage's code (ptrD): if on, its X (24 + 2 * (pixel + offset)),
; colour and pointer; off: skipped (bvc over its 15 bytes)
StageSpr .macro i
        lda v5
        and #4 << \i
        beq _off
        ldx v4
        lda ObjXOff + \i,x
        clc
        adc v2
        cmp #160
        bcc +
        lda #159                ; (past the line's end the 2600 wraps it into the comb: not us)
+       tax
        lda SprXHi,x
        beq +
        lda v6
        ora #4 << \i
        sta v6
+       lda SprXLo,x
        ldy #SG_P + 16 * \i + 1
        sta (ptrD),y
        dey
        lda #$a9                ; (lda #)
        sta (ptrD),y
        ldx v4
        lda ObjCol + \i,x
        ldy #SG_P + 16 * \i + 6
        sta (ptrD),y
        lda ObjPtr + \i,x
        ldy #SG_P + 16 * \i + 11
        sta (ptrD),y
        jmp _done
_off    ldy #SG_P + 16 * \i
        lda #$50                ; (bvc: V is clear)
        sta (ptrD),y
        iny
        lda #14
        sta (ptrD),y
_done
        .endm

; BlockObject: block X's object, if any of it is on the screen: its images (ObjImage), its
; sprites staged (stage stageN: X, colours, pointers of those on; the Y of the upper sprites
; (o 6) and the lower (o 27), the shared colours) and the event that sets them, on its line o -2
BlockObject:
        lda BlkO0,x             ; its lines o 6-29 on the screen? (o 29 on the top line isn't
        clc                     ; drawn)
        adc #29
        cmp #38
        bcc _nob
        lda BlkO0,x
        clc
        adc #6
        cmp #198
        bcc +
_nob    rts
+       stx v0
        txa                     ; (its stage, and its hints: the block's (BlkBase), kept while it
        clc                     ; moves down the screen)
        adc BlkBase
        tay
        lda Mod7,y
        sta oBK
        ldy rbuf
        clc
        adc StageOf,y
        sta stageN
        tax                     ; its entry: the stage's, if the same type and NUSIZ (the stages'
        ldy v0                  ; entries are forgotten when the colour masks change)
        lda BlkType,y
        cmp SgKT,x
        bne _img
        lda BlkFine,y
        and #15
        cmp SgKN,x
        bne _img
        lda P1Pos,y             ; (the same pixel too: nothing new, just its event)
        cmp SgKP,x
        bne _kx
        ldy SgKE,x
        bmi _img
        lda FrameNo
        sta ObjUsed,y
        jmp _ev
_kx     ldy SgKE,x
        bmi _img
        lda FrameNo
        sta ObjUsed,y
        jmp +
_img    ldx v0
        jsr ObjImage            ; (Y = its entry)
+       sty v1
        ldx stageN              ; the stage's code
        lda StgLo,x
        sta ptrD
        lda StgHi,x
        sta ptrD+1
        lda v1                  ; the stage as this buffer last had it (entry, pixel): nothing new
        cmp SgKE,x              ; (its Y registers: the interrupt's, by the event's line); the
        beq +                   ; same entry: only the X registers
        jmp _all
+       ldy v0
        lda P1Pos,y
        cmp SgKP,x
        bne +
        jmp _ev
+       sta SgKP,x
        sta v2
        ldx v1
        lda ObjEn,x
        sta v5
        lda Mul6,x
        sta v4
        lda #0
        sta v6
        #StageX 0
        #StageX 1
        #StageX 2
        #StageX 3
        #StageX 4
        #StageX 5
        jmp _msb
_all    sta SgKE,x
        ldy v0
        lda BlkType,y
        sta SgKT,x
        lda BlkFine,y
        and #15
        sta SgKN,x
        lda P1Pos,y
        sta SgKP,x
        sta v2                  ; (its pixel)
        ldx v1                  ; the entry's colours, sprites on, expanded
        lda ObjM1,x
        ldy #SG_M1
        sta (ptrD),y
        lda ObjM2,x
        ldy #SG_M2
        sta (ptrD),y
        lda ObjExp,x
        ldy #SG_EXP
        sta (ptrD),y
        lda ObjEn,x
        sta v5                  ; (bits 2-7)
        lda Mul6,x
        sta v4                  ; (the entry's sprites)
        lda #0
        sta v6                  ; (MSBs)
        #StageSpr 0
        #StageSpr 1
        #StageSpr 2
        #StageSpr 3
        #StageSpr 4
        #StageSpr 5
        lda v5                  ; (sprites 2-7 on; the interrupt adds the plane's and the shot's)
        ldy #SG_EN
        sta (ptrD),y
_msb    lda v6                  ; (their MSBs; the interrupt adds the plane's and the shot's)
        ldy #SG_MSB
        sta (ptrD),y
_ev     ldy v0                  ; the event, two lines above its first
        lda BlkO0,y
        clc
        adc #LINEOFS - 2
        ldx evN                 ; (its handler: the stage's code, on its line)
        sta EvRas,x
        sta EvArm,x
        ldy stageN
        lda StgLo,y
        sta EvLo,x
        lda StgHi,y
        sta EvHi,x
        inc evN
        rts
Mod7:   .byte 0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6

; the stages' code (StgCode + SGLEN * stage): the block's sprites set, then on to the next event
; (the bytes marked are set by BlockObject)
; It is the interrupt's handler (IrqPro first). The Y registers: the event's line (o -2) + 7
; (o 6 - 1 + LINEOFS), + 21 more for the lower ones (testing aid: a move on or after the upper
; sprites' first line on the screen counted in DbgMoveLate); the pointers: in the screen shown
; (irqP).
SG_MSB      = IRQPRO + 44
SG_EN       = SG_MSB + 7
SG_EXP      = SG_EN + 7
SG_M1       = SG_EXP + 5
SG_M2       = SG_M1 + 5
SG_P        = SG_M2 + 5
SGLEN       = SG_P + 6 * 16 + 3
StgTpl      .byte $85, irqSA, $86, irqSX, $84, irqSY, $d8, $0e, $19, $d0
            .if DBGTIME || DBGLOG
            .byte $20, <DbgIrqIn, >DbgIrqIn
            .endif
            .byte $a5, irqT, $18, $69, 7
            .byte $cd, $12, $d0, $b0, 12, $c9, 55 - 1, $90, 8, $ee, <DbgMoveLate, >DbgMoveLate, $d0, 3, $ee, <(DbgMoveLate + 1), >(DbgMoveLate + 1)
            .byte $8d, $05, $d0, $8d, $07, $d0, $8d, $09, $d0, $8d, $0b, $d0
            .byte $18, $69, 21, $8d, $0d, $d0, $8d, $0f, $d0
            .byte $a9, 0, $05, irqPM, $8d, $10, $d0
            .byte $a9, 0, $05, irqPE, $8d, $15, $d0
            .byte $a9, 0, $8d, $1d, $d0
            .byte $a9, 0, $8d, $25, $d0
            .byte $a9, 0, $8d, $26, $d0
            .byte $b8                       ; (clv)
            .for i := 0, i < 6, i += 1
            .byte $50, 14, $8d, <($d004 + 2 * i), $d0, $a9, 0, $8d, <($d029 + i), $d0, $a9, 0, $a0, 2 + i, $91, irqP
            .endfor
            .byte $4c, <IrqNextEv, >IrqNextEv
            .cerror * - StgTpl != SGLEN, "StgTpl's length"
StgLo       .for i := 0, i < NSTAGE * NBUF, i += 1
            .byte <(StgCode + SGLEN * i)
            .endfor
StgHi       .for i := 0, i < NSTAGE * NBUF, i += 1
            .byte >(StgCode + SGLEN * i)
            .endfor

; InitStages: every stage's code from the template, nothing staged
InitStages:
        ldx #NSTAGE * NBUF - 1
-       lda StgLo,x
        sta ptrD
        lda StgHi,x
        sta ptrD+1
        ldy #SGLEN - 1          ; (more than 128)
-       lda StgTpl,y
        sta (ptrD),y
        dey
        cpy #$ff
        bne -
        lda #$ff
        sta SgKE,x
        dex
        bpl --
        rts

; ---- the objects' images: OBJN entries, each up to six sprites (upper: sprites 2-5, lines
; o 6-26; lower: 6-7, o 27-29), by type, NUSIZ (with the reflection) and the colour masks; made
; when first needed (the entry used longest ago taken: never one of the last frames')
; ObjImage: block X's object -> Y its entry
ObjImage:
        lda BlkType,x
        sta okT
        lda BlkFine,x
        and #15
        sta okN
        ldx oBK                 ; (the block's last two: an animation's two images)
        ldy ObjHint,x
        jsr _okey
        beq _got2
        ldy ObjHint2,x
        jsr _okey
        beq _got
        ldy #OBJN - 1
-       lda ObjKT,y
        cmp okT
        bne +
        lda ObjKN,y
        cmp okN
        bne +
        lda ObjKE,y
        cmp ColEor
        bne +
        lda ObjKA,y
        cmp ColAnd
        beq _got
+       dey
        bpl -
        jsr ObjVictim
        jsr MakeObj
_got    lda FrameNo
        sta ObjUsed,y
        lda ObjHint,x
        sta ObjHint2,x
        tya
        sta ObjHint,x
        ldx v0
        rts
_got2   lda FrameNo
        sta ObjUsed,y
        ldx v0
        rts
_okey   lda ObjKT,y             ; (Z set: entry Y is the object's)
        cmp okT
        bne +
        lda ObjKN,y
        cmp okN
        bne +
        lda ObjKE,y
        cmp ColEor
        bne +
        lda ObjKA,y
        cmp ColAnd
+       rts

; the sprite blocks besides BLK_OBJ on: past the characters used, the panel screens' rows not shown
XtraBlk:    .byte 28, 29, 30, 31, 88, 89, 90, 91, 104, 105, 106, 107
BLK_COMB    = 108       ; (and one more there: the comb on the panel's last three lines, sprite 2)
XTRAN       = * - XtraBlk

; PreObj: the images of the objects the game shows in play (the colour masks 0 / $FF) made ahead
; and kept (pinned): no image is made in play (in colour; MakeObj leaves the pin on: in black and
; white those made then stay too)
PreObj:
        lda #0
        sta ColEor
        lda #$ff
        sta ColAnd
        ldx #0
-       stx oPK
        lda PreKT,x
        sta okT
        lda PreKN,x
        sta okN
        jsr ObjVictim
        jsr MakeObj
        lda #1
        sta ObjPin,y
        lda #0
        sta ObjUsed,y
        ldx oPK
        inx
        cpx #PREN
        bne -
        rts
PreKT:      .byte 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 9, 9, 10
PreKN:      .byte 0, 1, 5, 7, 8, 13, 0, 1, 5, 7, 8, 13, 0, 1, 5, 7, 8, 13, 0, 8, 0, 8, 0, 8, 5, 13, 7, 5, 13, 0
PREN        = * - PreKN

; ObjVictim: an entry to make (Y): an empty one, else the one used longest ago that isn't pinned
; and none of the last NBUF frames used (none such: the longest ago)
ObjVictim:
        ldy #OBJN - 1
-       lda ObjKT,y
        cmp #$ff
        beq _v
        dey
        bpl -
        lda #$ff
        sta tmp3
        lda #NBUF - 1
        sta tmp4
        ldy #OBJN - 1
-       jsr Pinned
        bne +
        lda FrameNo
        sec
        sbc ObjUsed,y
        cmp tmp4
        bcc +
        beq +
        sta tmp4
        sty tmp3
+       dey
        bpl -
        ldy tmp3
        bpl _v
        ldy #0                  ; (none such)
        sty tmp3
        sty tmp4
-       lda FrameNo
        sec
        sbc ObjUsed,y
        cmp tmp4
        bcc +
        sta tmp4
        sty tmp3
+       iny
        cpy #OBJN
        bne -
        ldy tmp3
_v      rts

; Pinned: entry Y kept (pinned, and made with the colour masks now: in black and white the
; colour images go, then those made stay)? Z clear if so
Pinned  lda ObjPin,y
        beq +
        lda ObjKE,y
        cmp ColEor
        bne _no
        lda ObjKA,y
        cmp ColAnd
        bne _no
        lda #1
+       rts
_no     lda #0
        rts

; ObjFree: entry Y's sprites' blocks back to the pool (its pointers blank; X kept)
ObjFree:
        stx oFX
        lda Mul6,y
        tay
        ldx #6
-       lda ObjPtr,y
        cmp #BLK_BLANK
        beq +
        stx oFX+1
        ldx FreeN
        sta FreeBlk,x
        inc FreeN
        ldx oFX+1
        lda #BLK_BLANK
        sta ObjPtr,y
+       iny
        dex
        bne -
        ldx oFX
        rts

; AllocBlk: a sprite block from the pool (A; X, Y lost): none left, an entry's let go (ObjEvict)
AllocBlk:
        ldx FreeN
        bne +
        jsr ObjEvict
        ldx FreeN
+       dex
        stx FreeN
        lda FreeBlk,x
        rts

; ObjEvict: an entry other than oE let go (its stages stale, its blocks to the pool): the one used
; longest ago, not pinned, none of the last NBUF frames' (none such: any)
ObjEvict:
        lda #$ff
        sta tmp3
        lda #NBUF - 1
        sta tmp4
        ldy #OBJN - 1
-       cpy oE
        beq +
        lda ObjKT,y
        cmp #$ff
        beq +
        jsr Pinned
        bne +
        lda FrameNo
        sec
        sbc ObjUsed,y
        cmp tmp4
        bcc +
        beq +
        sta tmp4
        sty tmp3
+       dey
        bpl -
        ldy tmp3
        bpl _ev
        ldy #OBJN - 1
-       cpy oE
        beq +
        lda ObjKT,y
        cmp #$ff
        bne _ev
+       dey
        bpl -
_ev     lda #$ff
        sta ObjKT,y
        tya
        ldx #NSTAGE * NBUF - 1
-       cmp SgKE,x
        bne +
        lda #$ff
        sta SgKE,x
        tya
+       dex
        bpl -
        jmp ObjFree

; MakeObj: entry Y for the object okT, okN with the colour masks (Y kept).
;   - its rows 12-1: graphics (even, odd lines; normalised: bit 7 the leftmost pixel), colour
;   - the two colours with most rows shared ($D025 "01", $D026 "11"); the others each a sprite
;     layer of its own ("10"); layer 0 also draws the shared ones
;   - the sprites: by segment (upper, lower), the layers with pixels there, by half (two
;     sprites across: quad width, or two copies); at most 4 upper, 2 lower
MakeObj:
        stx oBX
        sty oE
        jsr ObjFree             ; (its old sprites' blocks back to the pool)
        ldy oE
        tya                     ; (stages staged from this entry: stale)
        ldx #NSTAGE * NBUF - 1
-       cmp SgKE,x
        bne +
        lda #$ff
        sta SgKE,x
        tya
+       dex
        bpl -
        lda okT
        sta ObjKT,y
        lda okN
        sta ObjKN,y
        lda ColEor
        sta ObjKE,y
        lda ColAnd
        sta ObjKA,y
        ldx okT
        lda T_EVEN,x
        sta ptrA
        lda T_ODD,x
        sta ptrB
        lda #$fe
        sta ptrA+1
        sta ptrB+1
        lda T_COL,x
        sta ptrC
        lda #$ff
        sta ptrC+1
        ldx #15
        lda #0
-       sta CCount,x
        dex
        bpl -
        ldy #12
-       lda (ptrA),y
        jsr _norm
        sta RowE,y
        lda (ptrB),y
        jsr _norm
        sta RowO,y
        lda (ptrC),y
        jsr MaskCol
        sta RowC,y
        lda RowE,y
        ora RowO,y
        beq +
        ldx RowC,y
        inc CCount,x
+       dey
        bne -
        jsr _most
        sta oM1
        jsr _most
        sta oM2
        ; each row's pair and layer; the layers with pixels in each segment
        lda #0
        sta oNOwn
        sta oLayU
        sta oLayL
        ldy #12
_rl     lda RowE,y
        ora RowO,y
        bne +
        sta RowP,y
        sta RowL,y
        jmp _rn
+       lda RowC,y
        ldx #$55
        cmp oM1
        beq _sh
        ldx #$ff
        cmp oM2
        beq _sh
        ldx #0                  ; an own colour: its layer
-       cpx oNOwn
        beq _new
        cmp OwnC,x
        beq _old
        inx
        bne -
_new    cpx #8                  ; (eight own colours at most: more share the last's layer)
        bcc +
        dex
        bcs _old
+       sta OwnC,x
        inc oNOwn
_old    txa
        sta RowL,y
        lda #$aa
        sta RowP,y
        jmp _seg
_sh     txa
        sta RowP,y
        lda #0
        sta RowL,y
_seg    ldx RowL,y              ; (upper: rows 12-3, row 2's even line; lower: row 2's odd, row 1)
        lda RowE,y
        cpy #2
        bcc _lo
        beq +
        ora RowO,y
+       cmp #0
        beq +
        lda BitR,x
        ora oLayU
        sta oLayU
+       cpy #2
        bne _rn
        lda RowO,y
        jmp +
_lo     ora RowO,y
+       cmp #0
        beq _rn
        lda BitR,x
        ora oLayL
        sta oLayL
_rn     dey
        beq +
        jmp _rl
+
        ; the sprites
        lda okN
        and #7
        tax
        lda NusHalves,x
        sta oH
        lda NusExp,x
        sta oX
        ldy oE                  ; (its slots: 6 * entry; its blocks from the pool)
        lda Mul6,y
        sta oB
        lda oM1
        sta ObjM1,y
        lda oM2
        sta ObjM2,y
        lda #0
        sta ObjEn,y
        sta ObjExp,y
        ldx #5                  ; (all six off to start)
-       txa
        clc
        adc oB
        tay
        lda #0
        sta ObjXOff,y
        lda #BLK_BLANK
        sta ObjPtr,y
        lda oM1
        sta ObjCol,y
        dex
        bpl -
        lda #$ff
        sta oMrg
        lda #0                  ; upper sprites 0-3: by layer, half
        sta oS
        lda oLayU
        sta oLays
        lda #4
        sta oMax
        lda #0
        sta oSeg
        jsr _sprites
        lda #4                  ; lower sprites 4-5
        sta oS
        jsr _merge
        lda oLayL
        sta oLays
        lda #6
        sta oMax
        lda #1
        sta oSeg
        jsr _sprites
        ldy oE
        ldx oBX
        rts
; (the lower sprites, two: when layer 0 has none of its own colour's lines there, its sprites
; also draw the next layer's (its colour theirs: oMrg), so a wide object's two halves of each
; aren't needed twice)
_merge  lda #$ff
        sta oMrg
        lda oLayL
        lsr
        bcc _mx                 ; (no layer 0 there, or no other)
        beq _mx
        ldx #2                  ; (row 2's odd line, row 1: layer 0's own colour on them?)
        lda RowO,x
        jsr _own0
        beq _mx
        ldx #1
        lda RowE,x
        ora RowO,x
        jsr _own0
        beq _mx
        ldx #0                  ; the next layer there
-       inx
        lda oLayL
        and BitR,x
        beq -
        stx oMrg
        eor oLayL
        sta oLayL
_mx     rts
; (row X with graphics A: Z set if it is layer 0's own colour)
_own0   cmp #0
        beq +
        lda RowL,x
        bne +
        lda RowP,x
        cmp #$aa
        rts
+       lda #1
        rts
; (the sprites for segment oSeg's layers oLays, from oS up to oMax)
_sprites
        lda #0
        sta oLayer
_lay    ldx oLayer
        lda oLays
        and BitR,x
        beq _ln
        lda #0
        sta oHalf
_half   lda oS
        cmp oMax
        bcs _ln
        jsr _one
        inc oS
        inc oHalf
        lda oHalf
        cmp oH
        bne _half
_ln     inc oLayer
        lda oLayer
        cmp #8
        bne _lay
        rts
; (sprite oS: layer oLayer, half oHalf)
_one    ldx oS
        ldy oE                  ; enabled (sprite 2 + oS), expanded
        lda ObjEn,y
        ora BitR+2,x
        sta ObjEn,y
        lda oX
        beq +
        lda ObjExp,y
        ora BitR+2,x
        sta ObjExp,y
+       txa
        clc
        adc oB
        tay
        lda oHalf               ; X offset: 12 pixels a half (24 expanded)
        beq ++
        lda #12
        ldx oX
        beq +
        lda #24
+
+       clc                     ; (double and quad width: a pixel later, as the real TIA)
        adc oX
        sta ObjXOff,y
        sty oSl
        jsr AllocBlk
        ldy oSl
        sta ObjPtr,y
        sta tmp
        ldx oLayer              ; its own colour: its layer's (layer 0 without one: shared 1;
        bne +                   ; drawing a merged one: that one's)
        ldx oMrg
        bpl +
        ldx #0
+       lda oM1
        cpx oNOwn
        bcs +
        lda OwnC,x
+       sta ObjCol,y
        lda tmp
        jsr BlockAddr
        lda okN                 ; (the bytes by NUSIZ and half: _put's)
        and #7
        ldx oHalf
        cmp #7
        beq _q
        cmp #1
        bne _n
        cpx #0
        beq _n
        lda #<_putT1
        ldx #>_putT1
        bne _v
_q      cpx #0
        bne +
        lda #<_putQ0
        ldx #>_putQ0
        bne _v
+       lda #<_putQ1
        ldx #>_putQ1
        bne _v
_n      lda #<_putN
        ldx #>_putN
_v      sta _pj+1
        stx _pj+2
        lda #0
        sta oRow                ; (the sprite's row * 3)
        lda oSeg
        bne _low
        lda #12                 ; upper: rows 12-3 both lines, then row 2's even line (all 21)
        sta oR
-       ldx oR
        lda RowE,x
        jsr _put
        ldx oR
        cpx #2
        beq +
        lda RowO,x
        jsr _put
        dec oR
        bne -
+       rts
_low    ldx #2                  ; lower: row 2's odd line, row 1's; the rest blank
        lda RowO,x
        jsr _put
        ldx #1
        lda RowE,x
        jsr _put
        ldx #1
        lda RowO,x
        jsr _put
        ldy #62
        lda #0
-       sta (ptrD),y
        dey
        cpy #9
        bcs -
        rts
; (graphics A of row X as the sprite's next row (all three bytes), if the row is this sprite's
; layer's (shared rows: layer 0); else blank)
_put    ldy oRow
        cmp #0
        beq _z
        sta tmp4
        lda RowL,x
        cmp oMrg                ; (the layer merged into 0: 0's)
        bne +
        lda #0
+       cmp oLayer
        bne _z
        lda RowP,x              ; (the pair: shared $55 / $FF, own $AA)
        sta tmp3
        ldx tmp4
_pj     jmp $0000
_z      lda #0
        sta (ptrD),y
        iny
        sta (ptrD),y
        iny
        sta (ptrD),y
        iny
        sty oRow
        rts
_putN   lda Exp4Hi,x            ; pixels 0-7: two bytes
        and tmp3
        sta (ptrD),y
        iny
        lda Exp4Lo,x
        and tmp3
        sta (ptrD),y
        iny
        lda #0
        sta (ptrD),y
        iny
        sty oRow
        rts
_putT1  lda #0                  ; two copies 16 apart, the second: its pixels 4-11
        sta (ptrD),y
        iny
        lda Exp4Hi,x
        and tmp3
        sta (ptrD),y
        iny
        lda Exp4Lo,x
        and tmp3
        sta (ptrD),y
        iny
        sty oRow
        rts
_putQ0  txa                     ; quad width (expanded sprites: a pixel each two): pixels 0-5
        lsr
        lsr
        lsr
        lsr
        lsr
        lsr
        tax
        lda Exp2,x
        and tmp3
        sta (ptrD),y
        iny
        lda tmp4
        lsr
        lsr
        lsr
        lsr
        and #3
        tax
        lda Exp2,x
        and tmp3
        sta (ptrD),y
        iny
        lda tmp4
        lsr
        lsr
        and #3
        tax
        lda Exp2,x
        and tmp3
        sta (ptrD),y
        iny
        sty oRow
        rts
_putQ1  txa                     ; ... pixels 6-7
        and #3
        tax
        lda Exp2,x
        and tmp3
        sta (ptrD),y
        iny
        lda #0
        sta (ptrD),y
        iny
        sta (ptrD),y
        iny
        sty oRow
        rts
; (the object's graphics A normalised: bit 7 its leftmost pixel)
_norm   tax
        lda okN
        and #8
        beq +
        lda Rev,x
        rts
+       txa
        rts
; (the colour with most rows, its count then cleared: A)
_most   ldx #15
        lda #0
        sta tmp
        sta tmp2
-       lda CCount,x
        cmp tmp
        bcc +
        beq +
        sta tmp
        stx tmp2
+       dex
        bpl -
        ldx tmp2
        lda #0
        sta CCount,x
        txa
        rts

; ---- PlaneShot: the plane (sprite 0: lines 180-197, its graphics by 198 - line, one pixel right
; and reflected with REFP0) and the shot (sprite 1: the lines the kernel shows it on) for the
; frame top
PlaneShot:
        lda REFP0
        and #8
        cmp #1                  ; (carry: reflected, one pixel on)
        lda PlaneX
        adc #0
        tay
        ldx rbuf
        lda SprXLo,y
        sta StX0,x
        lda SprXHi,y
        sta StMsb,x
        lda #180 + LINEOFS - 1
        sta StY0,x
        lda StPlane,x
        sta StCol0,x
        sta StCol1,x
        lda REFP0               ; its image: NPL kept, by graphics and reflection
        and #8
        sta tmp3
        ldy #NPL - 1
-       lda PlanePtr
        cmp PlKLo,y
        bne +
        lda PlanePtr+1
        cmp PlKHi,y
        bne +
        lda tmp3
        cmp PlKR,y
        beq _phit
+       dey
        bpl -
        jsr PlVictim            ; (none: a new one)
        sty v2
        lda PlanePtr
        sta PlKLo,y
        sta ptrC
        lda PlanePtr+1
        sta PlKHi,y
        sta ptrC+1
        lda tmp3
        sta PlKR,y
        tya
        clc
        adc #BLK_PLANE
        jsr BlockAddr
        ldy #62
        lda #0
-       sta (ptrD),y
        dey
        bpl -
        lda #18                 ; rows 0-17: graphics 18 - row
        sta v0
        lda #0
        sta v1
-       ldy v0
        lda (ptrC),y
        ldy tmp3
        beq +
        tax
        lda Rev,x
+       sta tmp
        ldy v1
        lsr
        lsr
        lsr
        lsr
        tax
        lda Exp4,x
        and #$aa
        sta (ptrD),y
        iny
        lda tmp
        and #15
        tax
        lda Exp4,x
        and #$aa
        sta (ptrD),y
        lda v1
        clc
        adc #3
        sta v1
        dec v0
        bne -
        ldy v2
_phit   lda FrameNo
        sta PlUsed,y
        tya
        clc
        adc #BLK_PLANE
        ldx rbuf
        sta StPtr0,x
_shot   ldx rbuf                ; the shot: its pixel X - 1, its lines
        txa
        clc
        adc #BLK_SHOT
        sta StPtr1,x
        ldy ShotX
        dey
        cpy #160
        bcc +
        ldy #159
+       lda SprXLo,y
        sta StX1,x
        lda SprXHi,y
        asl
        ora StMsb,x
        sta StMsb,x
        lda SLFirst             ; (its lines: ShotScan's)
        sta v0
        lda SLBits
        sta v1
        lda SLBits+1
        sta v2
        lda SLBits+2
        sta v3
        ldx rbuf
        lda #1                  ; (the plane on; the shot if any)
        sta StEn,x
        lda v0
        bne +
        sta StY1,x
        rts
+       clc
        adc #LINEOFS - 1
        sta StY1,x
        lda #3
        sta StEn,x
        lda v1                  ; its image, if its lines aren't this buffer's last
        cmp ShK1,x
        bne +
        lda v2
        cmp ShK2,x
        bne +
        lda v3
        cmp ShK3,x
        beq _sd
+       lda v1
        sta ShK1,x
        lda v2
        sta ShK2,x
        lda v3
        sta ShK3,x
        lda StPtr1,x
        jsr BlockAddr
        ldy #0
-       lda #0
        lsr v3                  ; (bit 0 of v1 the first line)
        ror v2
        ror v1
        bcc +
        lda #$80
+       sta (ptrD),y
        iny
        iny
        iny
        cpy #63
        bne -
_sd     rts

; PlVictim: a plane image entry to make (Y): the one used longest ago that neither the buffer
; shown nor one waiting shows
PlVictim:
        lda #0
        sta tmp4
        ldy #NPL - 1
        sty tmp2
-       sei
        tya
        clc
        adc #BLK_PLANE
        ldx curBuf
        cmp StPtr0,x
        beq _busy
        ldx QCount
        beq _ok
        stx tmp
        sta v3
-       ldx tmp
        lda Queue-1,x
        tax
        lda v3
        cmp StPtr0,x
        beq _busy
        dec tmp
        bne -
_ok     cli
        lda FrameNo
        sec
        sbc PlUsed,y
        cmp tmp4
        bcc _next
        sta tmp4
        sty tmp2
        bcs _next
_busy   cli
_next   dey
        bpl --
        ldy tmp2
        rts

; BlockAddr: sprite block A -> ptrD its address (X kept)
BlockAddr:
        sta ptrD+1
        lda #0
        lsr ptrD+1
        ror a
        lsr ptrD+1
        ror a
        sta ptrD
        lda ptrD+1
        clc
        adc #$40
        sta ptrD+1
        rts

; ---- Panel: the score's digits, the gauge's needle (characters), the ships left and the logo
; (sprites 0 and 1), the panel's first line's colour (colour RAM rows 20-21). Shared by the
; buffers: drawn when they change.
; Panel rows 0-3 (2600 lines 198-205, 206-213, 214-221, 222-229) in character columns 14-25
; (the panel's six 8-pixel columns, 2600 pixels 56-103, two characters each): panel line
; pl = 2600 line - 198 is row pl / 8, line pl & 7; its character CH_PANEL + 12 * row + column.
Panel:
        ldx #0                  ; the digits
_dg     lda DigitPtr,x
        cmp PnDig,x
        bne +
        lda DigitPtr+1,x
        cmp PnDig+1,x
        beq _dn
+       lda DigitPtr,x
        sta PnDig,x
        sta ptrC
        lda DigitPtr+1,x
        sta PnDig+1,x
        sta ptrC+1
        stx v0
        jsr DigitGlyphs         ; (column X: characters X, X + 1)
        ldx v0
_dn     inx
        inx
        cpx #12
        bne _dg
        lda Fuel                ; the needle: the columns of its old and new place redrawn
        lsr
        lsr
        lsr
        clc
        adc #68
        cmp PnNeedle
        beq _nn
        ldx PnNeedle
        sta PnNeedle
        cpx #$ff
        bne +
        lda #0                  ; (the first time: all)
        sta GgLo
        lda #12
        sta GgEnd
        bne _gg
+       txa                     ; (both places, two pixels each from one left: three columns
        jsr GCol                ; from each)
        sta GgLo
        sta GgEnd
        lda PnNeedle
        jsr GCol
        cmp GgLo
        bcs +
        sta GgLo
+       cmp GgEnd
        bcc +
        sta GgEnd
+       lda GgEnd
        clc
        adc #3
        cmp #13
        bcc +
        lda #12
+       sta GgEnd
_gg     jsr GaugeGlyphs
_nn
+       lda LivesPtr            ; the ships left and the logo
        cmp PnLives
        bne +
        lda LivesPtr+1
        cmp PnLives+1
        bne +
        lda LogoTop
        cmp PnLogo
        beq ++
+       lda LivesPtr
        sta PnLives
        lda LivesPtr+1
        sta PnLives+1
        lda LogoTop
        sta PnLogo
        jsr LogoSprites
+       ldx rbuf                ; the gauge's colour: colour RAM rows 20-21 (the first line, "11")
        lda StGauge,x
        cmp PnGaugeCol
        beq +
        sta PnGaugeCol
        ora #8
        ldx #37
-       sta $d800 + 40 * 20 + 2,x
        sta $d800 + 40 * 21 + 2,x
        dex
        bpl -
+       rts

; DigitGlyphs: the digit at ptrC (8 rows, row 7 at the top: lines 200-207) in characters X,
; X + 1, "10"
DigitGlyphs:
        lda Mul8,x
        sta v1                  ; (its bytes in the panel's character row: 8 * X)
        ldy #7
-       sty v2
        lda (ptrC),y
        sta tmp
        tya                     ; (panel line 9 - row)
        eor #$ff
        sec
        adc #9
        tax
        lda PLineLo,x
        sta ptrD
        lda PLineHi,x
        sta ptrD+1
        ldy v1
        lda tmp
        lsr
        lsr
        lsr
        lsr
        tax
        lda Exp4,x
        and #$aa
        sta (ptrD),y
        tya
        clc
        adc #8
        tay
        lda tmp
        and #15
        tax
        lda Exp4,x
        and #$aa
        sta (ptrD),y
        ldy v2
        dey
        bpl -
        rts
; panel line l (0-31): its byte in the panel's character 0 of its row
PLineLo:    .for i := 0, i < 32, i += 1
            .byte <(CHARSET + 8 * CH_PANEL + 96 * (i >> 3) + (i & 7))
            .endfor
PLineHi:    .for i := 0, i < 32, i += 1
            .byte >(CHARSET + 8 * CH_PANEL + 96 * (i >> 3) + (i & 7))
            .endfor

; GlyphAddr: character A -> ptrD its address
GlyphAddr:
        sta ptrD
        lda #0
        asl ptrD
        rol a
        asl ptrD
        rol a
        asl ptrD
        rol a
        clc
        adc #>CHARSET
        sta ptrD+1
        rts

; GaugeGlyphs: the gauge (lines 210-224, rows 14-0: five ROM columns in the panel's columns 1-5)
; as "01", and the needle (PnNeedle, two pixels; where $FE48 enables it) as "10" behind it, in
; character columns GgLo to GgEnd - 1 (the gauge's pixels: GMaskT, made by InitGauge)
GaugeGlyphs:
        lda #0                  ; the needle's pixels: as "10" in a 48-pixel row
        ldx #11
-       sta NeedleRow,x
        dex
        bpl -
        lda PnNeedle
        jsr _nd
        lda PnNeedle
        clc
        adc #1
        jsr _nd
        lda #14
        sta v2                  ; (gauge row)
_gr     ldx v2
        lda GBaseLo,x           ; (its line's bytes in the panel's characters)
        sta ptrD
        lda GBaseHi,x
        sta ptrD+1
        lda $fe48,x
        and #2
        sta tmp3                ; (the needle on this row?)
        lda Mul12R,x
        clc
        adc GgLo
        tax                     ; (GMaskT's index)
        lda GgLo
        sta v1                  ; (character column)
-       lda GMaskT,x            ; the gauge's pixels "01", the needle "10" where none
        sta tmp4
        and #$55
        ldy tmp3
        beq +
        sta tmp
        lda tmp4
        eor #$ff
        ldy v1
        and NeedleRow,y
        ora tmp
+       ldy v1
        pha
        lda Mul8,y
        tay
        pla
        sta (ptrD),y
        inx
        inc v1
        lda v1
        cmp GgEnd
        bne -
        dec v2
        bpl _gr
        rts
; (needle pixel A: "10" in its character of NeedleRow)
_nd     sec
        sbc #56
        bcc +
        cmp #48
        bcs +
        pha
        lsr
        lsr
        tax
        pla
        and #3
        tay
        lda NeedleRow,x
        ora McPix10,y
        sta NeedleRow,x
+       rts
; GCol: the character column of needle pixel A, one left: (A - 1 - 56) / 4, at least 0
GCol    sec
        sbc #57
        bcs +
        lda #0
+       lsr
        lsr
        rts
GaugeLo:    .byte <$fe00, <$fe0f, <$fe1d, <$fe2b, <$fe39
Mul12:      .byte 0, 12, 24, 36
McPix10:    .byte $80, $20, $08, $02
Mul12R:     .for i := 0, i < 15, i += 1
            .byte 12 * i
            .endfor
Mul8:       .for i := 0, i < 12, i += 1
            .byte 8 * i
            .endfor
GBaseLo:    .for i := 0, i < 15, i += 1     ; (gauge row i: panel line 26 - i)
            .byte <(CHARSET + 8 * CH_PANEL + 96 * ((26 - i) >> 3) + ((26 - i) & 7))
            .endfor
GBaseHi:    .for i := 0, i < 15, i += 1
            .byte >(CHARSET + 8 * CH_PANEL + 96 * ((26 - i) >> 3) + ((26 - i) & 7))
            .endfor

; InitGauge: GMaskT (gauge row * 12 + character column): the gauge's pixels as "11"
InitGauge:
        ldx #0
        lda #0
        sta v2                  ; (row)
_ir     lda #0
        sta v1                  ; (column)
-       lda v1
        lsr
        tay
        lda #0
        cpy #0
        beq +
        lda GaugeLo-1,y
        sta ptrC
        lda #$fe
        sta ptrC+1
        ldy v2
        lda (ptrC),y
+       sta tmp
        lda v1
        and #1
        bne +
        lda tmp
        lsr
        lsr
        lsr
        lsr
        sta tmp
+       lda tmp
        and #15
        tay
        lda Exp4,y
        sta GMaskT,x
        inx
        inc v1
        lda v1
        cmp #12
        bne -
        inc v2
        lda v2
        cmp #15
        bne _ir
        rts

; LogoSprites: the ships left and the logo (8 rows from LogoTop down): sprites 0 (columns 0-2)
; and 1 (columns 3-5), hires, X-expanded
LogoSprites:
        lda #BLK_LOGO
        jsr BlockAddr
        ldy #127
        lda #0
-       sta (ptrD),y            ; (both blocks)
        dey
        bpl -
        lda LivesPtr
        sta ptrC
        lda LivesPtr+1
        sta ptrC+1
        lda #0
        sta v1                  ; (sprite row * 3)
        lda LogoTop
        sta v2
-       ldy v2
        lda (ptrC),y            ; the ships left
        ldy v1
        sta (ptrD),y
        ldx v2
        lda $fb68,x
        iny
        sta (ptrD),y
        lda $fb78,x
        iny
        sta (ptrD),y
        tya
        clc
        adc #64 - 2
        tay
        lda $fb88,x
        sta (ptrD),y
        iny
        lda $fb98,x
        sta (ptrD),y
        iny
        lda $fba8,x
        sta (ptrD),y
        lda v1
        clc
        adc #3
        sta v1
        dec v2
        cmp #24
        bne -
        rts

; ---- the frame top and the events (interrupt)

; FrameTop: the next buffer shown (or the same again): the river's screen and scroll, colours,
; the plane and the shot; the objects' sprites off until their first block's event
FrameTop:
        lda QCount
        beq _rep
        lda Queue
        sta curBuf
        lda Queue+1
        sta Queue
        lda Queue+2
        sta Queue+1
        dec QCount
        jmp +
_rep    ldy DbgRepI             ; (testing aid: the ticks of the last 128 repeats)
        lda AutoT
        sta DbgRepT,y
        lda AutoT+1
        sta DbgRepT+1,y
        iny
        iny
        sty DbgRepI
        inc DbgRepeat
        bne +
        inc DbgRepeat+1
+       inc DbgTops
        bne +
        inc DbgTops+1
+       ldx curBuf
        lda StD011,x
        sta $d011
        lda StD018,x
        sta $d018
        ldy StScr,x             ; (the sprite pointers: in the screen shown)
        lda ScrPtrHi,y
        sta irqP+1
        lda StD021,x
        sta $d021
        lda StD022,x
        sta $d022
        lda StDigit,x
        sta $d023
        lda #BLK_BLANK          ; (the panel's sprite 2: the comb only from the logo's event)
        sta STATA + $3fa
        sta STATB + $3fa
        lda #$ff                ; all multicolour, behind the comb
        sta $d01c
        sta $d01b
        lda #0
        sta $d01d
        lda StX0,x
        sta $d000
        lda StY0,x
        sta $d001
        lda StX1,x
        sta $d002
        lda StY1,x
        sta $d003
        lda StMsb,x
        sta $d010
        sta irqPM               ; (the stages add them to the objects' sprites')
        lda StEn,x
        sta $d015
        sta irqPE
        lda StCol0,x
        sta $d027
        lda StCol1,x
        sta $d028
        ldy #0
        lda StPtr0,x
        sta (irqP),y
        iny
        lda StPtr1,x
        sta (irqP),y
        lda StStat,x            ; the panel's NMI on 215: its screen, colours, a colour write
        sta NmD018              ; folded on 215 (the buffer's last, if on 215)
        lda StPanelBg,x
        sta NmBg
        lda StGauge,x
        sta NmGauge
        lda #$80
        sta NmV
        ldy FoldN,x
        beq +
        dey
        tya
        clc
        adc Mul3,x
        tay
        lda FoldL,y
        cmp #STATRASTER
        bne +
        lda FoldV,y
        sta NmV
+       rts
ScrPtrHi:   .byte >(SCREEN0 + $3f8), >(SCREEN0 + $400 + $3f8), >(SCREEN0 + $800 + $3f8)

; EvLogo: the digits done: the needle's colour; sprites 0 and 1 the ships left and the logo
EvLogo:
        ldx curBuf
        lda StNeedle,x
        sta $d023
        lda StDigit,x
        sta $d027
        sta $d028
        lda #24 + 2 * 56        ; (2600 pixels 56 and 80)
        sta $d000
        lda #24 + 2 * 80
        sta $d002
        lda #LOGOY
        sta $d001
        sta $d003
        lda #BLK_COMB           ; sprite 2: the comb on the last three lines (past the last
        sta STATA + $3fa        ; badline: no characters there; its pointer blank again at the
        sta STATB + $3fa        ; frame top: the objects' sprites may run on into the panel)
        lda #24
        sta $d004
        lda #COMBY
        sta $d005
        lda #0                  ; (sprites 3-7: blank from here on, their pointers the panel's)
        sta $d029
        sta $d010
        sta $d01b
        lda #$f8
        sta $d01c
        lda #3
        sta $d01d
        lda #7
        sta $d015
        rts
COMBY       = 247               ; (the comb sprite's first line - 1)

; ---- set-up
InitVideo:
        lda $dd02               ; VIC bank 1 ($4000)
        ora #3
        sta $dd02
        lda $dd00
        and #$fc
        ora #2
        sta $dd00
        lda #0
        sta $d020
        sta $d021
        sta $d015
        sta $d017
        lda #$18                ; multicolour characters, 40 columns
        sta $d016
        lda #0                  ; (the VIC's idle byte: the panel's last three lines, past the
        sta $7fff               ; last badline, show only the background)
        lda #$f8                ; (the sprite pointers: $3F8 in a screen)
        sta irqP
        lda #(SCREEN0 - $4000) / $400 * 16
        sta $d018
        ldx #0                  ; the event lists and stages: by buffer
        lda #0
        ldy #0
-       sta EvBaseOf,x
        pha
        tya
        sta StageOf,x
        clc
        adc #NSTAGE
        tay
        pla
        clc
        adc #NEV
        inx
        cpx #NBUF
        bne -
        ldx #NBUF - 1
-       ldy EvBaseOf,x
        lda #ENDRASTER
        sta EvRas,y
        lda #EV_END
        sta EvReg,y
        lda #0
        sta EvArm,y
        lda #<IrqEnd
        sta EvLo,y
        lda #>IrqEnd
        sta EvHi,y
        lda #0
        sta StEn,x
        lda #$10
        sta StD011,x
        dex
        bpl -
        ; the character set: 0-15 the river's (bit i: rows 2i, 2i + 1 land, "01"), 16 the comb,
        ; 17 blank, 18 the panel's first line ("11" the gauge's colour), the panel's (32 on)
        ldx #0
        lda #0
-       sta CHARSET,x
        sta CHARSET + $100,x
        sta CHARSET + $200,x
        sta CHARSET + $300,x
        inx
        bne -
        ldx #0
_ch     txa
        asl
        asl
        asl
        tay
        txa
        sta tmp
        lda #4
        sta tmp2
-       lsr tmp
        lda #0
        bcc +
        lda #$55
+       sta CHARSET,y
        sta CHARSET + 1,y
        iny
        iny
        dec tmp2
        bne -
        inx
        cpx #16
        bne _ch
        ldx #7
        lda #$ff
-       sta CHARSET + 8 * CH_COMB,x
        dex
        bpl -
        sta CHARSET + 8 * CH_BLACK
        ldx #11                 ; (the panel's row 0: its first line too)
-       txa
        clc
        adc #CH_PANEL
        jsr GlyphAddr
        ldy #0
        lda #$ff
        sta (ptrD),y
        dex
        bpl -
        ; colour RAM: black, multicolour (the comb's "11")
        ldx #0
        lda #8
-       sta $d800,x
        sta $d900,x
        sta $da00,x
        sta $dae8,x
        inx
        bne -
        ; the river's screens: the comb, land at the edges, the rest set by Rows
        ldx #2
-       stx tmp4
        lda ScrPtrHi,x
        sec
        sbc #3
        sta ptrA+1
        lda #0
        sta ptrA
        jsr EdgeScreen
        ldx tmp4
        dex
        bpl -
        ; the panel's screens: rows 20-23, 21-24
        lda #>STATA
        ldy #20
        jsr PanelScreen
        lda #>STATB
        ldy #21
        jsr PanelScreen
        ; nothing made yet
        ldx #3 * 21 - 1
        lda #$ff
-       sta RowKey,x
        dex
        bpl -
        ldx #5
-       sta BSlotPrev,x
        sta BsType,x            ; (collide's BlockSetup: nothing set up yet)
        dex
        bpl -
        ldx #CSLOTS - 1
-       sta SlotPF1,x
        dex
        bpl -
        jsr NoKeys
        sta DesQ                ; (A = $FF)
        ldx #5
-       sta LastPF1,x
        dex
        bpl -
        ldx #OBJN - 1           ; (no objects' images: their sprites blank)
-       sta ObjKT,x
        dex
        bpl -
        ldx #6 * OBJN - 1
        lda #BLK_BLANK
-       sta ObjPtr,x
        dex
        bne -
        sta ObjPtr
        ldx #0                  ; (the pool of sprite blocks)
        ldy #BLK_OBJ
-       tya
        sta FreeBlk,x
        inx
        iny
        bne -
        ldy #0
-       lda XtraBlk,y
        sta FreeBlk,x
        inx
        iny
        cpy #XTRAN
        bne -
        stx FreeN
        lda #$ff
        ldx #NPL - 1
-       sta PlKLo,x
        dex
        bpl -
        sta PnNeedle
        sta PnLives
        sta PnLogo
        sta PnGaugeCol
        sta ColK1               ; (ColEor is even: never $FF)
        ldx #11
-       sta PnDig,x
        dex
        bpl -
        ldx #NBUF               ; the blank sprite block, the shot's (PlaneShot writes only their
-       txa                     ; first column)
        clc
        adc #BLK_SHOT
        cpx #NBUF
        bne +
        lda #BLK_BLANK
+       jsr BlockAddr
        ldy #63
        lda #0
-       sta (ptrD),y
        dey
        bpl -
        dex
        bpl --
        lda #BLK_COMB           ; the comb's sprite: three rows of 16 pixels
        jsr BlockAddr
        ldy #63
-       lda #0
        cpy #9
        bcs +
        cpy #2
        beq +
        cpy #5
        beq +
        cpy #8
        beq +
        lda #$ff
+       sta (ptrD),y
        dey
        bpl -
        lda #$ff               ; (collide.asm: no plane pixel masks made yet, no plane rows ORed)
        sta GkPos
        sta POKHi
        jsr InitStages
        jsr InitRows
        jsr InitGauge
        jmp TypeRows

; EdgeScreen: the screen at ptrA: every row the comb (columns 0-1), land (2-3, 36-39), water
EdgeScreen:
        ldx #25
_er     ldy #39
-       lda ScrEdge,y
        sta (ptrA),y
        dey
        bpl -
        lda ptrA
        clc
        adc #40
        sta ptrA
        bcc +
        inc ptrA+1
+       dex
        bne _er
        rts
ScrEdge:    .byte CH_COMB, CH_COMB, CH_LAND, CH_LAND
            .fill 32, 0
            .byte CH_LAND, CH_LAND, CH_LAND, CH_LAND

; PanelScreen: the screen at page A gets the panel in rows Y to Y + 3 (blank elsewhere); its
; sprite pointers the logo's (sprites 0, 1) and blank (2-7)
PanelScreen:
        sta ptrA+1
        sta ptrB+1
        lda #0
        sta ptrA
        sty tmp
        ldy #0                  ; (all blank first)
        lda #CH_BLANK
        ldx #4
-       sta (ptrA),y
        iny
        bne -
        inc ptrA+1
        dex
        bne -
        lda ptrB+1              ; sprite pointers ($3F8)
        clc
        adc #3
        sta ptrA+1
        ldy #$f8
        lda #BLK_LOGO
        sta (ptrA),y
        iny
        lda #BLK_LOGO + 1
        sta (ptrA),y
        lda #BLK_BLANK
-       iny
        sta (ptrA),y
        cpy #$ff
        bne -
        lda #0                  ; rows Y..Y+3: the comb, then the panel's characters
        sta tmp3                ; (panel row)
_pr     ldx tmp
        lda Row40Lo,x
        sta ptrA
        lda Row40Hi,x
        clc
        adc ptrB+1
        sta ptrA+1
        ldy #39
_pc     lda #CH_BLANK
        ldx tmp3
        bne +
        lda #CH_BLACK
+       cpy #2
        bcs +
        lda #CH_COMB
+       cpy #14
        bcc +
        cpy #26
        bcs +
        tya                     ; (columns 14-25: the panel's own: 32 + 12 * row + column)
        sec
        sbc #14
        clc
        adc Mul12,x
        adc #CH_PANEL
+       sta (ptrA),y
        dey
        bpl _pc
        inc tmp
        inc tmp3
        lda tmp3
        cmp #4
        bne _pr
        rts
Row40Lo:    .for i := 0, i < 25, i += 1
            .byte <(40 * i)
            .endfor
Row40Hi:    .for i := 0, i < 25, i += 1
            .byte >(40 * i)
            .endfor

; TypeRows: each object type's rows (1-12) with pixels: TypeRowLo / Hi (0: none)
TypeRows:
        ldx #10
_tr     lda #0
        sta TypeRowLo,x
        sta TypeRowHi,x
        sta TypeOr,x
        lda T_EVEN,x
        sta ptrA
        lda T_ODD,x
        sta ptrB
        lda #$fe
        sta ptrA+1
        sta ptrB+1
        ldy #12
-       lda (ptrA),y
        ora (ptrB),y
        beq +
        pha                     ; (the rows' graphics ORed: TypeOr)
        ora TypeOr,x
        sta TypeOr,x
        pla
        tya
        sta TypeRowLo,x
        lda TypeRowHi,x
        bne +
        tya
        sta TypeRowHi,x
+       dey
        bne -
        lda TypeRowHi,x         ; (their lines: o 30 - 2 * highest row on, to 32 - 2 * lowest)
        asl
        eor #$ff
        sec
        adc #30
        sta TypeOFirst,x
        lda TypeRowLo,x
        asl
        eor #$ff
        sec
        adc #32
        sta TypeOEnd,x
        dex
        bpl _tr
        rts

; a nibble's 4 pixels (bit 3 the leftmost) as a multicolour byte, "11" for each set pixel
Exp4:       .byte $00, $03, $0c, $0f, $30, $33, $3c, $3f, $c0, $c3, $cc, $cf, $f0, $f3, $fc, $ff
; two pixels (bit 1 the left) each doubled
Exp2:       .byte $00, $0f, $f0, $ff
; by NUSIZ: sprites across (halves), expanded
NusHalves:  .byte 1, 2, 1, 1, 1, 1, 1, 2
NusExp:     .byte 0, 0, 0, 0, 0, 1, 0, 1

; ---- the panel's switch (NMI). CIA 2's timer A runs at the frame's period (NmiInit: started on
; line 215, so it comes there every frame, whatever the raster interrupt is doing then). Line
; 216 must be a badline that starts the panel's rows: its screen ($D018), scroll 0 and 25 rows
; ($D011), written after the river's last badline began and before 216's (from 215's cycle 12 at
; scroll 7, when 215 is that badline: the VIC holds the CPU's reads from 12 to 54, so these
; land just after). As interrupts it came too late now and then (the sprites' fetches on these
; lines, the interrupts before it): the panel broke up. Then a colour write folded on 215, the
; panel's colours (past 215's last pixel; line 216 shows only "11": anywhere up to its end).
NmiPanel:
        pha
        lda #$18
        sta $d011
NmD018  = * + 1
        lda #0                  ; (FrameTop: the shown buffer's panel screen)
        sta $d018
        lda $dd0d               ; (acknowledged; bit 0 clear: not the timer's but RESTORE's)
        lsr
        bcc _x
NmV     = * + 1
        lda #$80                ; (FrameTop: a colour on 215, $80 none)
        bmi +
        sta $d022
+       nop                     ; (past 215's last pixel)
        nop
NmBg    = * + 1
        lda #0
        sta $d021
NmGauge = * + 1
        lda #0
        sta $d022
_x      pla
        rti

; NmiInit: CIA 2's timer A at the frame's period (by the last raster line: PAL 312 x 63, NTSC
; 263 x 65, old NTSC 262 x 64 cycles), started at the start of line 215 (interrupts off); its
; NMI on
NmiInit:
        ldx #2
-       lda NmiLast,x
        cmp LastLine
        beq +
        dex
        bne -
+       lda NmiPerLo,x
        sta $dd04
        lda NmiPerHi,x
        sta $dd05
        lda #$7f
        sta $dd0d
        lda $dd0d
        lda #$11                ; (continuous, loaded on start)
-       ldx $d012
        cpx #STATRASTER - 1
        bne -
-       ldx $d012
        cpx #STATRASTER
        bne -
        sta $dd0e
        lda #$81
        sta $dd0d
        rts
NmiLast:    .byte $37, $06, $05
NmiPerLo:   .byte <(312 * 63 - 1), <(263 * 65 - 1), <(262 * 64 - 1)
NmiPerHi:   .byte >(312 * 63 - 1), >(263 * 65 - 1), >(262 * 64 - 1)
; the game's colour table at $FFF7 (its last two bytes are the NMI vector now: data.asm)
TFFF7c:     .binary "../build/original.a26", $0ff7, 5
