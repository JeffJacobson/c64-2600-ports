# River Raid (2600) RAM map

The 2600 has 128 bytes of RAM at `$80-$FF`. This is what the game keeps in each byte, worked out by reading
the code and watching memory in `tools/vcs.js`. A `?` marks something not fully confirmed yet.

Generated from `symbols.js` by `tools/disasm.js`; edit that file, not this one.

| Address | Name | Bytes | What it holds |
|---|---|---|---|
| `$80` | GameNum | 1 | Game selected: 0 one player, 1 two players |
| `$81` | SelectDelay | 1 | Frames until Game Select steps again |
| `$82` | Frame | 1 | Frame counter, counts down |
| `$83` | Random | 1 | Random number (shifted each frame) |
| `$84` | Joy | 1 | Joystick bits (SWCHA nibble of the player up, rotated in) |
| `$85` | ColEor | 1 | Colour EOR mask (attract colour cycling) |
| `$86` | ColAnd | 1 | Colour AND mask: $FF colour, $0F B&W ($F7 while cycling) |
| `$87` | TurnSpeed | 1 | Plane: sideways speed (fraction)? |
| `$8B` | Scroll | 1 | The line within the top block (0-31): the river's scroll |
| `$8C` | ScrollFrac | 1 | Scroll fraction: Speed is added to it twice a frame, each carry scrolls a line |
| `$8D` | Flash | 1 | Background flashes red while it counts down (bridge or plane hit) |
| `$8E-$93` | BlkFlags | 6 | Per block: bit 0 PF1 page ($FD), bit 1 PF2 page, bit 2 the bank's green, bit 5 the object touched the bank (kernel), bit 7 a road |
| `$94-$99` | BlkCoarse | 6 | Per block: the object's coarse position (the kernel's delay count) |
| `$9A-$9F` | BlkFine | 6 | Per block: the object's fine motion (high nibble), NUSIZ1 and reflection (low) |
| `$A0-$A5` | BlkType | 6 | Per block: the object type (0 none, 1-3 explosion, 4 jet, 5/6 helicopter, 7 tanker, 8 bridge, 9 house, 10 fuel) |
| `$A6-$AB` | BlkPF1 | 6 | Per block: PF1 shape pointer (low byte; page by BlkFlags bit 0) |
| `$AC-$B1` | BlkPF2 | 6 | Per block: PF2 shape pointer (low byte; page by BlkFlags bit 1) |
| `$B2` | ShotY | 1 | The shot's line counter value (8 lines from here up) |
| `$B3` | PlaneX | 1 | The plane's X |
| `$B5` | Speed | 1 | Scroll speed ($40 slow .. $FE fast) |
| `$B7` | Fuel | 1 | Fuel (the gauge's needle) |
| `$BA-$BB` | PlanePtr | 2 | Pointer to the plane's graphics (banking left/right, explosion) |
| `$C6` | State | 1 | 0 flying; other values: starting, dying; $FF no game? |
| `$C7-$C8` | ShapeOdd | 2 | Kernel: the block's object shape for odd lines |
| `$C9-$CA` | ShapeEven | 2 | Kernel: ... for even lines |
| `$CB-$CC` | ShapeCol | 2 | Kernel: ... its colours by row |
| `$CD-$D4` | DigitPtr | 8 | Score digit pointers? |
| `$D9-$DA` | PF1Ptr | 2 | Kernel: the block's PF1 shape pointer |
| `$DB-$DC` | PF2Ptr | 2 | Kernel: the block's PF2 shape pointer |
| `$DE` | KBlock | 1 | Kernel: the block being drawn |
| `$E0` | PlaneRefl | 1 | The plane's REFP0 (banking right) |
| `$E2` | HitShotObj | 1 | Kernel: the block whose object the shot hit ($FF none) |
| `$E4` | HitPlaneBank | 1 | Kernel: the plane touched the bank ($FF none) |
| `$E6` | HitShotBank | 1 | Kernel: the shot touched the bank ($FF none) |
| `$E8` | HitPlaneObj | 1 | Kernel: the block whose object the plane touched ($FF none) |
| `$ED` | KFlags | 1 | Kernel: the block's flags (scratch elsewhere) |
| `$EE` | KColPF | 1 | Kernel: the block's bank colour; in the vertical blank the colours $EE-$F3 |
| `$EF` | ColPlane | 1 | The plane's (and score's) colour |
| `$F0` | ColPanel | 1 | The bottom panel's background |
| `$F1` | ColNeedle | 1 | The fuel needle's colour |
| `$F2` | Temp | 1 | Scratch |
| `$F3` | ColGauge | 1 | The gauge's colour (and the line above the panel) |
| `$F4` | CurPlayer | 1 | Player up: 0 or 1 |
| `$F5` | ShotX | 1 | The shot's X |
| `$FC` | KRow | 1 | Kernel: the row within the block |
| `$FD` | KLine | 1 | Kernel: the line counter (160 at the top, 0 at the last line) |

## Routines

| Address | Name | What it does |
|---|---|---|
| `$F000` | Reset | Power on: clear RAM and the TIA |
| `$F027` | FrameStart | Vertical blank: positions, colours, the kernel's entry for the scroll |
| `$F12E` | WaitKernel | Wait for the timer, then "return" into the kernel at the entry pushed for the scroll |
| `$F13A` | KEntryEven | Kernel entry: the top line is the first of a row pair |
| `$F152` | KEntryOdd | Kernel entry: the top line is the second of a row pair |
| `$F156` | KRowPair | Kernel: a row pair (object, playfield, plane, shot) |
| `$F1B4` | KNextBlock | Kernel: the next block's flags, colour and shapes |
| `$F1F7` | KEntryRow0 | Kernel entry: the top line is a block's row 0 |
| `$F205` | KEntryLast | Kernel entry: the top line is a block's last line |
| `$F243` | KBlockLine0 | Kernel: a block's first line, then its object positioned (RESP1) |
| `$F296` | KBlockLine2 | Kernel: playfield row 14, HMP1 |
| `$F2B7` | KBlockLine3 | Kernel: NUSIZ1, then the collisions read for the block above |
| `$F340` | KEntryLine4 | Kernel entry at a block's line 4 |
| `$F346` | KEntryLine5 | Kernel entry at a block's line 5 |
| `$F350` | Panel | The bottom panel: score, fuel gauge, ships left and logo |
| `$F3C2` | GaugeLines | The fuel gauge |
| `$F41A` | LogoLines | Ships left and the Activision logo |
| `$F45C` | LastCollisions | The last block's collisions |
| `$F807` | FrameSync | Wait for the timer, vertical sync |
| `$FAEF` | PosObject | Position object X at A (CalcPos, then SetPos) |
| `$FAF2` | SetPos | HMxx = A, wait Y, RESxx |
| `$FBD5` | SetPFPtrs | The kernel's PF1 / PF2 pointers for block X |
| `$FDD8` | CalcPos | X (A) -> fine motion (A) and coarse count (Y) |
| `$FFAE` | WsyncHmove | WSYNC, HMOVE |
