// Names for River Raid's RAM and routines, worked out by reading the code and watching RAM in
// tools/vcs.js. Used by tools/disasm.js to label the source and to write RAM-MAP.md.
// "?" marks something not yet confirmed.
//
// Conventions found in the code:
//   - The river is drawn in blocks of 32 lines, six of them (index 0 at the bottom, 5 at the top),
//     each with one object (player 1) and its own playfield shape. The per-block arrays are
//     BlkFlags $8E, BlkCoarse $94, BlkFine $9A, BlkType $A0, BlkPF1 $A6, BlkPF2 $AC (+ block).
//   - Scroll ($8B, 0-31) is the line within the top block; when it passes 31 the arrays shift down
//     one block and a new block is made at the top (index 5).
//   - Object types (BlkType): 0 none, 1-3 explosion frames, 4 jet, 5-6 helicopter (two frames),
//     7 tanker, 8 bridge, 9 house, 10 fuel depot.
//   - Colours are EORed with ColEor ($85) and ANDed with ColAnd ($86) (attract colours, B&W).
//   - The kernel's collision results: $E2 shot-object, $E4 plane-bank, $E6 shot-bank, $E8
//     plane-object: the block's index, $FF none.

const game = { title: 'River Raid', from: 'Atari 2600 (Activision, 1982)', md5: '393948436d1f4cc3192410bb918f9724', asm: 'river-raid.asm' };

const ram = [
  [0x80, 'GameNum', 1, 'Game selected: 0 one player, 1 two players'],
  [0x81, 'SelectDelay', 1, 'Frames until Game Select steps again'],
  [0x82, 'Frame', 1, 'Frame counter, counts down'],
  [0x83, 'Random', 1, 'Random number (shifted each frame)'],
  [0x84, 'Joy', 1, 'Joystick bits (SWCHA nibble of the player up, rotated in)'],
  [0x85, 'ColEor', 1, 'Colour EOR mask (attract colour cycling)'],
  [0x86, 'ColAnd', 1, 'Colour AND mask: $FF colour, $0F B&W ($F7 while cycling)'],
  [0x87, 'TurnSpeed', 1, 'Plane: sideways speed (fraction)?'],
  [0x8B, 'Scroll', 1, 'The line within the top block (0-31): the river\'s scroll'],
  [0x8C, 'ScrollFrac', 1, 'Scroll fraction: Speed is added to it twice a frame, each carry scrolls a line'],
  [0x8D, 'Flash', 1, 'Background flashes red while it counts down (bridge or plane hit)'],
  [0x8E, 'BlkFlags', 6, 'Per block: bit 0 PF1 page ($FD), bit 1 PF2 page, bit 2 the bank\'s green, bit 5 the object touched the bank (kernel), bit 7 a road'],
  [0x94, 'BlkCoarse', 6, 'Per block: the object\'s coarse position (the kernel\'s delay count)'],
  [0x9A, 'BlkFine', 6, 'Per block: the object\'s fine motion (high nibble), NUSIZ1 and reflection (low)'],
  [0xA0, 'BlkType', 6, 'Per block: the object type (0 none, 1-3 explosion, 4 jet, 5/6 helicopter, 7 tanker, 8 bridge, 9 house, 10 fuel)'],
  [0xA6, 'BlkPF1', 6, 'Per block: PF1 shape pointer (low byte; page by BlkFlags bit 0)'],
  [0xAC, 'BlkPF2', 6, 'Per block: PF2 shape pointer (low byte; page by BlkFlags bit 1)'],
  [0xB2, 'ShotY', 1, 'The shot\'s line counter value (8 lines from here up)'],
  [0xB3, 'PlaneX', 1, 'The plane\'s X'],
  [0xB5, 'Speed', 1, 'Scroll speed ($40 slow .. $FE fast)'],
  [0xB7, 'Fuel', 1, 'Fuel (the gauge\'s needle)'],
  [0xBA, 'PlanePtr', 2, 'Pointer to the plane\'s graphics (banking left/right, explosion)'],
  [0xC6, 'State', 1, '0 flying; other values: starting, dying; $FF no game?'],
  [0xC7, 'ShapeOdd', 2, 'Kernel: the block\'s object shape for odd lines'],
  [0xC9, 'ShapeEven', 2, 'Kernel: ... for even lines'],
  [0xCB, 'ShapeCol', 2, 'Kernel: ... its colours by row'],
  [0xCD, 'DigitPtr', 8, 'Score digit pointers?'],
  [0xD9, 'PF1Ptr', 2, 'Kernel: the block\'s PF1 shape pointer'],
  [0xDB, 'PF2Ptr', 2, 'Kernel: the block\'s PF2 shape pointer'],
  [0xDE, 'KBlock', 1, 'Kernel: the block being drawn'],
  [0xE0, 'PlaneRefl', 1, 'The plane\'s REFP0 (banking right)'],
  [0xE2, 'HitShotObj', 1, 'Kernel: the block whose object the shot hit ($FF none)'],
  [0xE4, 'HitPlaneBank', 1, 'Kernel: the plane touched the bank ($FF none)'],
  [0xE6, 'HitShotBank', 1, 'Kernel: the shot touched the bank ($FF none)'],
  [0xE8, 'HitPlaneObj', 1, 'Kernel: the block whose object the plane touched ($FF none)'],
  [0xED, 'KFlags', 1, 'Kernel: the block\'s flags (scratch elsewhere)'],
  [0xEE, 'KColPF', 1, 'Kernel: the block\'s bank colour; in the vertical blank the colours $EE-$F3'],
  [0xEF, 'ColPlane', 1, 'The plane\'s (and score\'s) colour'],
  [0xF0, 'ColPanel', 1, 'The bottom panel\'s background'],
  [0xF1, 'ColNeedle', 1, 'The fuel needle\'s colour'],
  [0xF2, 'Temp', 1, 'Scratch'],
  [0xF3, 'ColGauge', 1, 'The gauge\'s colour (and the line above the panel)'],
  [0xF4, 'CurPlayer', 1, 'Player up: 0 or 1'],
  [0xF5, 'ShotX', 1, 'The shot\'s X'],
  [0xFC, 'KRow', 1, 'Kernel: the row within the block'],
  [0xFD, 'KLine', 1, 'Kernel: the line counter (160 at the top, 0 at the last line)'],
];

const labels = {
  0xF000: ['Reset', 'Power on: clear RAM and the TIA'],
  0xF027: ['FrameStart', 'Vertical blank: positions, colours, the kernel\'s entry for the scroll'],
  0xF12E: ['WaitKernel', 'Wait for the timer, then "return" into the kernel at the entry pushed for the scroll'],
  0xF13A: ['KEntryEven', 'Kernel entry: the top line is the first of a row pair'],
  0xF152: ['KEntryOdd', 'Kernel entry: the top line is the second of a row pair'],
  0xF156: ['KRowPair', 'Kernel: a row pair (object, playfield, plane, shot)'],
  0xF1B4: ['KNextBlock', 'Kernel: the next block\'s flags, colour and shapes'],
  0xF1F7: ['KEntryRow0', 'Kernel entry: the top line is a block\'s row 0'],
  0xF205: ['KEntryLast', 'Kernel entry: the top line is a block\'s last line'],
  0xF243: ['KBlockLine0', 'Kernel: a block\'s first line, then its object positioned (RESP1)'],
  0xF296: ['KBlockLine2', 'Kernel: playfield row 14, HMP1'],
  0xF2B7: ['KBlockLine3', 'Kernel: NUSIZ1, then the collisions read for the block above'],
  0xF340: ['KEntryLine4', 'Kernel entry at a block\'s line 4'],
  0xF346: ['KEntryLine5', 'Kernel entry at a block\'s line 5'],
  0xF350: ['Panel', 'The bottom panel: score, fuel gauge, ships left and logo'],
  0xF3C2: ['GaugeLines', 'The fuel gauge'],
  0xF41A: ['LogoLines', 'Ships left and the Activision logo'],
  0xF45C: ['LastCollisions', 'The last block\'s collisions'],
  0xF807: ['FrameSync', 'Wait for the timer, vertical sync'],
  0xFAEF: ['PosObject', 'Position object X at A (CalcPos, then SetPos)'],
  0xFAF2: ['SetPos', 'HMxx = A, wait Y, RESxx'],
  0xFBD5: ['SetPFPtrs', 'The kernel\'s PF1 / PF2 pointers for block X'],
  0xFDD8: ['CalcPos', 'X (A) -> fine motion (A) and coarse count (Y)'],
  0xFFAE: ['WsyncHmove', 'WSYNC, HMOVE'],
};

// The kernel's entries (pushed by the vertical blank by the scroll)
module.exports = { game, ram, labels, code: [0xF1F7, 0xF1B4, 0xF13A, 0xF152, 0xF346, 0xF340, 0xF2B7, 0xF296, 0xF243, 0xF205], always: [] };
