// Profile the C64 build's own self-playing game (DbgAuto, AutoInput in c64/sound.asm: the game
// c64late.js times in VICE) on a plain 6502: each frame one tick (NTSC) and one picture, the
// cycles they take by routine. No raster interrupt: the IRQ's own costs aren't counted.
//   node games/river-raid/tools/c64run.js [ticks] [--from=T] [--slow=cycles] [--profile=Label [--src] [--range=T1-T2]]
//   [--incl] [--count=Label,...]
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('393948436d1f4cc3192410bb918f9724');
const files = require('../../../tools/buildname').files(process.env.RR_BUILD || path.join(__dirname, '..', 'build'));
const prg = fs.readFileSync(files.prg);
const lst = fs.readFileSync(files.lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[2] || m[1], 16);
};
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const ticks = +(process.argv.find(a => /^\d+$/.test(a)) || 3900);
class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) { return this.mem[a & 0xFFFF]; }
  write(a, v) { this.mem[a & 0xFFFF] = v; }
  commit() {} flush() {}
  tick(n) { this.cycles += n; }
  call(addr, limit = 5e6) {
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    const start = this.cycles;
    for (let i = 0; this.pc !== STUB + 3; i++) { this.step(); if (i > limit) throw new Error(`runaway at $${this.pc.toString(16)}`); }
    return this.cycles - start;
  }
}
const c64 = new C64();
const labels = [...lst.matchAll(/^[.>]([0-9a-f]{4})\t(?:([0-9a-f]{4})\t)?.*\t([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[2] || m[1], 16), m[3]]).sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0xF000) return '2600 program'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
const prof = {}, frameProf = {}, calls = {};
const COUNT = (arg('count', '') + '').split(',').filter(Boolean).map(n => [sym(n), n]);
const profLabel = arg('profile', null), pcProf = {};
let curT = 0; const RANGE = (arg('range', '0-99999') + '').split('-').map(Number);
const incl = {}, istack = [], INCL = process.argv.includes('--incl');
{ const st = c64.step.bind(c64); c64.step = function () { const pc = this.pc, c = this.cycles; for (const [a, n] of COUNT) if (pc === a) calls[n] = (calls[n] || 0) + 1;
  if (INCL && this.mem[pc] === 0x20) { const t = this.mem[pc + 1] | this.mem[pc + 2] << 8; istack.push([labelOf(t), c, this.s]); }
  st();
  if (INCL) while (istack.length && this.s >= istack[istack.length - 1][2]) { const [k, c0] = istack.pop(); if (!istack.some(e => e[0] === k)) incl[k] = (incl[k] || 0) + this.cycles - c0; } const k = labelOf(pc), d = this.cycles - c; prof[k] = (prof[k] || 0) + d; frameProf[k] = (frameProf[k] || 0) + d; if (k === profLabel && curT >= RANGE[0] && curT <= RANGE[1]) pcProf[pc] = (pcProf[pc] || 0) + d; }; }
c64.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c64.s = 0xFF;
c64.call(sym('Relocate'));
for (let a = 0xC000; a < 0xD000; a++) c64.mem[a] = 0;
c64.mem[0x0280] = 0xFF; c64.mem[0x0282] = 0x0B; c64.mem[0x0284] = 0; c64.mem[0x0C] = 0x80; c64.mem[0x0D] = 0x80;
c64.mem[sym('firstTick')] = 1;
c64.mem[0x01] = 0x35;
c64.call(sym('InitVideo'));
if (lst.includes('\tPreObj:')) c64.call(sym('PreObj'));   // (the objects' images made ahead, as Start does)
c64.call(sym('InitSound'));
const W = (a, v) => { c64.mem[a] = v & 255; c64.mem[a + 1] = v >> 8; };
W(sym('AutoFrom'), 60000); W(sym('AutoTo'), 60001);
c64.mem[sym('DbgAuto')] = 1;
c64.mem[sym('AutoR')] = 1; c64.mem[sym('AutoSpeed')] = 0xF0;
const from = arg('from', 300), slow = arg('slow', 0);
const per = [];
for (let t = 0; t < ticks; t++) {
  curT = t;
  for (const k in frameProf) delete frameProf[k];
  c64.mem[0x0280] = 0xFF; c64.mem[0x0C] = 0x80; c64.mem[0x0D] = 0x80; c64.mem[0x0282] = 0x0B;   // (ReadInput's, at rest)
  const a = c64.call(sym('Tick'));
  const b = c64.call(sym('Render'));
  const c = c64.call(sym('UpdateSound'));
  c64.mem[sym('curBuf')] = c64.mem[sym('rbuf')];
  if (t >= from) per.push([a, b, c]);
  if (slow && t >= from && a + b + c > slow) console.log(`tick ${t}: ${a} + ${b} + ${c}: ` + Object.entries(frameProf).filter(e => e[1] > 300).sort((x, y) => y[1] - x[1]).slice(0, 8).map(([k, v]) => k + ' ' + v).join(', '));
}
const tot = per.map(p => p[0] + p[1] + p[2]).sort((x, y) => x - y), at = q => tot[Math.min(tot.length - 1, Math.floor(q * tot.length))];
const avg = i => Math.round(per.reduce((s, p) => s + p[i], 0) / per.length);
console.log(`${per.length} frames: tick ${avg(0)}, render ${avg(1)}, sound ${avg(2)} on average; total median ${at(0.5)}, 90% ${at(0.9)}, 99% ${at(0.99)}, most ${tot[tot.length - 1]}`);
if (COUNT.length) console.log('calls a frame:', Object.entries(calls).map(([k, v]) => k + ' ' + (v / ticks).toFixed(2) + ' (' + v + ')').join(', '));
const sum = Object.values(prof).reduce((x, y) => x + y, 0);
for (const [k, v] of Object.entries(prof).sort((x, y) => y[1] - x[1]).slice(0, 25)) console.log(k.padEnd(16), String(Math.round(v / ticks)).padStart(7), (100 * v / sum).toFixed(1) + '%');
if (INCL) { console.log('inclusive (calls from their callers):'); for (const [k, v] of Object.entries(incl).sort((x, y) => y[1] - x[1]).slice(0, 40)) console.log('  ' + k.padEnd(16), String(Math.round(v / ticks)).padStart(7)); }
if (profLabel && !process.argv.includes('--src')) for (const [pc, v] of Object.entries(pcProf).sort((x, y) => y[1] - x[1]).slice(0, 20)) console.log('  $' + (+pc).toString(16), Math.round(v / ticks));
// --src: the routine's listing, each line with its cycles a frame
if (profLabel && process.argv.includes('--src')) {
  const at = {};
  for (const l of lst.split('\n')) { if (l[0] !== '.') continue; const p = l.split('\t'); const a = /^[0-9a-f]{4}$/.test(p[1]) ? parseInt(p[1], 16) : parseInt(p[0].slice(1), 16); if (!(a in at)) at[a] = p[p.length - 1]; }
  for (const a of Object.keys(pcProf).map(Number).sort((x, y) => x - y)) console.log(String(Math.round(pcProf[a] / (process.argv.some(x => x.startsWith('--range=')) ? RANGE[1] - RANGE[0] + 1 : ticks))).padStart(5), (at[a] || '').replace(/\t/g, ' ').slice(0, 100));
}
