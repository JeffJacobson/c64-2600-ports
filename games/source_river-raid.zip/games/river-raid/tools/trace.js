// Log one frame's TIA writes (line, colour clock, register, value, PC), to study the kernel.
//   node games/river-raid/tools/trace.js <frame> [--reset] [--from=line] [--to=line] [--regs=PF1,GRP0]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('393948436d1f4cc3192410bb918f9724'));
const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
const NAMES = ['VSYNC', 'VBLANK', 'WSYNC', 'RSYNC', 'NUSIZ0', 'NUSIZ1', 'COLUP0', 'COLUP1', 'COLUPF', 'COLUBK', 'CTRLPF', 'REFP0', 'REFP1',
  'PF0', 'PF1', 'PF2', 'RESP0', 'RESP1', 'RESM0', 'RESM1', 'RESBL', 'AUDC0', 'AUDC1', 'AUDF0', 'AUDF1', 'AUDV0', 'AUDV1', 'GRP0', 'GRP1',
  'ENAM0', 'ENAM1', 'ENABL', 'HMP0', 'HMP1', 'HMM0', 'HMM1', 'HMBL', 'VDELP0', 'VDELP1', 'VDELBL', 'RESMP0', 'RESMP1', 'HMOVE', 'HMCLR', 'CXCLR'];
const frame = +(process.argv[2] || 100);
if (process.argv.includes('--reset')) { vcs.runFrames(10); vcs.swchb &= ~1; vcs.runFrames(5); vcs.swchb |= 1; }
vcs.runFrames(Math.max(0, frame - vcs.frames));
const from = +opt('from', 0), to = +opt('to', 300);
const regs = opt('regs', '') ? new Set(opt('regs', '').split(',')) : null;
const orig = vcs.tiaWrite.bind(vcs);
vcs.tiaWrite = (a, v) => {
  const n = NAMES[a] || a.toString(16);
  if (vcs.line >= from && vcs.line <= to && (!regs || regs.has(n)))
    console.log(`${String(vcs.line).padStart(3)} ${String(vcs.clock - 68).padStart(4)} ${n.padEnd(7)} ${v.toString(16).padStart(2, '0')}  ${vcs.lastPc.toString(16)}`);
  orig(a, v);
};
vcs.runFrames(1);
