// Checks tools/model.js against tools/vcs.js over frames of random play: each line's TIA state
// (tools/probe.js), then (later) pixels and collisions.
//   node games/river-raid/tools/modelcheck.js [frames] [--seed=N] [--learn] [--show=N]
'use strict';
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const probe = require('./probe');
const model = require('./model');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? +a.split('=')[1] : d; };
const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 2000);
const opts = { k3: arg("k3", 0), k4: arg("k4", 0) };
const learn = process.argv.includes('--learn');
const show = arg('show', 5);
const vcs = new VCS(require('../../../tools/rom').load('393948436d1f4cc3192410bb918f9724'));
vcs.hmoveBlank = true;
probe.attach(vcs);
const play = require('./play')(arg('seed', 1));
// RAM when the kernel starts ($F12E: the wait for the timer)
let kram = null, ktia = null, eram = null;
const step = vcs.step.bind(vcs);
vcs.step = () => { if (vcs.pc === 0xF489 && kram && !eram) { eram = new Uint8Array(256); eram.set(vcs.ram, 0x80); }
  if (vcs.pc === 0xF12E && !kram) { kram = new Uint8Array(256); kram.set(vcs.ram, 0x80); ktia = vcs.r.slice(); } step(); };
const stats = { cmp: 0, e2: 0, e4: 0, e6: 0, e8: 0, p1f: 0 };
const needle = [];
const bad = {}; let shown = 0, checked = 0;
const FIELDS = ['pf1', 'pf2', 'colupf', 'grp1', 'colup1', 'nusiz1', 'p1', 'p0', 'grp0', 'm0', 'enam0'];
for (let f = 0; f < frames; f++) {
  play.step(vcs);
  kram = null; eram = null;
  vcs.runFrames(1);
  if (!kram || vcs.frames < 3) continue;
  const ram = kram, got = vcs.lines;
  const want = model.lines(ram);
  checked++;
  for (const w of want) {
    const g = got[w.line];
    for (const k of FIELDS) {
      if (w[k] === undefined) continue;
      if ((k === 'colup1' || k === 'nusiz1' || k === 'p1') && !g.grp1) continue;
      if (k === 'p0' && !g.grp0) continue;
      if (k === 'm0' && !(g.enam0 & 2)) continue;
      if (k === 'enam0' && (g[k] & 2) === (w[k] & 2)) continue;
      if (g[k] !== w[k]) {
        bad[k] = (bad[k] || 0) + 1;
        if (shown < show) { shown++; console.log(`frame ${vcs.frames} line ${w.line} b${w.b} o${w.o} ${k}: got ${g[k].toString(16)} want ${w[k].toString(16)}  8B=${ram[0x8B]}`); }
      }
    }
  }
  // collisions
  if (eram) { stats.cmp++; if (eram[0xE2] !== 0xFF) stats.e2++; if (eram[0xE4] !== 0xFF) stats.e4++; if (eram[0xE6] !== 0xFF) stats.e6++; if (eram[0xE8] !== 0xFF) stats.e8++; for (let b = 0; b < 6; b++) if (eram[0x8E + b] & 0x20) stats.p1f++;
    const cx = model.collide(ram, want, ktia, opts);
    const exp = { e2: cx.e[0], e4: cx.e[1], e6: cx.e[2], e8: cx.e[3] };
    for (let b = 0; b < 7; b++) exp["f" + b] = ram[0x8E + b] | (cx.p1f[b] ? 0x20 : 0);
    const gotc = { e2: eram[0xE2], e4: eram[0xE4], e6: eram[0xE6], e8: eram[0xE8] };
    for (let b = 0; b < 7; b++) gotc["f" + b] = eram[0x8E + b];
    for (const k in exp) if (exp[k] !== gotc[k]) {
      bad["cx_" + k] = (bad["cx_" + k] || 0) + 1;
      if (shown < show) { shown++; console.log(`frame ${vcs.frames} collision ${k}: got ${gotc[k].toString(16)} want ${exp[k].toString(16)}  8B=${ram[0x8B]}`); }
    }
  }
  // the panel
  if (eram) {
    const pr = Uint8Array.from(ram); pr[0xC0] = eram[0xC0];
    let top = 7; if (ram[0xC6] === 0xFF) { const a = ram[0x82] >> 3; top = a >= 0x14 ? 15 : a < 0x0C ? 7 : a - 4; }
    const nx = vcs.pos[4]; needle[ram[0xB7] >> 3] = needle[ram[0xB7] >> 3] || new Set(); needle[ram[0xB7] >> 3].add(nx);
    const pc = new Uint8Array(160);
    for (let L = 198; L <= 235; L++) {
      model.panelPixels(pr, L, nx, top, pc);
      for (let x = 0; x < 160; x++) if (vcs.fb[L * 160 + x] !== pc[x] >> 1) {
        bad.panel = (bad.panel || 0) + 1;
        if (shown < show) { shown++; console.log(`frame ${vcs.frames} panel line ${L} x ${x}: got ${(vcs.fb[L * 160 + x] << 1).toString(16)} want ${pc[x].toString(16)}`); }
      }
    }
  }
  // pixels
  const col = new Uint8Array(160), obj = new Uint8Array(160);
  for (const w of want) {
    if (w.colup1 === undefined) w.colup1 = got[w.line].colup1;
    model.linePixels(w, ktia, col, obj);
    for (let x = 0; x < 160; x++) {
      const i = w.line * 160 + x;
      if (vcs.fb[i] !== col[x] >> 1 || vcs.ob[i] !== obj[x]) {
        bad.pixel = (bad.pixel || 0) + 1;
        if (shown < show) { shown++; console.log(`frame ${vcs.frames} line ${w.line} x ${x}: got ${(vcs.fb[i] << 1).toString(16)}/${vcs.ob[i]} want ${col[x].toString(16)}/${obj[x]}`); }
      }
    }
  }
}
console.log(`${checked} frames checked`, bad, stats);
console.log('needle x by fuel >> 3:', needle.map((v, i) => v ? i + ':' + [...v].join('/') : '').filter(Boolean).join(' '));
