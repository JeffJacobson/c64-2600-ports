// A model of what River Raid's kernel draws, built only from the RAM at the kernel's start
// (the game's state when it hands over to the kernel, $F12E). Checked against tools/vcs.js by
// tools/modelcheck.js: line by line (the TIA's registers as each line shows them), pixel by pixel
// and in its collisions.
//
// The play area is 2600 lines 37-197 (FD = 197 - line counts down to 0). It is made of blocks of
// 32 lines (six, index 5 at the top); the top line is offset o = 31 - $8B into block 5. A block's
// line o: playfield row r = 15 - o/2 (two lines a row; row 0 at o = 30-31), the block's object
// (player 1) on rows 12..1 at o = 6..29 (two lines a row: the "even" shape table, then the "odd").
'use strict';
const ROM = require('../../../tools/rom').load('393948436d1f4cc3192410bb918f9724');
const rb = a => ROM[a & 0xFFF];

const T_ODD = 0xFFC8, T_EVEN = 0xFBBB, T_COL = 0xFF23, T_ROAD = 0xFFB3;
const PLAY_TOP = 37, PLAY_END = 197;


function mask(ram, c) { return ((c ^ ram[0x85]) & ram[0x86]) & 0xFF; }

// ram: 256-entry array (index = address; $80-$FF used)
function lines(ram) {
  const k8b = ram[0x8B];
  const o37 = 31 - k8b;
  const out = [];
  const blk = L => { const d = L - PLAY_TOP + o37; return { b: 5 - (d >> 5), o: d & 31 }; };
  const flags = b => ram[0x8E + b];
  const pf1 = (b, r) => rb(((0xFC | (flags(b) & 1)) << 8) + ram[0xA6 + b] + r);
  const pf2 = (b, r) => rb(((0xFC | ((flags(b) >> 1) & 1)) << 8) + ram[0xAC + b] + r);
  const ee = b => mask(ram, 0xD2 | (flags(b) & 4));
  const type = b => ram[0xA0 + b];
  for (let L = PLAY_TOP; L <= PLAY_END; L++) {
    const { b, o } = blk(L);
    const r = 15 - (o >> 1);
    const s = { line: L, b, o };
    s.pf1 = pf1(b, r); s.pf2 = pf2(b, r);
    // playfield colour
    if (o < 6) s.colupf = ee(b);
    else {
      const rr = o >= 30 ? 1 : 12 - ((o - 6) >> 1);
      s.colupf = (flags(b) & 0x80) && rr < 13 ? mask(ram, rb(T_ROAD + rr)) : ee(b);
    }
    // the object
    s.grp1 = 0;
    if (o >= 6 && o < 30 && !(L === PLAY_TOP && o === 29)) {   // (the top line at o 29: not drawn)
      const rr = 12 - ((o - 6) >> 1), t = type(b);
      const p = (o & 1) ? rb(T_ODD + t) : rb(T_EVEN + t);
      s.grp1 = rb(0xFE00 + ((p + rr) & 0xFF));
      s.colup1 = mask(ram, rb(0xFF00 + ((rb(T_COL + t) + rr) & 0xFF)));
    }
    s.nusiz1 = ram[0x9A + b];
    const c = ram[0x94 + b], h = ram[0x9A + b] >> 4;
    s.p1 = (6 + 15 * c - (h < 8 ? h : h - 16) + 160) % 160;
    // the plane (player 0) on the bottom 19 lines, the shot (missile 0) in pairs of lines above
    const fd = PLAY_END - L;
    s.p0 = ram[0xB3] + (ram[0xE0] ? 1 : 0);
    s.grp0 = fd + 1 < 19 ? rb((ram[0xBB] << 8) + ram[0xBA] + fd + 1) : 0;
    s.m0 = (ram[0xF5] + 159) % 160;
    const ky = (o & 1) ? fd + 1 : fd + 2;     // ENAM0 is written on the odd lines
    const wo = (o & 1) ? o : o - 1;           // (the line that wrote it: at o 3 and 5 the plane's
    const plane = ky < 19 && wo !== 3 && wo !== 5;   // lines don't turn the shot off)
    // (the kernel's first ENAM0 write is on line 38 or 39: the first odd line after the top)
    s.enam0 = plane || L === PLAY_TOP || (L === PLAY_TOP + 1 && !(o & 1)) ? 0 :(((ky - ram[0xB2]) & 0xF8) === 0 ? 2 : 0);
    out.push(s);
  }
  return out;
}

// The pixels of one line (what tools/vcs.js draws): colour (2600 value) and objects bits
// (1 P0, 2 P1, 4 M0, 32 PF) per pixel. tia: the TIA registers the vertical blank left ($00-$3F).
const COPIES = [[0], [0, 16], [0, 32], [0, 16, 32], [0, 64], [0], [0, 32, 64], [0]];
function playerBit(g, pos, nus, refl, x) {
  if (!g) return false;
  const d = (x - pos + 160) % 160, scale = nus === 5 ? 2 : nus === 7 ? 4 : 1;
  for (const c of COPIES[nus]) {
    const dd = d - c;
    if (dd >= 0 && dd < 8 * scale) { let bit = Math.floor(dd / scale); if (!refl) bit = 7 - bit; return ((g >> bit) & 1) === 1; }
  }
  return false;
}
function pfBit(s, pf0, x) {
  let c = x >> 2;
  if (c >= 20) c = 39 - c;             // (reflected playfield)
  if (c < 4) return (pf0 >> (4 + c)) & 1;
  if (c < 12) return (s.pf1 >> (11 - c)) & 1;
  return (s.pf2 >> (c - 12)) & 1;
}
function linePixels(s, tia, col, obj) {
  for (let x = 0; x < 160; x++) {
    if (x < 8) { col[x] = 0; obj[x] = 0; continue; }   // the HMOVE comb
    const p0 = playerBit(s.grp0, s.p0, tia[0x04] & 7, tia[0x0B] & 8, x);
    const p1 = playerBit(s.grp1, s.p1, s.nusiz1 & 7, s.nusiz1 & 8, x);
    const m0 = (s.enam0 & 2) && x === s.m0;
    const pf = !!pfBit(s, tia[0x0D], x);
    let c = tia[0x09];
    if (pf) c = s.colupf;
    if (p1) c = s.colup1;
    if (p0 || m0) c = tia[0x06];
    col[x] = c; obj[x] = p0 | p1 << 1 | m0 << 2 | pf << 5;
  }
}

// The collisions: what the kernel stores from the TIA's collision latches. Each block's line
// o 3 reads M0-P1, P0-PF, M0-PF and P0-P1 (into $E2, $E4, $E6, $E8: the block above's index,
// X = block + 1), its line o 4 reads P1-PF (bit 5 of the block above's flags) and clears the
// latches (CXCLR). After the picture, the last reads store X = 0 (1 if $8B >= 26).
// The reads' clocks: 21 later on the plane's lines (the kernel loads its graphics first), 6 later
// for each read before that found a hit (its STX); the clear 27 later after a P1-PF hit.
// Pairs (bits of a line's objects): M0P = M0 & P1, P0F = P0 & PF, M0F = M0 & PF, PP = P0 & P1, P1F = P1 & PF
const PAIRS = [[4, 2], [1, 32], [4, 32], [1, 2], [2, 32]];
function collide(ram, ls, tia, opts = {}) {
  const res = { e: [ram[0xE2], ram[0xE4], ram[0xE6], ram[0xE8]], p1f: [0, 0, 0, 0, 0, 0, 0] };   // (p1f[6]: $94 bit 5)
  const lat = [0, 0, 0, 0, 0];
  const col = new Uint8Array(160), obj = new Uint8Array(160);
  // the line's hits in pixel order, applied up to a clock
  let L, hits;
  const upto = c => { for (const h of hits) if (h.x < c && !h.done) { h.done = 1; lat[h.p] = 1; } };
  const k8b = ram[0x8B];
  for (const s of ls) {
    L = s.line;
    model_linePixels(s, tia, col, obj);
    hits = [];
    for (let x = 8; x < 160; x++) for (let p = 0; p < 5; p++)
      if ((obj[x] & PAIRS[p][0]) && (obj[x] & PAIRS[p][1]) && !hits.some(h => h.p === p)) hits.push({ x, p });
    const fd = PLAY_END - L;
    if (s.o === 3 && L > PLAY_TOP) {
      let c = 25 + (fd + (opts.k3 ?? 0) < 19 ? 21 : 0);
      const blk = s.b + 1;
      for (let p = 0; p < 4; p++) {
        upto(c);
        if (lat[p]) { res.e[p] = blk; c += 6; }
        c += 18;
      }
      upto(160);
    } else if (s.o === 4 && L > PLAY_TOP) {
      const plane = fd + (opts.k4 ?? 0) < 19;
      let c = 31 + (plane ? 21 : 0);
      upto(c);
      const hit = lat[4];
      if (hit) res.p1f[s.b + 1] = 1;
      c = 58 + (plane ? 21 : 0) + (hit ? 27 : 0);
      upto(c);
      lat.fill(0);
      for (const h of hits) h.done = h.x < c ? 1 : h.done;
      upto(160);
    } else upto(160);
  }
  const blk = k8b >= 26 ? 1 : 0;
  for (let p = 0; p < 4; p++) if (lat[p]) res.e[p] = blk;
  if (lat[4]) res.p1f[blk] = 1;
  return res;
}
const model_linePixels = linePixels;

// The bottom panel (lines 198-235): six 8-pixel columns from pixel 56 (players 0 and 1, three
// copies each, both vertically delayed: the 48-pixel trick). Line 198 the gauge's colour ($F3),
// the rest the panel's ($F0). The score (lines 200-207, rows 7-0) from the six digit pointers
// $CD-$D7 in the score's colour ($EF); the fuel gauge (lines 210-224, rows 14-0) from five ROM
// columns (the first column empty) in $F3, with the needle (the ball, two pixels, ROM column
// $FE48 its enable) in $F1 behind them; the ships left ($C0 pointer) and the logo (lines 227-234,
// rows from the kernel's $FC down) in $EF.
const T_GAUGE = [null, 0xFE00, 0xFE0F, 0xFE1D, 0xFE2B, 0xFE39], T_NEEDLE = 0xFE48;
const T_LOGO = [null, 0xFB68, 0xFB78, 0xFB88, 0xFB98, 0xFBA8];
function panelLine(ram, L, needleX, logoTop) {
  const cols = [0, 0, 0, 0, 0, 0];
  let colour = ram[0xEF], bg = ram[0xF0], needle = false;
  if (L === 198) return { cols, colour, bg: ram[0xF3], needle };
  if (L >= 200 && L <= 207) {
    const y = 207 - L;
    for (let k = 0; k < 6; k++) cols[k] = rb((ram[0xCE + 2 * k] << 8) + ram[0xCD + 2 * k] + y);
  } else if (L >= 210 && L <= 224) {
    const y = 224 - L;
    for (let k = 1; k < 6; k++) cols[k] = rb(T_GAUGE[k] + y);
    colour = ram[0xF3];
    needle = (rb(T_NEEDLE + y) & 2) !== 0;
  } else if (L >= 227 && L <= 234) {
    const y = logoTop - (L - 227);
    cols[0] = rb((ram[0xC1] << 8) + ram[0xC0] + y);
    for (let k = 1; k < 6; k++) cols[k] = rb(T_LOGO[k] + y);
  }
  return { cols, colour, bg, needle };
}
function panelPixels(ram, L, needleX, logoTop, col) {
  const p = panelLine(ram, L, needleX, logoTop);
  for (let x = 0; x < 160; x++) {
    let c = p.bg;
    if (p.needle && (x === needleX || x === needleX + 1)) c = ram[0xF1];
    const k = (x - 56) >> 3;
    if (x >= 56 && k < 6 && (p.cols[k] >> (7 - ((x - 56) & 7))) & 1) c = p.colour;
    col[x] = x < 8 ? 0 : c;
  }
}

module.exports = { lines, linePixels, collide, panelLine, panelPixels, PLAY_TOP, PLAY_END, mask };
