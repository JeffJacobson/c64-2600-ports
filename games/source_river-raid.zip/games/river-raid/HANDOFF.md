# River Raid port: handoff (2026-10-14, third session)

Status: version 1.0, published 2026-10-14 (next version 1.1). Runs in VICE, lockstep
exact, screencheck clean but for one known case. README.md written. Colours chosen with the user
(2026-10-13: land green $D6 -> 5, trees stay light green; the road light grey in colour). The user
found the sound fine.

## Timing now (VICE, tools/c64late.js, self-playing game, frames with no new picture)
- ticks 300-3900: PAL 0, NTSC 0
- ticks 3900-7500 (`--from=3900`): PAL 0, NTSC 2-5 (run to run noise of +-1-2): ticks ~4671-4675
  (a road in a busy stretch) and ~7402-7408 (7408: the self-play refuels in jumps, GaugeGlyphs
  ~3K: a test artefact)
- black and white (`--bw`): NTSC 0.1-0.3% (the first sight of each object: its B&W image made
  then), PAL 0
- This session: 14 -> 2-5 on NTSC 3900-7500 (ShQuick: only the shot's own rows / lines, object
  only if its pixels are in the shot's column; BlockObject: nothing new goes straight to the
  event; road colour events from a list; one interrupt fewer). Tried and dropped: colour writes
  with 1 line of lead (one late frame less, glitch risk), skipping a latch window's later shot
  lines (no gain there).
- What's left costs: road stretches have ~6 colour-write interrupts (~170 cycles each, ~85 of it
  waiting); BlockObject's moving objects' X path; PlaneScan / ShotScan near land.

## The panel switch (2026-10-14, with the user in VICE: the flicker at the bottom)
- Line 216 must be a badline that starts the panel's rows: $D011 (scroll 0, 25 rows) and $D018
  (STATA / STATB) written after the river's last badline began and before 216's. As raster
  interrupts this came late now and then (other interrupts, the sprites' fetches): the panel's
  top broke up. Now an NMI does it: CIA 2's timer A runs at the frame's period (NmiInit, by
  the last raster line), started on 215; NmiPanel (render.asm) writes $D011/$D018 first, then a
  colour write folded on 215 (NmV) and the panel's colours; FrameTop sets its values. The 2600
  code's table at $FFF7 is read from a copy (TFFF7c): $FFFA/$FFFB are the NMI vector.
- Scroll 7: line 215 is then the river's last badline, and with an object's sprites at the
  bottom the VIC holds the CPU from 215's cycle 12 to 216's cycle ~10: no cycle for the switch.
  The user chose: scroll 7 is drawn as 6 (Phase), the colour events a line earlier (rasOfs).
  screencheck skips the river's lines in those frames.
- IrqStat now only does the colour writes folded from line 211 on (FoldEv); STATLEAD 4.
- Ways that were tried and why they failed are in the git log (2026-10-13/14). Catching it:
  screenshots from the user's VICE through its monitor while they play (scratch grab.js) were
  what finally showed the case; the self-play rarely has an object at the bottom then.

## Found and fixed by screencheck / VICE this session
- double / quad width objects a pixel early (vcs.js wideDelay = the real TIA): ObjXOff + oX
- a wide object's bottom row (the bridge's pillars) dropped: _merge in MakeObj
- an object whose only line is o 29 on the top line was drawn (BlockObject cmp #38)
- the shot's sprite blocks and $7FFF (the VIC's idle byte) never cleared (junk beside the shot,
  a pattern on the panel's last three lines): screencheck now fills unloaded RAM with $AA
- the comb on the panel's last three lines (past the last badline): sprite 2 (BLK_COMB) from
  EvLogo, its pointer blank again at FrameTop
- the panel's colours and switch: see above (NMI)
- the plane fired by itself (user): the 2600 writes REFP1 / PF0 at $0C / $0D where it reads
  INPT4 / INPT5; a pass doing two ticks (PAL) read leftovers. TickIn stores them before each tick
- IrqWrite's wait loop 7 cycles: the grey dots at the first pixel past the comb gone from the
  test shots

## Testing aids (turn off / check before release)
DBGTIME and DBGLOG = 0 in main.asm (DBGLOG=1 needed for tools/c64irq.js); DbgBorder, DbgRepT log,
DbgMoveLate (inside stage code), AutoInput self-play (steers every 4th tick).

## Verification tools
- tools/lockstep.js [frames] --seed=N (several seeds) [--bw] [--diff=A] [--power=F]: 0 differences.
- tools/screencheck.js [frames] [--seed=N] [--bw] [--diff=A] [--events=F] [--png=dir] [--lines=A-B]:
  the C64 picture modelled from the frame's events vs the 2600; 16 frames in 2000 differ, all a
  bridge's debris (its white row: more colours than the sprites hold; documented in README).
- tools/inputtest.js: keys / joysticks / F1-F8 (all right).
- tools/c64test.js <dir> [--ntsc] [--c64c] [--play] [--shots=n] [--every=ms] [--power]; then
  tools/greydots.js on the shots (a few dots left near the panel's top, ~5 in 64 shots).
- tools/c64late.js [--ntsc] [--from=T] [--reps] [--bw] [--png=dir].
- A/B picture check (old build vs new, same self-play, events + stage code + St* + screen): was a
  scratch script this session (abcheck.js); worth adding to tools/ if render work goes on.
- Timing probes used: a scratch copy of c64/ with a histogram (DbgHL/DbgHH by $D012) after a
  store, read from VICE after a c64late-style run.

## Still to do
1.1 built 2026-10-26, not published: the panel medium grey (2600 $06 -> C64 12, a player's
suggestion; B&W land too). Publish
with publish.cmd after the user says so).
